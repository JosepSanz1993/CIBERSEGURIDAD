"""Demostración end-to-end de Photo2Print (Fases 1–4), sin GUI ni IA.

Crea un sujeto sintético "busto" con siluetas y colores dependientes del
ángulo, reconstruye el volumen multivista con color, aplica postprocesado
(vaciado + decimación), exporta con color y genera un print pack con vistas
previa. Ejecuta:  python examples/demo_pipeline.py
"""
from __future__ import annotations

import os
import numpy as np
from PIL import Image

from app.pipeline import cameras, multiview, texturing, mesh_tools, render_preview, printpack
from app.pipeline.cameras import View
from app import exporters
from app.config import PrintSettings


def _bust_silhouette(H, W, width_scale):
    """Silueta de busto: cabeza (elipse) + hombros (trapecio). width_scale<1 = perfil."""
    yy, xx = np.mgrid[0:H, 0:W]
    cx = W / 2
    head_cx, head_cy, head_rx, head_ry = cx, H * 0.34, W * 0.16 * width_scale, H * 0.17
    head = ((xx - head_cx) / head_rx) ** 2 + ((yy - head_cy) / head_ry) ** 2 <= 1.0
    # hombros: trapecio que se ensancha hacia abajo
    top, bot = H * 0.52, H * 0.92
    half_top, half_bot = W * 0.13 * width_scale, W * 0.34 * width_scale
    t = np.clip((yy - top) / (bot - top), 0, 1)
    half = half_top + (half_bot - half_top) * t
    shoulders = (yy >= top) & (yy <= bot) & (np.abs(xx - cx) <= half)
    return head | shoulders


def make_views(n=6):
    H, W = 360, 300
    views = []
    for ang in cameras.default_angles(n):
        # el perfil (90/270) es más estrecho que el frente/espalda (0/180)
        a = np.radians(ang)
        width_scale = 0.55 + 0.45 * abs(np.cos(a))       # 1.0 de frente, ~0.55 de lado
        sil = _bust_silhouette(H, W, width_scale)
        mask = (sil.astype(np.uint8) * 255)
        # color: frente cálido (piel/camiseta clara), espalda azul, laterales verde
        front = max(0.0, np.cos(a))
        back = max(0.0, -np.cos(a))
        side = 1 - front - back
        skin = np.array([232, 190, 158]); jacket = np.array([54, 110, 200]); flank = np.array([70, 175, 120])
        col = (skin * front + jacket * back + flank * side).clip(0, 255).astype(np.uint8)
        rgb = np.full((H, W, 3), (240, 242, 245), np.uint8)
        rgb[sil] = col
        views.append(View(rgb=rgb, mask=mask, angle_deg=ang))
    return views


def main():
    out = "/tmp/demo_out"
    os.makedirs(out, exist_ok=True)
    views = make_views(6)

    # guarda las "fotos" de entrada
    for v in views:
        Image.fromarray(v.rgb).save(f"{out}/foto_{int(v.angle_deg):03d}.png")

    print("Reconstruyendo volumen multivista…")
    mesh = multiview.visual_hull(views, multiview.VisualHullParams(resolution=110, smooth_iters=8))
    mesh = mesh_tools.basic_repair(mesh)
    mesh = mesh_tools.keep_largest_component(mesh)
    print(f"  volumen: {len(mesh.faces)} caras, estanco={mesh.is_watertight}")

    print("Transfiriendo color…")
    mesh = texturing.color_from_views(mesh, views)

    print("Orientando de pie + escala a 120 mm…")
    mesh = mesh_tools.orient_upright_y_to_z(mesh)
    mesh = mesh_tools.scale_to_height(mesh, 120.0, axis=2)

    from app.pipeline import postprocess as pp
    print("Vaciando (pared 2.5 mm) y decimando…")
    solid_faces = len(mesh.faces)
    hollow = pp.hollow(mesh, wall_thickness_mm=2.5, drain_diameter_mm=6.0)
    # el vaciado pierde el color por vértice; se re-muestrea desde la malla con color
    hollow = pp._transfer_colors_nearest(mesh, hollow)
    final = pp.decimate(hollow, 60000)
    print(f"  caras: {solid_faces} (sólido) → {len(final.faces)} (vaciado+decimado)")

    print("Exportando (PLY con color, STL, 3MF)…")
    exporters.export(mesh, f"{out}/busto_solido", "ply")
    exporters.export(final, f"{out}/busto_vaciado", "ply")
    exporters.export(final, f"{out}/busto_vaciado", "stl")

    print("Generando print pack…")
    st = PrintSettings(target_height_mm=120, material="PLA", nozzle_diameter_mm=0.4)
    info = printpack.export_print_pack(final, f"{out}/print_pack", st, model_format="3mf")
    print("  estimación:", info["estimate"])

    print("Renderizando vistas previa…")
    for name, az in [("frente", 0), ("perfil", 90), ("iso", 35)]:
        render_preview.save_png(mesh, f"{out}/preview_{name}.png", size=560, azim_deg=az, elev_deg=15)
    print("Listo. Artefactos en", out)
    return out


if __name__ == "__main__":
    main()
