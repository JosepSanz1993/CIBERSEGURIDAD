# Salida de la demostración (examples/demo_pipeline.py)

Generado ejecutando el pipeline completo (Fases 1–4) sobre un sujeto sintético,
sin GUI ni IA. Reprodúcelo con:  `PYTHONPATH=. python examples/demo_pipeline.py`

- `foto_000/090/180.png` — algunas de las "fotos" de entrada (siluetas + color por ángulo).
- `preview_frente/perfil/iso.png` — vistas previa del modelo (render por software, sin GPU).
- `print_pack_manifest.json` — manifiesto del print pack (dimensiones, material, ajustes).

Nota: el sujeto es sintético; con fotos reales el resultado es mucho más fiel.
