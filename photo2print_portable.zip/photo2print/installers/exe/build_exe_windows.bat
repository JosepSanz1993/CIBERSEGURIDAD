@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0\..\.."
title Photo2Print - construir .exe

echo ============================================================
echo   Construir Photo2Print.exe (autocontenido) para Windows
echo   Esto se hace UNA vez. Necesita Python 3.10-3.12 e internet.
echo   El .exe resultante NO necesita instalar nada para ejecutarse.
echo ============================================================
echo.

set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY ( python --version >nul 2>nul && set "PY=python" )
if not defined PY goto no_python
%PY% --version
echo.

echo [1/3] Creando entorno de construccion...
%PY% -m venv .build-venv
if not exist ".build-venv\Scripts\python.exe" goto venv_fail
set "VPY=.build-venv\Scripts\python.exe"

echo [2/3] Instalando dependencias + PyInstaller (puede tardar)...
"%VPY%" -m pip install --upgrade pip
"%VPY%" -m pip install -r requirements-web.txt pyinstaller > build_log.txt 2>&1
if errorlevel 1 goto pip_fail

echo [3/3] Empaquetando (esto tarda unos minutos)...
"%VPY%" -m PyInstaller installers\exe\photo2print_web.spec --noconfirm >> build_log.txt 2>&1
if errorlevel 1 goto build_fail

if not exist "dist\Photo2Print.exe" goto build_fail
copy /Y "dist\Photo2Print.exe" "Photo2Print.exe" >nul

echo.
echo ============================================================
echo   LISTO.  Se ha creado:  Photo2Print.exe  (en esta carpeta)
echo   Doble clic en Photo2Print.exe para usar la aplicacion.
echo   Ese .exe ya lleva todo dentro; puedes copiarlo a otro PC.
echo ============================================================
goto end

:no_python
echo [ERROR] No se ha encontrado Python. Instala 3.10-3.12 desde python.org
echo         (marca "Add python.exe to PATH") y vuelve a ejecutar este archivo.
goto end
:venv_fail
echo [ERROR] No se pudo crear el entorno .build-venv (posible alias de Microsoft Store).
echo         Instala Python real desde python.org.
goto end
:pip_fail
echo [ERROR] Fallo instalando dependencias. Revisa build_log.txt.
goto end
:build_fail
echo [ERROR] Fallo en PyInstaller. Revisa build_log.txt.
goto end
:end
echo.
pause
endlocal
