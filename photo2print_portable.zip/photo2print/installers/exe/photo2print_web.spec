# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec para Photo2Print (interfaz WEB, ejecutable único).

Produce un ejecutable autocontenido que arranca la interfaz web (abre el
navegador). Incluye Python y todas las dependencias ligeras; NO requiere que el
usuario instale nada. Entrada: run_web.py.

Construir (desde la RAÍZ del proyecto):
    pyinstaller installers/exe/photo2print_web.spec --noconfirm

Salida:  dist/Photo2Print(.exe)
"""
from PyInstaller.utils.hooks import collect_all
import os

# Raíz del proyecto = dos niveles por encima de este .spec (installers/exe/).
ROOT = os.path.abspath(os.path.join(SPECPATH, "..", ".."))

datas, binaries, hidden = [], [], []
# Paquetes con datos/DLLs que hay que recoger enteros:
for pkg in ("trimesh", "scipy", "numpy", "skimage", "shapely",
            "fast_simplification", "PIL", "lxml"):
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hidden += h
    except Exception:
        pass

# La app lee estos módulos por nombre en tiempo de ejecución:
hidden += ["app", "app.webapp", "app.pipeline", "app.exporters"]

a = Analysis(
    [os.path.join(ROOT, "run_web.py")],
    pathex=[ROOT],
    binaries=binaries,
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    runtime_hooks=[],
    excludes=["PySide6", "PyQt5", "PyQt6", "pyvista", "pyvistaqt", "vtkmodules",
              "tkinter", "matplotlib", "IPython"],
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data)

exe = EXE(
    pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name="Photo2Print",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    runtime_tmpdir=None,
    console=True,            # muestra la URL local; cerrar la ventana cierra la app
    icon=None,
)
