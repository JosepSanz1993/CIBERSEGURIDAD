#!/usr/bin/env bash
# Construye Photo2Print.app (autocontenida) para macOS. Se hace UNA vez.
# Necesita Python 3.10-3.12 e internet. La .app resultante no requiere instalar nada.
cd "$(dirname "$0")/../.." || exit 1
echo "============================================================"
echo "  Construir Photo2Print.app para macOS"
echo "============================================================"

PY="$(command -v python3 || command -v python)"
if [ -z "$PY" ]; then
  echo "[ERROR] Instala Python 3.10-3.12 desde https://www.python.org/downloads/macos/"
  read -p "Pulsa Enter para cerrar..."; exit 1
fi
"$PY" --version

echo "[1/4] Entorno de construccion..."
"$PY" -m venv .build-venv || { echo "[ERROR] no se pudo crear .build-venv"; read -p "Enter"; exit 1; }
VPY=".build-venv/bin/python"

echo "[2/4] Dependencias + PyInstaller (puede tardar)..."
"$VPY" -m pip install --upgrade pip
"$VPY" -m pip install -r requirements-web.txt pyinstaller > build_log.txt 2>&1 || { echo "[ERROR] pip fallo; revisa build_log.txt"; read -p "Enter"; exit 1; }

echo "[3/4] Empaquetando .app (unos minutos)..."
"$VPY" -m PyInstaller installers/exe/photo2print_web_macos.spec --noconfirm >> build_log.txt 2>&1 || { echo "[ERROR] PyInstaller fallo; revisa build_log.txt"; read -p "Enter"; exit 1; }

if [ ! -d "dist/Photo2Print.app" ]; then
  echo "[ERROR] no se genero dist/Photo2Print.app  (revisa build_log.txt)"
  read -p "Pulsa Enter para cerrar..."; exit 1
fi

echo "[4/4] Preparando la app..."
rm -rf "Photo2Print.app"
cp -R "dist/Photo2Print.app" "Photo2Print.app"
# Quita el atributo de cuarentena para que Gatekeeper no la bloquee
xattr -cr "Photo2Print.app" 2>/dev/null

echo ""
echo "============================================================"
echo "  LISTO.  Se ha creado:  Photo2Print.app"
echo ""
echo "  Abrela con DOBLE CLIC. Se abrira sola en tu navegador."
echo "  (La primera vez, si macOS la bloquea: clic derecho > Abrir)."
echo "  Para cerrarla: clic derecho en su icono del Dock > Salir."
echo ""
echo "  Puedes mover Photo2Print.app a Aplicaciones o a otro Mac."
echo "============================================================"
echo ""
echo "Abriendola ahora para probar..."
open "Photo2Print.app"
read -p "Pulsa Enter para cerrar esta ventana..."
