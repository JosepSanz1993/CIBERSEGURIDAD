# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec para Photo2Print en **macOS**: genera un .app (bundle).

A diferencia del binario "pelado", un .app se abre con doble clic en Finder y
arranca la interfaz web (abre el navegador). Incluye Python y las dependencias
ligeras; no requiere instalar nada.

Construir (desde la RAÍZ del proyecto, en macOS):
    pyinstaller installers/exe/photo2print_web_macos.spec --noconfirm

Salida:  dist/Photo2Print.app
"""
from PyInstaller.utils.hooks import collect_all
import os

ROOT = os.path.abspath(os.path.join(SPECPATH, "..", ".."))

datas, binaries, hidden = [], [], []
for pkg in ("trimesh", "scipy", "numpy", "skimage", "shapely",
            "fast_simplification", "PIL", "lxml", "pillow_heif"):
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hidden += h
    except Exception:
        pass
hidden += ["app", "app.webapp", "app.pipeline", "app.exporters"]

a = Analysis(
    [os.path.join(ROOT, "run_web.py")],
    pathex=[ROOT],
    binaries=binaries,
    datas=datas,
    hiddenimports=hidden,
    excludes=["PySide6", "PyQt5", "PyQt6", "pyvista", "pyvistaqt", "vtkmodules",
              "tkinter", "matplotlib", "IPython"],
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data)

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="Photo2Print",
    debug=False,
    strip=False,
    upx=False,
    console=False,             # app de ventana: se abre con doble clic
    icon=None,
)
coll = COLLECT(
    exe, a.binaries, a.zipfiles, a.datas,
    strip=False, upx=False, name="Photo2Print",
)
app = BUNDLE(
    coll,
    name="Photo2Print.app",
    icon=None,
    bundle_identifier="com.photo2print.web",
    info_plist={
        "NSHighResolutionCapable": True,
        "CFBundleShortVersionString": "0.1.0",
        "LSMinimumSystemVersion": "11.0",
        # No lo marcamos como agente en segundo plano: así aparece en el Dock
        # y se puede cerrar con clic derecho sobre su icono > Salir.
    },
)
