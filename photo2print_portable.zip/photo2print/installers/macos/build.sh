#!/usr/bin/env bash
# Construye Photo2Print.app en macOS (Intel o Apple Silicon).
# Uso (desde la raíz del proyecto):
#     bash installers/macos/build.sh
set -euo pipefail

echo "== Creando entorno virtual =="
python3 -m venv .venv
source .venv/bin/activate

echo "== Instalando dependencias =="
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install pyinstaller

echo "== Empaquetando con PyInstaller =="
pyinstaller installers/macos/photo2print_macos.spec --noconfirm

echo "== Listo =="
echo "App en: dist/Photo2Print.app"
echo "Para crear un DMG:  hdiutil create -volname Photo2Print -srcfolder dist/Photo2Print.app -ov -format UDZO Photo2Print.dmg"
