# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec para Photo2Print (macOS: .app bundle).

Ejecuta desde la RAÍZ del proyecto:
    pyinstaller installers/macos/photo2print_macos.spec --noconfirm
"""
from PyInstaller.utils.hooks import collect_all

datas, binaries, hidden = [], [], []
_PACKAGES = [
    "trimesh", "scipy", "numpy", "skimage", "shapely",
    "fast_simplification", "pyvista", "pyvistaqt", "vtkmodules",
    "PIL", "pillow_heif", "rembg", "onnxruntime", "manifold3d",
]
for pkg in _PACKAGES:
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hidden += h
    except Exception:
        pass

a = Analysis(
    ["../../run.py"],
    pathex=["../.."],
    binaries=binaries,
    datas=datas,
    hiddenimports=hidden,
    excludes=["tkinter"],
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data)

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="Photo2Print",
    debug=False,
    strip=False,
    upx=False,
    console=False,
)
coll = COLLECT(
    exe, a.binaries, a.zipfiles, a.datas,
    strip=False, upx=False, name="Photo2Print",
)
app = BUNDLE(
    coll,
    name="Photo2Print.app",
    icon=None,                 # coloca aquí tu .icns si tienes uno
    bundle_identifier="com.tuempresa.photo2print",
    info_plist={
        "NSHighResolutionCapable": True,
        "CFBundleShortVersionString": "0.1.0",
        "LSMinimumSystemVersion": "11.0",
    },
)
