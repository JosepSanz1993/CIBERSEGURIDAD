# Crear la app para macOS

## Requisitos
- macOS 11 o superior (Intel o Apple Silicon)
- Python 3.10–3.12 (recomendado el de [python.org](https://www.python.org/downloads/macos/) o Homebrew)
- Xcode Command Line Tools: `xcode-select --install`

## Pasos rápidos
Desde la raíz del proyecto:

```bash
bash installers/macos/build.sh
```

Genera `dist/Photo2Print.app`. Para distribuir cómodamente, crea un DMG:

```bash
hdiutil create -volname Photo2Print -srcfolder dist/Photo2Print.app -ov -format UDZO Photo2Print.dmg
```

## Apple Silicon vs Intel
PyInstaller genera un binario para la arquitectura de la máquina donde
compilas. Para cubrir ambas:
- Compila en un Mac Intel **y** en uno Apple Silicon, o
- Usa un Mac Apple Silicon y compila también bajo Rosetta para Intel.
Un binario universal completo requiere que **todas** las ruedas (torch, vtk,
etc.) sean universal2; no todas lo son, por eso se recomienda compilar por
arquitectura.

## Firma y notarización (evita "app de desarrollador no identificado")
Requiere **tu** cuenta de Apple Developer (99 $/año) y tus certificados. No es
automatizable sin ellos. Resumen:

```bash
# Firmar
codesign --deep --force --options runtime \
  --sign "Developer ID Application: TU NOMBRE (TEAMID)" dist/Photo2Print.app

# Notarizar (requiere notarytool configurado con tu Apple ID)
xcrun notarytool submit Photo2Print.dmg --keychain-profile "AC_PASSWORD" --wait

# Grapar el ticket
xcrun stapler staple Photo2Print.dmg
```

> Sin firma/notarización, el usuario puede abrirla con clic derecho → "Abrir"
> la primera vez (Gatekeeper). Es esperable en software propio sin firmar.

## Problemas frecuentes
- **"Photo2Print.app is damaged"**: suele ser Gatekeeper con app sin firmar;
  `xattr -cr dist/Photo2Print.app` limpia atributos de cuarentena en local.
- **Falta libvtk/Qt al abrir**: reejecuta el build; el `.spec` recoge
  submódulos de `pyvista`/`vtkmodules`.
