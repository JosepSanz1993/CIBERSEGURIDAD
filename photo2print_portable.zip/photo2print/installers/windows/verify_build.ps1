# Comprueba que el ejecutable ya construido arranca y carga las librerías
# críticas dentro del paquete. Uso (desde la raíz del proyecto):
#     .\installers\windows\verify_build.ps1

$ErrorActionPreference = "Stop"
$exe = "dist\Photo2Print\Photo2Print.exe"

if (-not (Test-Path $exe)) {
    Write-Host "No se encuentra $exe. Ejecuta primero build.ps1." -ForegroundColor Red
    exit 1
}

Write-Host "== Comprobando el paquete ==" -ForegroundColor Cyan
# Arranca la app en modo self-check (no abre ventana): valida imports internos.
& $exe --selfcheck
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: el ejecutable carga las librerías críticas." -ForegroundColor Green
} else {
    Write-Host "FALLO: revisa build_windows.md (sección solución de problemas)." -ForegroundColor Red
    exit $LASTEXITCODE
}
