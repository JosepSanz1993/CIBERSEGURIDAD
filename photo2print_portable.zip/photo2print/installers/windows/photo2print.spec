# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec para Photo2Print (Windows).

Genera un ejecutable en carpeta (onedir). Ejecuta desde la RAÍZ del proyecto:

    pyinstaller installers/windows/photo2print.spec --noconfirm

Recolecta de forma robusta las dependencias que la app usa en ejecución,
incluidas las que llevan DLLs o datos (shapely→GEOS, scikit-image, VTK).
"""
from PyInstaller.utils.hooks import collect_all

block_cipher = None

datas, binaries, hidden = [], [], []

# Paquetes que hay que recoger por completo (código + datos + DLLs).
#  - núcleo geométrico: trimesh, scipy, numpy
#  - Fase 2: scikit-image (marching cubes del visual hull)
#  - Fase 3: fast_simplification (decimación)
#  - Fase 4: shapely (troceado por cama; trae DLLs de GEOS)
#  - visor 3D: pyvista, pyvistaqt, vtkmodules
#  - imágenes: PIL (incluye plugins como HEIF si está pillow-heif)
_PACKAGES = [
    "trimesh", "scipy", "numpy", "skimage", "shapely",
    "fast_simplification", "pyvista", "pyvistaqt", "vtkmodules",
    "PIL",
    # opcionales (si el usuario los instaló, se incluyen; si no, se ignoran):
    "pillow_heif", "rembg", "onnxruntime", "manifold3d",
]
for pkg in _PACKAGES:
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hidden += h
    except Exception:
        pass  # paquete no instalado: se omite sin romper el build

a = Analysis(
    ["..\\..\\run.py"],
    pathex=["..\\.."],
    binaries=binaries,
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="Photo2Print",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,                 # UPX desactivado: puede corromper DLLs de VTK
    console=False,             # app de ventana (sin consola)
    icon=None,                 # coloca aquí tu .ico si tienes uno
)
coll = COLLECT(
    exe, a.binaries, a.zipfiles, a.datas,
    strip=False, upx=False, upx_exclude=[], name="Photo2Print",
)
