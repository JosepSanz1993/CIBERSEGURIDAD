# Construye el ejecutable de Photo2Print en Windows.
# Uso (desde la raíz del proyecto, PowerShell):
#     .\installers\windows\build.ps1

$ErrorActionPreference = "Stop"

Write-Host "== Creando entorno virtual ==" -ForegroundColor Cyan
python -m venv .venv
.\.venv\Scripts\Activate.ps1

Write-Host "== Instalando dependencias ==" -ForegroundColor Cyan
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install pyinstaller

Write-Host "== Empaquetando con PyInstaller ==" -ForegroundColor Cyan
pyinstaller installers\windows\photo2print.spec --noconfirm

Write-Host "== Listo ==" -ForegroundColor Green
Write-Host "Ejecutable en: dist\Photo2Print\Photo2Print.exe"
Write-Host ""
Write-Host "Para un instalador con asistente, usa Inno Setup apuntando a dist\Photo2Print (ver build_windows.md)."
