# Crear el instalador para Windows

Guía para generar un ejecutable/instalador de Photo2Print en **Windows 10/11 (64-bit)**.

## Requisitos
- Windows 10/11 (64 bits)
- **Python 3.10–3.12** (marca "Add Python to PATH" al instalarlo)
- Conexión a internet la primera vez (para descargar dependencias)
- (Opcional) [Inno Setup](https://jrsoftware.org/isinfo.php) para un instalador con asistente

## Pasos rápidos
Desde la raíz del proyecto, en **PowerShell**:

```powershell
.\installers\windows\build.ps1
```

Esto:
1. crea un entorno virtual `.venv`,
2. instala `requirements.txt` (incluye lo necesario para todas las fases),
3. instala PyInstaller,
4. empaqueta con `installers\windows\photo2print.spec`.

Resultado: **`dist\Photo2Print\Photo2Print.exe`** (carpeta autónoma). Puedes
comprimir `dist\Photo2Print` en un ZIP y distribuirla tal cual, o crear un
instalador con Inno Setup (más abajo).

## Qué dependencias se empaquetan
El `.spec` recoge automáticamente (con `collect_all`) todo lo que la app usa en
ejecución, **incluidas DLLs y datos**:
- Núcleo: `numpy`, `scipy`, `trimesh`, `Pillow`
- Fase 2 (volumen multivista): **`scikit-image`** (marching cubes del visual hull)
- Fase 3 (postprocesado): **`fast-simplification`** (decimación)
- Fase 4 (impresión): **`shapely`** (troceado por cama; trae las DLLs de **GEOS**)
- Visor 3D: `pyvista`, `pyvistaqt`, `vtkmodules` (VTK)
- GUI: `PySide6`

> Las opcionales de IA (`rembg`, `onnxruntime`, `torch`) **no** se instalan por
> defecto. Si quieres incluirlas en el .exe, instálalas **antes** de ejecutar
> el build (el `.spec` las detecta y las empaqueta si están presentes). Ten en
> cuenta que aumentan mucho el tamaño (varios GB con torch).

## Comprobar que el .exe arranca bien
Tras el build, valida el ejecutable con:

```powershell
.\installers\windows\verify_build.ps1
```

Arranca el .exe en modo comprobación y confirma que las librerías críticas
(numpy, trimesh, scipy, scikit-image, shapely, PySide6) cargan dentro del
paquete.

## Instalador con asistente (opcional, recomendado)
1. Instala Inno Setup.
2. Crea `installer.iss`:

   ```
   [Setup]
   AppName=Photo2Print
   AppVersion=0.1.0
   DefaultDirName={autopf}\Photo2Print
   DefaultGroupName=Photo2Print
   OutputBaseFilename=Photo2Print-Setup
   Compression=lzma2
   SolidCompression=yes
   ArchitecturesInstallIn64BitMode=x64

   [Files]
   Source: "dist\Photo2Print\*"; DestDir: "{app}"; Flags: recursesubdirs

   [Icons]
   Name: "{group}\Photo2Print"; Filename: "{app}\Photo2Print.exe"
   Name: "{commondesktop}\Photo2Print"; Filename: "{app}\Photo2Print.exe"
   ```

3. Compílalo con Inno Setup → genera `Photo2Print-Setup.exe`.

## Firma de código (evita el aviso SmartScreen)
Requiere **tu** certificado Authenticode (`.pfx`). No se puede automatizar sin él:

```powershell
signtool sign /f mi_certificado.pfx /p CONTRASENA /tr http://timestamp.digicert.com /td sha256 /fd sha256 "dist\Photo2Print\Photo2Print.exe"
```
> Sin firma, Windows mostrará "Editor desconocido" la primera vez (no impide instalar).

## Solución de problemas (frecuentes en Windows)
- **`ImportError: DLL load failed` con shapely/GEOS**: usa el `.spec` incluido
  (hace `collect_all("shapely")`, que arrastra las DLLs). Reinstala shapely con
  `pip install --force-reinstall shapely` si persiste.
- **Falta un módulo de scikit-image al generar el volumen**: el `.spec` ya hace
  `collect_all("skimage")`. Si editaste el spec, no quites esa entrada.
- **Error de VTK/Qt al abrir el visor 3D**: el `.spec` recoge `vtkmodules` y
  `pyvista`. Mantén **UPX desactivado** (ya lo está): UPX puede corromper las
  DLLs de VTK. El visor tiene, además, un aviso de reserva si VTK no carga.
- **El antivirus marca el .exe**: falso positivo típico de PyInstaller; firmar
  el ejecutable lo reduce.
- **`Failed to execute script`**: reconstruye con consola para ver el error real
  cambiando `console=False` a `console=True` en el `.spec` temporalmente.
- **Rendimiento**: la reconstrucción multivista (visual hull) es intensiva; en
  equipos modestos usa resolución 64–96.

## Notas
- El .exe es de 64 bits (las ruedas de numpy/scipy/VTK lo son).
- La app funciona **sin GPU ni IA** (métodos de reserva). La IA es opcional.
