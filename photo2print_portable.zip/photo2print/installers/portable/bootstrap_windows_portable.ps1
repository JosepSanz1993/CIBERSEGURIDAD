# ============================================================
#  Photo2Print - Modo TOTALMENTE PORTABLE en Windows
#  Descarga un Python "embebido" DENTRO de esta carpeta, de modo
#  que no se instala nada en el sistema. Tras ejecutarlo una vez,
#  usa  Photo2Print_Portable.bat  para arrancar.
#
#  Uso (clic derecho > "Ejecutar con PowerShell", o):
#     powershell -ExecutionPolicy Bypass -File installers\portable\bootstrap_windows_portable.ps1
#
#  Requiere conexion a internet SOLO la primera vez.
# ============================================================
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)  # raiz del proyecto
Set-Location $root

$pyver = "3.11.9"
$pydir = Join-Path $root "python-portable"
$pyzip = Join-Path $env:TEMP "python-embed.zip"
$getpip = Join-Path $pydir "get-pip.py"

Write-Host "== Descargando Python $pyver embebido (64-bit) ==" -ForegroundColor Cyan
$url = "https://www.python.org/ftp/python/$pyver/python-$pyver-embed-amd64.zip"
Invoke-WebRequest -Uri $url -OutFile $pyzip
if (Test-Path $pydir) { Remove-Item -Recurse -Force $pydir }
Expand-Archive -Path $pyzip -DestinationPath $pydir

# Habilita 'import site' para que pip funcione en el Python embebido
$pth = Get-ChildItem $pydir -Filter "python*._pth" | Select-Object -First 1
(Get-Content $pth.FullName) -replace '#import site','import site' | Set-Content $pth.FullName

Write-Host "== Instalando pip ==" -ForegroundColor Cyan
Invoke-WebRequest -Uri "https://bootstrap.pypa.io/get-pip.py" -OutFile $getpip
& "$pydir\python.exe" $getpip

Write-Host "== Instalando dependencias de Photo2Print ==" -ForegroundColor Cyan
& "$pydir\python.exe" -m pip install -r "$root\requirements-web.txt"

# Crea el lanzador portable que usa este Python local
$bat = @"
@echo off
cd /d "%~dp0"
echo Iniciando Photo2Print (portable)... se abrira en el navegador.
"%~dp0python-portable\python.exe" run_web.py
"@
Set-Content -Path (Join-Path $root "Photo2Print_Portable.bat") -Value $bat -Encoding ASCII

Write-Host ""
Write-Host "== LISTO ==" -ForegroundColor Green
Write-Host "Ya es portable: no se ha instalado nada en el sistema."
Write-Host "Arranca la app con:  Photo2Print_Portable.bat  (doble clic)."
Write-Host "Puedes copiar toda la carpeta a un USB y funcionara igual."
