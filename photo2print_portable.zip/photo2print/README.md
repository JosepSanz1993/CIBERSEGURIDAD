# Photo2Print — Foto a modelo 3D imprimible (Fase 1 / MVP)

Aplicación de escritorio (Windows / macOS) que convierte **una foto** en un
**modelo 3D sólido e imprimible** (STL / OBJ / 3MF), compatible con Bambu
Studio y laminadores genéricos. Procesamiento **local**; sin subir imágenes.

> Estado: **Fases 1–4**. Núcleo probado end-to-end (**40 tests**). Ver
> `documentation/ROADMAP.md` (alcance) y `documentation/NO_EJECUTADO_EN_SANDBOX.txt`.

## Qué hace hoy
- Importa JPG/PNG/WebP/BMP/TIFF y **HEIC/HEIF** (con `pillow-heif`).
- Elimina el fondo (IA `rembg` **o** método básico sin dependencias).
- **Modo Rápido (1 foto):** genera un **sólido estanco** (frente con relieve +
  espalda plana + paredes).
- **Modo Multivista (varias fotos) — Fase 2:** reconstruye un **volumen real**
  por *visual hull* y **transfiere el color**; orienta la figura de pie.
- **Postprocesado — Fase 3:** **vaciado** (ahorro de material) con drenaje,
  **decimación** (archivos ligeros) y **auto-orientación**.
- **Preparación de impresión — Fase 4:** **encaje/troceado por cama**,
  **estimación** (dimensiones, material, tiempo) y **print pack** (modelo +
  `manifest.json` + README + **vista previa PNG**).
- Repara la malla, la **escala a una altura exacta en mm** y **analiza
  imprimibilidad**.
- Visor 3D · export **STL/OBJ/3MF** (geometría) y **PLY/GLB** (con color).
- Flujo por pasos, temas claro/oscuro, autoguardado, CLI completa.

## Requisitos
- Python 3.10–3.12.
- 8 GB de RAM mínimo (16 GB cómodo). GPU opcional (acelera la IA).

## Uso portable con interfaz web (sin instalar la app)
La forma más sencilla: doble clic en **`Photo2Print.bat`** (Windows) o
**`Photo2Print.command`** (macOS). Prepara su entorno la primera vez y abre la
**interfaz en el navegador** para subir una foto y descargar el modelo. Modo
100% portable sin Python del sistema: ver `documentation/PORTABLE.md`.

Directo por consola: `python run_web.py` (web) o `python run.py` (ventana nativa).

## Ejecutar desde el código (recomendado para probar)
```bash
# 1) crea y activa un entorno virtual
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS:    source .venv/bin/activate

# 2) instala dependencias
pip install -r requirements.txt

# 3) lanza la app
python run.py
```

### Sin interfaz (CLI, útil para pruebas)
```bash
# Fase 1 — una foto
python -m app.cli mi_foto.jpg -o modelo.stl --height 120 --format stl --no-ai

# Fase 2 — multivista con color (varias fotos + ángulos) a PLY/GLB
python -m app.cli frente.jpg lado.jpg detras.jpg otro.jpg \
    --angles 0,90,180,270 --format ply -o modelo.ply --height 100 --no-ai
```
`--no-ai` fuerza los métodos básicos (sin descargar torch/rembg). En
multivista, `--resolution` controla el detalle del volumen y `--no-color` lo
desactiva.

```bash
# Fase 3 — vaciar (pared 2mm) + decimar + auto-orientar
python -m app.cli foto.jpg -o modelo.stl --height 100 --hollow 2 --drain 4 \
    --decimate 20000 --auto-orient --no-ai

# Fase 4 — generar un print pack (modelo + manifest + preview + README)
python -m app.cli foto.jpg -o modelo.3mf --height 100 --no-ai \
    --pack ./salida_pack --pack-format 3mf
```

## IA opcional (mejor calidad)
El MVP funciona **sin** modelos. Para más calidad, ver
`documentation/MODELS.md` (instalar `rembg` y/o `torch`+MiDaS y dónde se
descargan los pesos).

## Crear instaladores
- Windows: `installers/windows/build_windows.md`
- macOS: `installers/macos/build_macos.md`

## Tests
```bash
pip install -r requirements-dev.txt
pytest            # núcleo (no requiere GUI ni IA)
```

## Estructura
```
app/
  main.py            arranque de la GUI
  cli.py             modo sin interfaz
  config.py          rutas y ajustes
  system_probe.py    detección de CPU/GPU/RAM
  i18n.py            textos ES/EN
  project.py         proyecto .p2p + autosave
  pipeline/          images, segmentation, depth, reconstruct,
                     mesh_tools, print_analysis, orchestrator
  exporters/         STL / OBJ / 3MF
  ui/                main_window, steps/, widgets/, worker, theme
tests/               pruebas del núcleo
installers/          PyInstaller (windows/ y macos/)
documentation/       ARCHITECTURE, MODELS, LIMITATIONS, USER_GUIDE
```

## Licencia
Código de la app: define la que prefieras. Modelos de IA de terceros
(rembg/U²-Net, MiDaS): MIT. Revisa cada licencia antes de distribuir.
