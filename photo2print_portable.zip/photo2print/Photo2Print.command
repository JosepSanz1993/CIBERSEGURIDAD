#!/usr/bin/env bash
# Photo2Print - lanzador portable para macOS / Linux (interfaz web).
cd "$(dirname "$0")" || exit 1
PY="$(command -v python3 || command -v python)"
if [ -z "$PY" ]; then
  echo "[ERROR] No se ha encontrado Python 3. Instala 3.10-3.12 desde python.org"
  read -p "Pulsa Enter para cerrar..."; exit 1
fi
if [ ! -x ".venv/bin/python" ]; then
  echo "Primera ejecucion: creando entorno (una vez)..."
  "$PY" -m venv .venv || { echo "[ERROR] no se pudo crear .venv"; read -p "Enter"; exit 1; }
  ./.venv/bin/python -m pip install --upgrade pip
  ./.venv/bin/python -m pip install -r requirements-web.txt || { echo "[ERROR] fallo instalando deps"; read -p "Enter"; exit 1; }
fi
echo "Iniciando Photo2Print... se abrira en el navegador. Ctrl+C para salir."
./.venv/bin/python run_web.py
