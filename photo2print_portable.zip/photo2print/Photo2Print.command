#!/bin/bash
# ============================================================
#  Photo2Print para macOS  -  abre la interfaz en el navegador
#  Doble clic para usar. La primera vez prepara el entorno.
#  Esta ventana de Terminal muestra la direccion y los mensajes.
# ============================================================
cd "$(dirname "$0")" || exit 1
clear
echo "============================================================"
echo "  Photo2Print"
echo "============================================================"
echo ""

# 1) Buscar Python 3
PY=""
for c in python3.12 python3.11 python3.10 python3 python; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "[!] No se ha encontrado Python 3 en tu Mac."
  echo "    Instalalo (gratis) desde:  https://www.python.org/downloads/macos/"
  echo "    Descarga 'macOS 64-bit universal2 installer', instalalo, y vuelve"
  echo "    a abrir este archivo (Photo2Print.command)."
  echo ""
  read -p "Pulsa Enter para cerrar..."
  exit 1
fi
echo "Python detectado: $($PY --version 2>&1)"
echo ""

# 2) Preparar entorno la primera vez (ligero: sin PySide6 ni VTK)
if [ ! -x ".venv/bin/python" ]; then
  echo "Primera ejecucion: preparando el entorno (2-5 min, solo una vez)..."
  echo ""
  "$PY" -m venv .venv || { echo "[!] No se pudo crear el entorno."; read -p "Enter para cerrar..."; exit 1; }
  ./.venv/bin/python -m pip install --upgrade pip
  ./.venv/bin/python -m pip install -r requirements-web.txt
  if [ $? -ne 0 ]; then
    echo ""
    echo "[!] Fallo instalando dependencias. Comprueba tu conexion a internet."
    read -p "Enter para cerrar..."
    exit 1
  fi
  echo ""
  echo "Entorno listo."
fi

# 3) Arrancar la interfaz web (imprime la URL y abre el navegador)
echo ""
echo "Iniciando Photo2Print... se abrira en tu navegador."
echo "Manten esta ventana ABIERTA mientras uses la app."
echo "Para cerrar la app: pulsa Ctrl+C aqui, o cierra esta ventana."
echo ""
./.venv/bin/python run_web.py

echo ""
echo "La aplicacion se ha detenido."
read -p "Pulsa Enter para cerrar..."
