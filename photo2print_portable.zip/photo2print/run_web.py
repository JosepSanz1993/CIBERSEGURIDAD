#!/usr/bin/env python3
"""Lanza la interfaz gráfica web de Photo2Print.

Uso:  python run_web.py
Abre el navegador en una página local para subir una foto y generar el modelo.
"""
from app.webapp import run

if __name__ == "__main__":
    run()
