#!/usr/bin/env python3
"""Lanzador de Photo2Print. Uso:  python run.py"""
from app.main import main

if __name__ == "__main__":
    raise SystemExit(main())
