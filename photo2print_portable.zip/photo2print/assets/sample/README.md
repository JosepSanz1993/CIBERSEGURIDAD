# Imagen de muestra

`busto_demo.png` es una imagen sintética para probar la app sin buscar fotos.

Pruébala por CLI:
    python -m app.cli assets/sample/busto_demo.png -o /tmp/demo.stl --height 120 --no-ai

O ábrela desde la app en el paso "Importar".
