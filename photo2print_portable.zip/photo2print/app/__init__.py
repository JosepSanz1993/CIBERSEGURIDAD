"""Photo2Print — aplicación de escritorio foto → modelo 3D imprimible (Fase 1 MVP)."""

__version__ = "0.1.0"
__app_name__ = "Photo2Print"
