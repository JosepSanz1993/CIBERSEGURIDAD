"""Ventana principal: flujo por pasos Importar → Generar → Reparar/Exportar."""
from __future__ import annotations

import io

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget, QPushButton,
    QLabel, QMessageBox,
)

from .. import __app_name__, __version__
from ..config import AppSettings
from ..logging_setup import get_logger
from ..system_probe import SystemInfo
from .theme import stylesheet
from .steps.import_step import ImportStep
from .steps.generate_step import GenerateStep
from .steps.export_step import ExportStep

log = get_logger()

STEP_TITLES = ["Importar", "Generar", "Revisar · Reparar · Exportar"]


class MainWindow(QMainWindow):
    def __init__(self, settings: AppSettings, sysinfo: SystemInfo):
        super().__init__()
        self.settings = settings
        self.sysinfo = sysinfo
        self.setWindowTitle(f"{__app_name__} {__version__}")
        self.resize(1100, 720)

        self._build_menu()

        central = QWidget()
        root = QVBoxLayout(central)

        # barra de pasos
        self.stepbar = QHBoxLayout()
        self.step_labels: list[QLabel] = []
        for i, name in enumerate(["Importar", "Generar", "Reparar/Exportar"]):
            lbl = QLabel(f"{i+1}. {name}")
            lbl.setAlignment(Qt.AlignCenter)
            self.step_labels.append(lbl)
            self.stepbar.addWidget(lbl)
        root.addLayout(self.stepbar)

        # páginas
        self.stack = QStackedWidget()
        self.import_step = ImportStep()
        self.generate_step = GenerateStep(
            get_job=lambda: self.import_step.job(),
            device=sysinfo.device,
        )
        self.export_step = ExportStep(get_settings=lambda: self.generate_step.settings())
        self.stack.addWidget(self.import_step)
        self.stack.addWidget(self.generate_step)
        self.stack.addWidget(self.export_step)
        root.addWidget(self.stack, 1)

        # navegación
        nav = QHBoxLayout()
        self.btn_back = QPushButton("← Atrás")
        self.btn_next = QPushButton("Siguiente →")
        self.btn_back.clicked.connect(lambda: self._go(self.stack.currentIndex() - 1))
        self.btn_next.clicked.connect(lambda: self._go(self.stack.currentIndex() + 1))
        nav.addWidget(self.btn_back)
        nav.addStretch(1)
        nav.addWidget(self.btn_next)
        root.addLayout(nav)

        self.setCentralWidget(central)

        # señales entre pasos
        self.generate_step.generated.connect(self._on_generated)

        self.apply_theme(settings.theme)
        self._go(0)

    # ---- menú ----
    def _build_menu(self) -> None:
        m = self.menuBar()
        file_menu = m.addMenu("Archivo")
        act_new = QAction("Nuevo proyecto", self); act_new.triggered.connect(self._new_project)
        file_menu.addAction(act_new)
        file_menu.addSeparator()
        act_quit = QAction("Salir", self); act_quit.triggered.connect(self.close)
        file_menu.addAction(act_quit)

        view_menu = m.addMenu("Ver")
        act_theme = QAction("Cambiar tema claro/oscuro", self)
        act_theme.triggered.connect(self._toggle_theme)
        view_menu.addAction(act_theme)

        help_menu = m.addMenu("Ayuda")
        act_about = QAction("Acerca de", self); act_about.triggered.connect(self._about)
        help_menu.addAction(act_about)
        act_sys = QAction("Información del sistema", self)
        act_sys.triggered.connect(self._show_sysinfo)
        help_menu.addAction(act_sys)

    # ---- navegación ----
    def _go(self, index: int) -> None:
        index = max(0, min(self.stack.count() - 1, index))
        if index == 1 and not self.import_step.is_ready():
            QMessageBox.information(self, "Falta imagen", "Importa una imagen antes de continuar.")
            return
        self.stack.setCurrentIndex(index)
        self.btn_back.setEnabled(index > 0)
        self.btn_next.setEnabled(index < self.stack.count() - 1)
        for i, lbl in enumerate(self.step_labels):
            weight = "700" if i == index else "400"
            lbl.setStyleSheet(f"font-weight:{weight};")

    def _on_generated(self, result) -> None:
        self.export_step.set_mesh(result.mesh)
        self._autosave(result.mesh)
        self._go(2)

    # ---- proyecto / autosave ----
    def _new_project(self) -> None:
        self.import_step.rgb = None
        self.import_step.image_path = None
        self.import_step.mask = None
        self.import_step.view.clear_image()
        self.export_step.set_mesh(None)
        self.generate_step.viewer.clear()
        self._go(0)

    def _autosave(self, mesh) -> None:
        try:
            from ..project import Project
            proj = Project(
                name=self.import_step.image_path or "Proyecto",
                model_type=self.import_step.model_type(),
                image_paths=[self.import_step.image_path] if self.import_step.image_path else [],
                print_settings=self.generate_step.settings(),
            )
            buf = io.BytesIO()
            mesh.export(buf, file_type="stl")
            proj.autosave(buf.getvalue())
        except Exception as exc:  # noqa: BLE001
            log.warning("Autosave falló: %s", exc)

    # ---- apariencia / info ----
    def apply_theme(self, theme: str) -> None:
        self.setStyleSheet(stylesheet(theme))

    def _toggle_theme(self) -> None:
        self.settings.theme = "light" if self.settings.theme == "dark" else "dark"
        self.settings.save()
        self.apply_theme(self.settings.theme)

    def _about(self) -> None:
        QMessageBox.information(
            self, "Acerca de",
            f"{__app_name__} {__version__}\n\n"
            "Convierte fotos en modelos 3D imprimibles (Fase 1 / MVP).\n"
            "Procesamiento local. Sin envío de imágenes sin permiso.",
        )

    def _show_sysinfo(self) -> None:
        info = self.sysinfo.to_dict()
        text = "\n".join(f"{k}: {v}" for k, v in info.items())
        QMessageBox.information(self, "Información del sistema", text)
