"""Widget para mostrar una imagen (numpy) y opcionalmente la máscara."""
from __future__ import annotations

from typing import Optional

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import QLabel


def numpy_to_qpixmap(arr: np.ndarray) -> QPixmap:
    arr = np.ascontiguousarray(arr)
    if arr.ndim == 2:
        h, w = arr.shape
        qimg = QImage(arr.data, w, h, w, QImage.Format_Grayscale8)
    elif arr.shape[2] == 3:
        h, w, _ = arr.shape
        qimg = QImage(arr.data, w, h, 3 * w, QImage.Format_RGB888)
    else:  # RGBA
        h, w, _ = arr.shape
        qimg = QImage(arr.data, w, h, 4 * w, QImage.Format_RGBA8888)
    return QPixmap.fromImage(qimg.copy())


def overlay_mask(rgb: np.ndarray, mask: np.ndarray, alpha: float = 0.45) -> np.ndarray:
    """Superpone la máscara en verde sobre la imagen para revisión visual."""
    out = rgb[..., :3].astype(np.float32).copy()
    sel = mask > 127
    tint = np.array([60, 220, 130], np.float32)
    out[sel] = out[sel] * (1 - alpha) + tint * alpha
    return np.clip(out, 0, 255).astype(np.uint8)


class ImageView(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(320, 320)
        self._pix: Optional[QPixmap] = None
        self.setText("Sin imagen")
        self.setObjectName("Hint")

    def show_array(self, arr: np.ndarray) -> None:
        self._pix = numpy_to_qpixmap(arr)
        self._update_scaled()

    def clear_image(self) -> None:
        self._pix = None
        self.setText("Sin imagen")

    def resizeEvent(self, event):  # noqa: N802 (Qt override)
        super().resizeEvent(event)
        self._update_scaled()

    def _update_scaled(self) -> None:
        if self._pix is None:
            return
        self.setPixmap(
            self._pix.scaled(
                self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
        )
