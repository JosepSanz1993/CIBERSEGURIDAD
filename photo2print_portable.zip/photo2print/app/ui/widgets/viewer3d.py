"""Visor 3D embebido.

Usa pyvistaqt (VTK) si está disponible. Si no, muestra un aviso claro con
el comando de instalación, de modo que el resto de la app siga usable
(importar/generar/exportar funcionan sin visor).

Modos de vista: sólido, textura (color plano en Fase 1) y alámbrico.
"""
from __future__ import annotations

from typing import Optional

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel

try:
    import pyvista as pv
    from pyvistaqt import QtInteractor
    _PV_OK = True
except Exception:  # pragma: no cover - depende del entorno
    _PV_OK = False


class Viewer3D(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._current_mesh = None
        self._mode = "solid"

        if _PV_OK:
            self.plotter = QtInteractor(self)
            self.plotter.set_background("#2a2c36")
            self._layout.addWidget(self.plotter.interactor)
            self.plotter.add_axes()
        else:
            self.plotter = None
            lbl = QLabel(
                "Visor 3D no disponible.\n\n"
                "Instálalo con:\n    pip install pyvista pyvistaqt\n\n"
                "El resto de funciones (importar, generar, exportar) siguen "
                "operativas."
            )
            lbl.setObjectName("Hint")
            lbl.setWordWrap(True)
            self._layout.addWidget(lbl)

    def available(self) -> bool:
        return _PV_OK

    def set_mesh(self, trimesh_mesh) -> None:
        self._current_mesh = trimesh_mesh
        self._render()

    def set_mode(self, mode: str) -> None:
        self._mode = mode
        self._render()

    def clear(self) -> None:
        self._current_mesh = None
        if self.plotter is not None:
            self.plotter.clear()

    def _render(self) -> None:
        if not _PV_OK or self._current_mesh is None:
            return
        import numpy as np
        m = self._current_mesh
        faces = np.hstack(
            [np.full((len(m.faces), 1), 3, dtype=np.int64), m.faces]
        ).ravel()
        poly = pv.PolyData(m.vertices, faces)
        self.plotter.clear()
        style = {"solid": "surface", "texture": "surface", "wire": "wireframe"}.get(
            self._mode, "surface"
        )
        self.plotter.add_mesh(
            poly, style=style, color="#c7ccff", show_edges=(self._mode == "wire"),
            smooth_shading=True,
        )
        self.plotter.reset_camera()
        self.plotter.render()
