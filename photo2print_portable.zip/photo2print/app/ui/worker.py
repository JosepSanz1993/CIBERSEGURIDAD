"""Worker en QThread para ejecutar el pipeline sin bloquear la interfaz.

Despacha a la generación de una sola foto (Fase 1) o a la reconstrucción
multivista con color (Fase 2) según el `job` recibido. Soporta cancelación
cooperativa y emite progreso/estado.
"""
from __future__ import annotations

from PySide6.QtCore import QThread, Signal

from ..config import PrintSettings
from ..pipeline import orchestrator
from ..pipeline.orchestrator import GenerationResult, CancelledError


class GenerationWorker(QThread):
    progress = Signal(int, str)
    finished_ok = Signal(object)
    failed = Signal(str)
    cancelled = Signal()

    def __init__(self, job: dict, settings: PrintSettings, device: str = "cpu",
                 prefer_ai_depth: bool = True, prefer_rembg: bool = True,
                 postprocess: dict | None = None, parent=None):
        super().__init__(parent)
        self._job = job
        self._settings = settings
        self._device = device
        self._prefer_ai_depth = prefer_ai_depth
        self._prefer_rembg = prefer_rembg
        self._postprocess = postprocess or {}
        self._cancel = False

    def request_cancel(self) -> None:
        self._cancel = True

    def _should_cancel(self) -> bool:
        return self._cancel

    def run(self) -> None:
        try:
            mode = self._job.get("mode", "single")
            if mode == "multiview":
                result: GenerationResult = orchestrator.generate_multiview(
                    self._job["image_paths"],
                    self._settings,
                    angles=self._job.get("angles"),
                    resolution=self._job.get("resolution", 96),
                    apply_color=self._job.get("apply_color", True),
                    prefer_rembg=self._prefer_rembg,
                    progress=lambda p, m: self.progress.emit(p, m),
                    cancel=self._should_cancel,
                )
            else:
                result = orchestrator.generate(
                    self._job["image_path"],
                    self._settings,
                    device=self._device,
                    prefer_ai_depth=self._prefer_ai_depth,
                    prefer_rembg=self._prefer_rembg,
                    progress=lambda p, m: self.progress.emit(p, m),
                    cancel=self._should_cancel,
                )
            pp = self._postprocess
            if pp.get("auto_orient") or pp.get("hollow_mm", 0) or pp.get("decimate_faces", 0):
                mesh2 = orchestrator.apply_postprocess(
                    result.mesh,
                    auto_orient=pp.get("auto_orient", False),
                    hollow_mm=pp.get("hollow_mm", 0.0),
                    drain_mm=pp.get("drain_mm", 0.0),
                    decimate_faces=pp.get("decimate_faces", 0),
                    progress=lambda p, m: self.progress.emit(p, m),
                    cancel=self._should_cancel,
                )
                from ..pipeline import print_analysis
                result.mesh = mesh2
                try:
                    result.report = print_analysis.analyze(
                        mesh2, nozzle_diameter_mm=self._settings.nozzle_diameter_mm,
                        material=self._settings.material)
                except Exception:
                    pass
            self.finished_ok.emit(result)
        except CancelledError:
            self.cancelled.emit()
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))
