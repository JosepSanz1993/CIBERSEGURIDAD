"""Temas claro y oscuro (hojas de estilo Qt)."""
from __future__ import annotations

_DARK = """
* { font-size: 14px; }
QMainWindow, QWidget { background: #1e1f26; color: #e6e6ea; }
QLabel#Title { font-size: 20px; font-weight: 600; }
QLabel#Hint { color: #9aa0b4; }
QPushButton {
    background: #2c2e3a; color: #e6e6ea; border: 1px solid #3a3d4d;
    border-radius: 8px; padding: 8px 14px;
}
QPushButton:hover { background: #363949; }
QPushButton:disabled { color: #6b6f80; background: #24262f; }
QPushButton#Primary { background: #4c7dff; border: none; color: white; font-weight: 600; }
QPushButton#Primary:hover { background: #5c8bff; }
QPushButton#Primary:disabled { background: #34405f; color: #9aa4c4; }
QProgressBar {
    border: 1px solid #3a3d4d; border-radius: 8px; text-align: center;
    background: #24262f; height: 20px;
}
QProgressBar::chunk { background: #4c7dff; border-radius: 7px; }
QComboBox, QLineEdit, QDoubleSpinBox, QSpinBox {
    background: #24262f; border: 1px solid #3a3d4d; border-radius: 6px; padding: 5px;
    color: #e6e6ea;
}
QListWidget { background: #24262f; border: 1px solid #3a3d4d; border-radius: 8px; }
QTabBar::tab {
    background: #24262f; color: #b8bccc; padding: 8px 16px; border-radius: 8px; margin: 3px;
}
QTabBar::tab:selected { background: #4c7dff; color: white; }
QTextEdit { background: #14151a; color: #cfd3e0; border: 1px solid #3a3d4d; border-radius: 8px; }
"""

_LIGHT = """
* { font-size: 14px; }
QMainWindow, QWidget { background: #f5f6fa; color: #1e1f26; }
QLabel#Title { font-size: 20px; font-weight: 600; }
QLabel#Hint { color: #6b7080; }
QPushButton {
    background: #ffffff; color: #1e1f26; border: 1px solid #d3d6e0;
    border-radius: 8px; padding: 8px 14px;
}
QPushButton:hover { background: #eef0f6; }
QPushButton:disabled { color: #a7abbb; background: #f0f1f5; }
QPushButton#Primary { background: #3567f6; border: none; color: white; font-weight: 600; }
QPushButton#Primary:hover { background: #2e5ce0; }
QPushButton#Primary:disabled { background: #a9bbf6; color: #f0f2ff; }
QProgressBar {
    border: 1px solid #d3d6e0; border-radius: 8px; text-align: center;
    background: #eceef4; height: 20px;
}
QProgressBar::chunk { background: #3567f6; border-radius: 7px; }
QComboBox, QLineEdit, QDoubleSpinBox, QSpinBox {
    background: #ffffff; border: 1px solid #d3d6e0; border-radius: 6px; padding: 5px;
}
QListWidget { background: #ffffff; border: 1px solid #d3d6e0; border-radius: 8px; }
QTabBar::tab {
    background: #e9ebf2; color: #4a4e5e; padding: 8px 16px; border-radius: 8px; margin: 3px;
}
QTabBar::tab:selected { background: #3567f6; color: white; }
QTextEdit { background: #ffffff; color: #22242e; border: 1px solid #d3d6e0; border-radius: 8px; }
"""


def stylesheet(theme: str) -> str:
    return _LIGHT if theme == "light" else _DARK
