"""Paso 3: Comprobar impresión, reparar y exportar."""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QTextEdit,
    QFileDialog, QMessageBox, QComboBox,
)

from ...pipeline import mesh_tools, print_analysis
from ... import exporters


class ExportStep(QWidget):
    def __init__(self, get_settings=None, parent=None):
        super().__init__(parent)
        self._get_settings = get_settings
        self.mesh = None

        root = QVBoxLayout(self)
        title = QLabel("3 · Reparar y exportar")
        title.setObjectName("Title")
        root.addWidget(title)

        self.report_view = QTextEdit()
        self.report_view.setReadOnly(True)
        root.addWidget(self.report_view, 1)

        row = QHBoxLayout()
        self.btn_check = QPushButton("Comprobar impresión")
        self.btn_repair = QPushButton("Reparar para impresión")
        self.btn_check.clicked.connect(self._on_check)
        self.btn_repair.clicked.connect(self._on_repair)
        row.addWidget(self.btn_check)
        row.addWidget(self.btn_repair)
        root.addLayout(row)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Formato:"))
        self.fmt = QComboBox(); self.fmt.addItems(["stl", "obj", "3mf", "ply", "glb"])
        row2.addWidget(self.fmt)
        self.btn_export = QPushButton("Exportar…")
        self.btn_export.setObjectName("Primary")
        self.btn_export.clicked.connect(self._on_export)
        row2.addWidget(self.btn_export)
        self.btn_bambu = QPushButton("Abrir en Bambu Studio")
        self.btn_bambu.clicked.connect(self._on_open_bambu)
        row2.addWidget(self.btn_bambu)
        self.btn_pack = QPushButton("Guardar print pack…")
        self.btn_pack.clicked.connect(self._on_print_pack)
        row2.addWidget(self.btn_pack)
        root.addLayout(row2)

        self._last_export: Optional[Path] = None
        self._set_enabled(False)

    def set_mesh(self, mesh) -> None:
        self.mesh = mesh
        self._set_enabled(mesh is not None)
        if mesh is not None:
            # Si la malla lleva color, sugerimos un formato que lo conserve.
            try:
                from ...pipeline import texturing
                if texturing.has_color(mesh):
                    idx = self.fmt.findText("ply")
                    if idx >= 0:
                        self.fmt.setCurrentIndex(idx)
            except Exception:
                pass
            self._on_check()

    def _set_enabled(self, on: bool) -> None:
        for b in (self.btn_check, self.btn_repair, self.btn_export):
            b.setEnabled(on)
        self.btn_bambu.setEnabled(False)

    def _on_check(self) -> None:
        if self.mesh is None:
            return
        rep = print_analysis.analyze(self.mesh)
        self.report_view.setHtml(self._format_report(rep))

    def _on_repair(self) -> None:
        if self.mesh is None:
            return
        self.mesh = mesh_tools.basic_repair(self.mesh)
        self.mesh = mesh_tools.keep_largest_component(self.mesh)
        self.mesh = mesh_tools.basic_repair(self.mesh)
        self._on_check()
        QMessageBox.information(self, "Reparación", "Se ha intentado reparar la malla.")

    def _on_export(self) -> None:
        if self.mesh is None:
            return
        fmt = self.fmt.currentText()
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar modelo", f"modelo.{fmt}", f"{fmt.upper()} (*.{fmt})"
        )
        if not path:
            return
        try:
            out = exporters.export(self.mesh, path, fmt)
        except exporters.ExportError as exc:
            QMessageBox.warning(self, "Error de exportación", str(exc))
            return
        self._last_export = out
        self.btn_bambu.setEnabled(True)
        note = ""
        try:
            from ...pipeline import texturing
            has_color = texturing.has_color(self.mesh)
        except Exception:
            has_color = False
        if fmt in ("ply", "glb"):
            note = "\n\nEste formato conserva el color por vértice (para previsualizar)."
        elif has_color and fmt in ("stl", "obj", "3mf"):
            note = ("\n\nNota: este formato no guarda el color. Para conservarlo usa "
                    "PLY o GLB. Para imprimir en color (AMS) exporta la geometría e "
                    "importa el color en Bambu Studio.")
        QMessageBox.information(self, "Exportado", f"Guardado en:\n{out}{note}")

    def _on_open_bambu(self) -> None:
        if not self._last_export or not self._last_export.exists():
            return
        path = str(self._last_export)
        try:
            if platform.system() == "Windows":
                os.startfile(path)  # type: ignore[attr-defined]
            elif platform.system() == "Darwin":
                app = _find_bambu_macos()
                if app:
                    subprocess.Popen(["open", "-a", app, path])
                else:
                    subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:  # noqa: BLE001
            QMessageBox.information(
                self, "Abrir en Bambu Studio",
                "No se pudo abrir automáticamente. Abre Bambu Studio e importa "
                f"el archivo manualmente:\n{path}\n\nDetalle: {exc}",
            )

    @staticmethod
    def _format_report(rep: print_analysis.PrintReport) -> str:
        color = {"ok": "#3fbf6f", "warning": "#e0a800", "error": "#e05555"}
        lines = [
            f"<b>Imprimible:</b> {'Sí' if rep.printable else 'No (hay errores)'}<br>",
            f"<b>Dimensiones:</b> {rep.dimensions_mm[0]:.1f} × "
            f"{rep.dimensions_mm[1]:.1f} × {rep.dimensions_mm[2]:.1f} mm<br>",
            f"<b>Volumen:</b> {rep.volume_cm3:.1f} cm³ · "
            f"<b>Material aprox.:</b> {rep.est_filament_g:.0f} g<br>",
            f"<b>Soportes:</b> {'probablemente sí' if rep.needs_supports else 'mínimos'}<br><hr>",
        ]
        for i in rep.issues:
            c = color.get(i.severity, "#888")
            lines.append(f"<span style='color:{c}'>●</span> {i.message}<br>")
        return "".join(lines)


def _find_bambu_macos() -> Optional[str]:
    candidates = ["BambuStudio", "Bambu Studio"]
    for name in candidates:
        p = f"/Applications/{name}.app"
        if os.path.exists(p):
            return p
    return "BambuStudio" if shutil.which("BambuStudio") else None

    def _on_print_pack(self):
        if self.mesh is None:
            return
        from ...config import PrintSettings
        settings = self._get_settings() if self._get_settings else PrintSettings()
        out_dir = QFileDialog.getExistingDirectory(self, "Carpeta para el print pack")
        if not out_dir:
            return
        try:
            from ...pipeline import printpack
            info = printpack.export_print_pack(
                self.mesh, out_dir, settings, model_format=self.fmt.currentText())
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Error", f"No se pudo crear el print pack: {exc}")
            return
        est = info.get("estimate", {})
        QMessageBox.information(
            self, "Print pack",
            f"Guardado en:\n{info['dir']}\n\n"
            f"Piezas: {len(info['model_files'])}  ·  "
            f"Material aprox.: {est.get('filament_g','?')} g\n"
            f"Incluye manifest.json, README y preview.png",
        )
