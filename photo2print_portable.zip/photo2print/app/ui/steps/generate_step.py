"""Paso 2: Configurar tamaño/detalle y generar el modelo 3D."""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QPushButton, QComboBox,
    QDoubleSpinBox, QSpinBox, QLabel, QProgressBar, QMessageBox, QGroupBox,
)

from ...config import PrintSettings
from ..worker import GenerationWorker
from ..widgets.viewer3d import Viewer3D


class GenerateStep(QWidget):
    generated = Signal(object)   # GenerationResult

    def __init__(self, get_job, device: str = "cpu", parent=None):
        super().__init__(parent)
        self._get_job = get_job           # callable -> job dict
        self._device = device
        self._worker: Optional[GenerationWorker] = None
        self.result = None

        root = QHBoxLayout(self)

        # --- controles ---
        left = QVBoxLayout()
        title = QLabel("2 · Generar 3D")
        title.setObjectName("Title")
        left.addWidget(title)

        box = QGroupBox("Tamaño y calidad")
        form = QFormLayout(box)
        self.height = QDoubleSpinBox()
        self.height.setRange(5, 500); self.height.setValue(100); self.height.setSuffix(" mm")
        self.nozzle = QDoubleSpinBox()
        self.nozzle.setRange(0.1, 1.2); self.nozzle.setSingleStep(0.1)
        self.nozzle.setValue(0.4); self.nozzle.setSuffix(" mm")
        self.material = QComboBox(); self.material.addItems(["PLA", "PETG", "ABS", "ASA", "TPU"])
        self.detail = QSpinBox(); self.detail.setRange(1, 3); self.detail.setValue(2)
        self.smoothing = QDoubleSpinBox()
        self.smoothing.setRange(0.0, 1.0); self.smoothing.setSingleStep(0.1); self.smoothing.setValue(0.3)
        form.addRow("Altura:", self.height)
        form.addRow("Boquilla:", self.nozzle)
        form.addRow("Material:", self.material)
        form.addRow("Detalle (1-3):", self.detail)
        form.addRow("Suavizado:", self.smoothing)
        left.addWidget(box)

        # --- Postprocesado opcional (Fase 3) ---
        from PySide6.QtWidgets import QCheckBox, QGroupBox, QDoubleSpinBox, QSpinBox
        ppbox = QGroupBox("Postprocesado (opcional)")
        ppform = QFormLayout(ppbox)
        self.chk_hollow = QCheckBox("Vaciar interior")
        self.wall = QDoubleSpinBox(); self.wall.setRange(0.4, 10.0); self.wall.setValue(2.0); self.wall.setSuffix(" mm")
        self.chk_orient = QCheckBox("Auto-orientar")
        self.chk_decimate = QCheckBox("Reducir caras")
        self.dec_faces = QSpinBox(); self.dec_faces.setRange(1000, 500000); self.dec_faces.setValue(40000)
        ppform.addRow(self.chk_hollow, self.wall)
        ppform.addRow(self.chk_orient)
        ppform.addRow(self.chk_decimate, self.dec_faces)
        left.addWidget(ppbox)

        self.btn_generate = QPushButton("Generar 3D")
        self.btn_generate.setObjectName("Primary")
        self.btn_generate.clicked.connect(self._on_generate)
        left.addWidget(self.btn_generate)

        self.btn_cancel = QPushButton("Cancelar")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._on_cancel)
        left.addWidget(self.btn_cancel)

        self.progress = QProgressBar(); self.progress.setValue(0)
        left.addWidget(self.progress)
        self.status = QLabel(""); self.status.setObjectName("Hint"); self.status.setWordWrap(True)
        left.addWidget(self.status)

        # modos de vista
        modes = QHBoxLayout()
        for label, mode in [("Sólido", "solid"), ("Textura", "texture"), ("Alámbrico", "wire")]:
            b = QPushButton(label)
            b.clicked.connect(lambda _=False, m=mode: self.viewer.set_mode(m))
            modes.addWidget(b)
        left.addLayout(modes)
        left.addStretch(1)

        # --- visor ---
        self.viewer = Viewer3D()

        root.addLayout(left, 0)
        root.addWidget(self.viewer, 1)

    def settings(self) -> PrintSettings:
        return PrintSettings(
            target_height_mm=self.height.value(),
            nozzle_diameter_mm=self.nozzle.value(),
            material=self.material.currentText(),
            detail_level=self.detail.value(),
            smoothing=self.smoothing.value(),
        )

    def _on_generate(self) -> None:
        job = self._get_job()
        if job.get("mode") == "multiview":
            if len(job.get("image_paths", [])) < 2:
                QMessageBox.information(self, "Faltan fotos", "Añade 2 o más fotos para multivista.")
                return
        elif not job.get("image_path"):
            QMessageBox.information(self, "Falta imagen", "Importa una imagen primero.")
            return
        self.btn_generate.setEnabled(False)
        self.btn_cancel.setEnabled(True)
        self.progress.setValue(0)
        postprocess = {
            "auto_orient": self.chk_orient.isChecked(),
            "hollow_mm": self.wall.value() if self.chk_hollow.isChecked() else 0.0,
            "decimate_faces": self.dec_faces.value() if self.chk_decimate.isChecked() else 0,
        }
        self._worker = GenerationWorker(job, self.settings(), device=self._device,
                                        postprocess=postprocess)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished_ok.connect(self._on_done)
        self._worker.failed.connect(self._on_failed)
        self._worker.cancelled.connect(self._on_cancelled)
        self._worker.start()

    def _on_cancel(self) -> None:
        if self._worker:
            self._worker.request_cancel()
            self.status.setText("Cancelando…")

    def _on_progress(self, pct: int, msg: str) -> None:
        self.progress.setValue(pct)
        self.status.setText(msg)

    def _on_done(self, result) -> None:
        self.result = result
        self.viewer.set_mesh(result.mesh)
        self._reset_buttons()
        warn = "\n".join(f"• {w}" for w in result.warnings)
        self.status.setText("Modelo generado.\n" + warn)
        self.generated.emit(result)

    def _on_failed(self, msg: str) -> None:
        self._reset_buttons()
        self.status.setText("")
        QMessageBox.warning(self, "No se pudo generar", msg)

    def _on_cancelled(self) -> None:
        self._reset_buttons()
        self.status.setText("Proceso cancelado.")
        self.progress.setValue(0)

    def _reset_buttons(self) -> None:
        self.btn_generate.setEnabled(True)
        self.btn_cancel.setEnabled(False)
