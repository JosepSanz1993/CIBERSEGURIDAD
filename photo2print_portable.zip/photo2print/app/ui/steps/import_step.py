"""Paso 1: Importar foto(s), elegir modo y tipo, y revisar la máscara.

Modo "Rápido" (Fase 1): una sola foto → relieve/sólido con espalda plana.
Modo "Multivista" (Fase 2): varias fotos alrededor del objeto con sus ángulos
→ reconstrucción volumétrica con color.
"""
from __future__ import annotations

from typing import Optional

import numpy as np
from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox, QLabel,
    QFileDialog, QMessageBox, QListWidget, QListWidgetItem, QDoubleSpinBox,
    QGroupBox,
)

from ...config import SUPPORTED_IMAGE_EXTS
from ...pipeline import images as images_mod
from ...pipeline import segmentation, cameras
from ..widgets.image_view import ImageView, overlay_mask

MODEL_TYPE_LABELS = {
    "persona_completa": "Persona de cuerpo completo",
    "busto": "Busto",
    "cabeza": "Cabeza o rostro",
    "mascota": "Mascota",
    "objeto": "Objeto",
    "figura_artistica": "Figura artística",
    "relieve": "Relieve o litofanía",
}


class ImportStep(QWidget):
    ready_changed = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rgb: Optional[np.ndarray] = None
        self.mask: Optional[np.ndarray] = None
        self.image_path: Optional[str] = None
        self._multi: list[dict] = []   # [{"path","angle"}]

        root = QHBoxLayout(self)
        left = QVBoxLayout()

        title = QLabel("1 · Importar y revisar")
        title.setObjectName("Title")
        left.addWidget(title)

        left.addWidget(QLabel("Modo de reconstrucción:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Rápido — 1 foto (relieve/sólido)", "single")
        self.mode_combo.addItem("Multivista — varias fotos (volumen + color)", "multiview")
        self.mode_combo.currentIndexChanged.connect(self._on_mode_changed)
        left.addWidget(self.mode_combo)

        left.addWidget(QLabel("Tipo de modelo:"))
        self.type_combo = QComboBox()
        for key, label in MODEL_TYPE_LABELS.items():
            self.type_combo.addItem(label, key)
        left.addWidget(self.type_combo)

        # --- modo single ---
        self.single_box = QGroupBox("Foto única")
        sb = QVBoxLayout(self.single_box)
        self.btn_import = QPushButton("Importar imagen…")
        self.btn_import.clicked.connect(self._on_import_single)
        sb.addWidget(self.btn_import)
        self.btn_removebg = QPushButton("Eliminar fondo")
        self.btn_removebg.setEnabled(False)
        self.btn_removebg.clicked.connect(self._on_remove_bg)
        sb.addWidget(self.btn_removebg)
        row = QHBoxLayout()
        self.btn_grow = QPushButton("Ampliar selección")
        self.btn_shrink = QPushButton("Reducir selección")
        self.btn_grow.setEnabled(False); self.btn_shrink.setEnabled(False)
        self.btn_grow.clicked.connect(lambda: self._adjust_mask(+1))
        self.btn_shrink.clicked.connect(lambda: self._adjust_mask(-1))
        row.addWidget(self.btn_grow); row.addWidget(self.btn_shrink)
        sb.addLayout(row)
        left.addWidget(self.single_box)

        # --- modo multivista ---
        self.multi_box = QGroupBox("Fotos multivista (2 o más)")
        mb = QVBoxLayout(self.multi_box)
        self.list_widget = QListWidget()
        self.list_widget.currentRowChanged.connect(self._on_multi_selection)
        mb.addWidget(self.list_widget)
        addrow = QHBoxLayout()
        self.btn_add = QPushButton("Añadir foto(s)…")
        self.btn_add.clicked.connect(self._on_add_multi)
        self.btn_del = QPushButton("Quitar")
        self.btn_del.clicked.connect(self._on_del_multi)
        addrow.addWidget(self.btn_add); addrow.addWidget(self.btn_del)
        mb.addLayout(addrow)
        angrow = QHBoxLayout()
        angrow.addWidget(QLabel("Ángulo de la foto seleccionada:"))
        self.angle_spin = QDoubleSpinBox()
        self.angle_spin.setRange(0, 359.9); self.angle_spin.setSuffix(" °")
        self.angle_spin.valueChanged.connect(self._on_angle_changed)
        angrow.addWidget(self.angle_spin)
        mb.addLayout(angrow)
        self.btn_autoangles = QPushButton("Repartir ángulos automáticamente")
        self.btn_autoangles.clicked.connect(self._auto_angles)
        mb.addWidget(self.btn_autoangles)
        left.addWidget(self.multi_box)

        self.hint = QLabel(
            "Consejo: fotos nítidas, sujeto centrado y buen contraste con el "
            "fondo. En multivista, gira el objeto en pasos regulares."
        )
        self.hint.setObjectName("Hint"); self.hint.setWordWrap(True)
        left.addWidget(self.hint)
        left.addStretch(1)

        self.view = ImageView()
        root.addLayout(left, 0)
        root.addWidget(self.view, 1)

        self._on_mode_changed()

    # ---- modo ----
    def mode(self) -> str:
        return self.mode_combo.currentData()

    def _on_mode_changed(self) -> None:
        multi = self.mode() == "multiview"
        self.multi_box.setVisible(multi)
        self.single_box.setVisible(not multi)
        self.ready_changed.emit(self.is_ready())

    # ---- single ----
    def _on_import_single(self) -> None:
        exts = " ".join(f"*{e}" for e in SUPPORTED_IMAGE_EXTS)
        path, _ = QFileDialog.getOpenFileName(self, "Selecciona una imagen", "", f"Imágenes ({exts})")
        if not path:
            return
        try:
            self.rgb = images_mod.to_rgb(images_mod.load_image(path))
        except images_mod.ImageLoadError as exc:
            QMessageBox.warning(self, "No se pudo abrir", str(exc)); return
        self.image_path = path
        self.mask = None
        self.view.show_array(self.rgb)
        self.btn_removebg.setEnabled(True)
        self.btn_grow.setEnabled(False); self.btn_shrink.setEnabled(False)
        self.ready_changed.emit(True)

    def _on_remove_bg(self) -> None:
        if self.rgb is None:
            return
        try:
            self.mask, method = segmentation.segment(self.rgb)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Error", f"No se pudo segmentar: {exc}"); return
        self.view.show_array(overlay_mask(self.rgb, self.mask))
        self.btn_grow.setEnabled(True); self.btn_shrink.setEnabled(True)
        note = "" if method == "rembg" else "  (método básico; instala 'rembg' para más calidad)"
        self.hint.setText(f"Máscara generada{note}. Amplía/reduce si hace falta.")

    def _adjust_mask(self, direction: int) -> None:
        if self.mask is None:
            return
        self.mask = segmentation.refine_mask(self.mask, grow=direction)
        self.view.show_array(overlay_mask(self.rgb, self.mask))

    # ---- multivista ----
    def _on_add_multi(self) -> None:
        exts = " ".join(f"*{e}" for e in SUPPORTED_IMAGE_EXTS)
        paths, _ = QFileDialog.getOpenFileNames(self, "Selecciona fotos", "", f"Imágenes ({exts})")
        for p in paths:
            self._multi.append({"path": p, "angle": 0.0})
        self._refresh_multi_list()
        self._auto_angles()
        self.ready_changed.emit(self.is_ready())

    def _on_del_multi(self) -> None:
        r = self.list_widget.currentRow()
        if 0 <= r < len(self._multi):
            self._multi.pop(r)
            self._refresh_multi_list()
            self.ready_changed.emit(self.is_ready())

    def _refresh_multi_list(self) -> None:
        self.list_widget.clear()
        for i, item in enumerate(self._multi):
            name = item["path"].split("/")[-1].split("\\")[-1]
            QListWidgetItem(f"{i+1}. {name}  ({item['angle']:.0f}°)", self.list_widget)

    def _on_multi_selection(self, row: int) -> None:
        if 0 <= row < len(self._multi):
            self.angle_spin.blockSignals(True)
            self.angle_spin.setValue(self._multi[row]["angle"])
            self.angle_spin.blockSignals(False)
            try:
                rgb = images_mod.to_rgb(images_mod.load_image(self._multi[row]["path"]))
                self.view.show_array(rgb)
            except Exception:
                pass

    def _on_angle_changed(self, val: float) -> None:
        r = self.list_widget.currentRow()
        if 0 <= r < len(self._multi):
            self._multi[r]["angle"] = float(val)
            self._refresh_multi_list()
            self.list_widget.setCurrentRow(r)

    def _auto_angles(self) -> None:
        n = len(self._multi)
        if n == 0:
            return
        for item, ang in zip(self._multi, cameras.default_angles(n)):
            item["angle"] = ang
        self._refresh_multi_list()

    # ---- API para otros pasos ----
    def model_type(self) -> str:
        return self.type_combo.currentData()

    def is_ready(self) -> bool:
        if self.mode() == "multiview":
            return len(self._multi) >= 2
        return self.rgb is not None

    def job(self) -> dict:
        if self.mode() == "multiview":
            return {
                "mode": "multiview",
                "image_paths": [m["path"] for m in self._multi],
                "angles": [m["angle"] for m in self._multi],
                "apply_color": True,
            }
        return {"mode": "single", "image_path": self.image_path}
