"""Modelo de cámara para reconstrucción multivista (Fase 2).

Se asume un montaje tipo **plato giratorio** (turntable) con proyección
**ortográfica**: el sujeto rota sobre el eje vertical (Y) y se toman varias
fotos a ángulos conocidos o estimados. Es una aproximación deliberada: evita
tener que calibrar cámaras (intrínsecos/extrínsecos), que es frágil con fotos
de consumo, y funciona bien cuando el objeto se fotografía de forma
razonablemente centrada y a cierta distancia.

Convenio de coordenadas (cubo normalizado [-1, 1]^3):
  X derecha · Y arriba (altura) · Z hacia la cámara frontal (ángulo 0).
Un ángulo θ representa girar el objeto θ grados alrededor de Y.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class View:
    """Una vista = imagen + máscara del sujeto + ángulo del plato (grados)."""
    rgb: np.ndarray            # (H, W, 3) uint8
    mask: np.ndarray           # (H, W) uint8 (0/255)
    angle_deg: float           # 0 = frontal; sentido antihorario visto desde arriba

    # parámetros de encuadre derivados de la silueta (se rellenan al preparar)
    cx: float = 0.0
    cy: float = 0.0
    half: float = 1.0


def prepare_view(view: View, margin: float = 0.06) -> View:
    """Calcula el encuadre de la silueta (centro y semi-extensión en px).

    Mapea el cubo normalizado del objeto al *bounding box* de la silueta,
    conservando la relación de aspecto (misma escala en X e Y). Así el carving
    es robusto a diferencias de zoom/encuadre entre fotos.
    """
    ys, xs = np.where(view.mask > 127)
    if ys.size == 0:
        raise ValueError("Una de las vistas tiene la máscara vacía.")
    x0, x1 = xs.min(), xs.max()
    y0, y1 = ys.min(), ys.max()
    view.cx = float((x0 + x1) / 2.0)
    view.cy = float((y0 + y1) / 2.0)
    half_w = (x1 - x0) / 2.0
    half_h = (y1 - y0) / 2.0
    view.half = float(max(half_w, half_h) * (1.0 + margin))
    return view


def rotate_y(points: np.ndarray, angle_deg: float) -> np.ndarray:
    """Rota puntos (N,3) alrededor del eje Y por -angle (lleva la vista al frente)."""
    t = np.radians(-angle_deg)
    c, s = np.cos(t), np.sin(t)
    x, y, z = points[:, 0], points[:, 1], points[:, 2]
    xr = x * c + z * s
    zr = -x * s + z * c
    return np.stack([xr, y, zr], axis=-1)


def project_to_pixels(points_view: np.ndarray, view: View) -> np.ndarray:
    """Proyección ortográfica de puntos ya rotados a la vista → (N,2) [col,row].

    u = X' → columna ; v = Y → fila (Y arriba, por eso la fila se invierte).
    """
    u = points_view[:, 0]
    v = points_view[:, 1]
    col = view.cx + u * view.half
    row = view.cy - v * view.half
    return np.stack([col, row], axis=-1)


def sample_mask(view: View, cols: np.ndarray, rows: np.ndarray) -> np.ndarray:
    """Devuelve booleano: ¿cada (col,row) cae dentro de la silueta?"""
    h, w = view.mask.shape[:2]
    ci = np.round(cols).astype(np.int64)
    ri = np.round(rows).astype(np.int64)
    inside_frame = (ci >= 0) & (ci < w) & (ri >= 0) & (ri < h)
    out = np.zeros(cols.shape, dtype=bool)
    idx = inside_frame
    out[idx] = view.mask[ri[idx], ci[idx]] > 127
    return out


def sample_rgb(view: View, cols: np.ndarray, rows: np.ndarray) -> np.ndarray:
    """Muestrea color RGB (N,3) con recorte a los bordes de la imagen."""
    h, w = view.rgb.shape[:2]
    ci = np.clip(np.round(cols).astype(np.int64), 0, w - 1)
    ri = np.clip(np.round(rows).astype(np.int64), 0, h - 1)
    return view.rgb[ri, ci, :3]


def default_angles(n: int) -> list[float]:
    """Ángulos equiespaciados para n fotos alrededor del objeto."""
    if n <= 0:
        return []
    return [round(360.0 * i / n, 2) for i in range(n)]
