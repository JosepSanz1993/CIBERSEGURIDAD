"""Segmentación del sujeto / eliminación de fondo.

Estrategia:
  1. Si `rembg` (ONNX, modelo U^2-Net, licencia MIT) está disponible, se usa
     para obtener una máscara de alta calidad. El modelo se descarga la
     primera vez en la carpeta de datos de la app.
  2. Si no, se aplica un fallback clásico determinista (GrabCut-like por
     color de bordes + umbral) que NO necesita descargas ni GPU. Es peor,
     pero garantiza que el MVP funcione siempre y sea testeable.

La máscara devuelta es uint8 (H, W) con 0=fondo, 255=sujeto.
"""
from __future__ import annotations

import numpy as np

from .images import to_rgb


def rembg_available() -> bool:
    try:
        import rembg  # noqa: F401
        return True
    except Exception:
        return False


def _mask_with_rembg(rgb: np.ndarray) -> np.ndarray:
    from rembg import remove  # type: ignore

    rgba = remove(rgb)  # devuelve RGBA con alfa como máscara
    alpha = np.asarray(rgba)[..., 3]
    return (alpha > 10).astype(np.uint8) * 255


def _mask_fallback(rgb: np.ndarray) -> np.ndarray:
    """Fallback sin dependencias pesadas.

    Asume que el fondo domina los bordes de la imagen. Estima el color de
    fondo con el borde y marca como sujeto los píxeles suficientemente
    distintos, luego limpia con morfología ligera y quedándose con la
    componente conexa central más grande.
    """
    rgb = to_rgb(rgb).astype(np.float32)
    h, w = rgb.shape[:2]

    border = np.concatenate([
        rgb[0, :, :], rgb[-1, :, :], rgb[:, 0, :], rgb[:, -1, :]
    ], axis=0)
    bg_color = np.median(border, axis=0)

    dist = np.linalg.norm(rgb - bg_color, axis=-1)
    thr = max(25.0, np.percentile(dist, 60))
    mask = (dist > thr).astype(np.uint8)

    mask = _binary_close(mask, iters=2)
    mask = _binary_open(mask, iters=1)
    mask = _largest_component_near_center(mask)
    mask = _fill_holes(mask)
    return (mask * 255).astype(np.uint8)


# ---- morfología / componentes mínimas en numpy (sin OpenCV) ----

def _dilate(m: np.ndarray) -> np.ndarray:
    out = m.copy()
    out[1:, :] |= m[:-1, :]
    out[:-1, :] |= m[1:, :]
    out[:, 1:] |= m[:, :-1]
    out[:, :-1] |= m[:, 1:]
    return out


def _erode(m: np.ndarray) -> np.ndarray:
    inv = 1 - m
    return 1 - _dilate(inv)


def _binary_close(m: np.ndarray, iters: int = 1) -> np.ndarray:
    for _ in range(iters):
        m = _dilate(m)
    for _ in range(iters):
        m = _erode(m)
    return m


def _binary_open(m: np.ndarray, iters: int = 1) -> np.ndarray:
    for _ in range(iters):
        m = _erode(m)
    for _ in range(iters):
        m = _dilate(m)
    return m


def _largest_component_near_center(m: np.ndarray) -> np.ndarray:
    try:
        from scipy import ndimage
    except Exception:
        return m
    labels, n = ndimage.label(m)
    if n == 0:
        return m
    h, w = m.shape
    cy, cx = h / 2.0, w / 2.0
    best_label, best_score = 0, -1.0
    for lab in range(1, n + 1):
        ys, xs = np.where(labels == lab)
        size = ys.size
        dist = np.hypot(ys.mean() - cy, xs.mean() - cx)
        score = size / (1.0 + dist)
        if score > best_score:
            best_score, best_label = score, lab
    return (labels == best_label).astype(np.uint8)


def _fill_holes(m: np.ndarray) -> np.ndarray:
    try:
        from scipy import ndimage
        return ndimage.binary_fill_holes(m).astype(np.uint8)
    except Exception:
        return m


def segment(rgb: np.ndarray, prefer_rembg: bool = True) -> tuple[np.ndarray, str]:
    """Devuelve (mask uint8, método_usado)."""
    if prefer_rembg and rembg_available():
        try:
            return _mask_with_rembg(rgb), "rembg"
        except Exception:
            pass
    return _mask_fallback(rgb), "fallback"


def refine_mask(mask: np.ndarray, grow: int = 0) -> np.ndarray:
    """Permite a la UI crecer/encoger la máscara tras revisarla."""
    m = (mask > 127).astype(np.uint8)
    if grow > 0:
        for _ in range(grow):
            m = _dilate(m)
    elif grow < 0:
        for _ in range(-grow):
            m = _erode(m)
    return (m * 255).astype(np.uint8)
