"""Reconstrucción volumétrica (Fase 2).

Dos vías nuevas frente a la Fase 1 (que aproximaba la espalda como plana):

1. `visual_hull(...)` — **space carving** a partir de varias siluetas
   alrededor del objeto (turntable ortográfico). Produce un volumen 3D real
   (con parte trasera) por intersección de siluetas y lo convierte en malla
   con marching cubes. Determinista, sin IA ni GPU.

2. `reconstruct_front_back(...)` — modo de **dos fotos** (frontal + trasera):
   combina dos mapas de profundidad en un sólido cerrado con volumen real por
   ambas caras. Más simple que multivista y muy superior a la espalda plana.

Ambas devuelven un trimesh.Trimesh en coordenadas normalizadas (se escala a
mm después con mesh_tools.scale_to_height).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import trimesh

from . import cameras
from .cameras import View


@dataclass
class VisualHullParams:
    resolution: int = 96          # nº de vóxeles por lado (calidad vs. memoria)
    margin: float = 0.06
    smooth_iters: int = 8         # suavizado laplaciano tras marching cubes
    min_views: int = 2


def _voxel_grid(resolution: int) -> tuple[np.ndarray, np.ndarray]:
    """Centros de vóxel en [-1,1]^3 y las coordenadas 1D del eje."""
    axis = np.linspace(-1.0, 1.0, resolution, dtype=np.float32)
    gx, gy, gz = np.meshgrid(axis, axis, axis, indexing="ij")
    centers = np.stack([gx.ravel(), gy.ravel(), gz.ravel()], axis=-1)
    return centers, axis


def visual_hull(views: list[View], params: VisualHullParams | None = None) -> trimesh.Trimesh:
    """Intersección de siluetas → malla estanca con volumen real."""
    params = params or VisualHullParams()
    if len(views) < params.min_views:
        raise ValueError(
            f"La reconstrucción multivista necesita al menos "
            f"{params.min_views} fotos con ángulos distintos."
        )

    for v in views:
        cameras.prepare_view(v, margin=params.margin)

    res = int(params.resolution)
    centers, _axis = _voxel_grid(res)
    occupied = np.ones(centers.shape[0], dtype=bool)

    # Carving: un vóxel sobrevive si cae dentro de TODAS las siluetas.
    for v in views:
        pv = cameras.rotate_y(centers, v.angle_deg)
        px = cameras.project_to_pixels(pv, v)
        inside = cameras.sample_mask(v, px[:, 0], px[:, 1])
        occupied &= inside
        if not occupied.any():
            raise ValueError(
                "Las siluetas no se solapan; revisa las máscaras o los ángulos "
                "de las fotos."
            )

    volume = occupied.reshape(res, res, res)
    mesh = _volume_to_mesh(volume, params.smooth_iters)
    return mesh


def _volume_to_mesh(volume: np.ndarray, smooth_iters: int) -> trimesh.Trimesh:
    """Marching cubes sobre el volumen ocupado → malla en [-1,1]^3."""
    res = volume.shape[0]
    pitch = 2.0 / (res - 1)

    padded = np.pad(volume.astype(np.float32), 1, mode="constant", constant_values=0.0)
    try:
        from skimage.measure import marching_cubes
        verts, faces, _n, _v = marching_cubes(padded, level=0.5)
        verts = (verts - 1.0) * pitch - 1.0  # deshace el pad y lleva a [-1,1]
        mesh = trimesh.Trimesh(vertices=verts, faces=faces, process=True)
    except Exception:
        # Fallback sin skimage: vóxeles como cajas (más tosco, pero válido).
        vg = trimesh.voxel.VoxelGrid(volume)
        mesh = vg.as_boxes()
        mesh.apply_scale(pitch)
        mesh.apply_translation([-1, -1, -1])

    trimesh.repair.fix_normals(mesh)
    if smooth_iters > 0:
        try:
            trimesh.smoothing.filter_taubin(mesh, iterations=smooth_iters)
        except Exception:
            pass
    return mesh


def reconstruct_front_back(
    depth_front: np.ndarray,
    mask_front: np.ndarray,
    depth_back: np.ndarray,
    mask_back: np.ndarray,
    relief_front: float = 0.5,
    relief_back: float = 0.5,
    detail_level: int = 2,
) -> trimesh.Trimesh:
    """Combina profundidad frontal y trasera en un sólido cerrado.

    La foto trasera se asume "espejada" respecto a la frontal (el sujeto se da
    la vuelta), por lo que su máscara/profundidad se voltean horizontalmente
    para alinearlas con la vista frontal.
    """
    from .reconstruct import _resample, _grid_resolution

    h, w = depth_front.shape[:2]
    res = _grid_resolution(detail_level)
    if max(h, w) >= res:
        if h >= w:
            gh, gw = res, max(2, int(round(res * w / h)))
        else:
            gw, gh = res, max(2, int(round(res * h / w)))
    else:
        gh, gw = h, w

    df = _resample(depth_front, gh, gw, order_nearest=False)
    mf = _resample((mask_front > 127).astype(np.float32), gh, gw, order_nearest=False) >= 0.5
    db = _resample(depth_back, gh, gw, order_nearest=False)[:, ::-1]
    mb = (_resample((mask_back > 127).astype(np.float32), gh, gw, order_nearest=False) >= 0.5)[:, ::-1]

    inside = mf & mb  # solo donde ambas siluetas coinciden
    if inside.sum() < 8:
        raise ValueError(
            "Las siluetas frontal y trasera apenas se solapan. Asegúrate de "
            "fotografiar el mismo sujeto centrado por delante y por detrás."
        )

    longest = max(gh, gw)
    zf = 0.05 * longest + df * (relief_front * longest)     # frente hacia +Z
    zb = -(0.05 * longest + db * (relief_back * longest))    # espalda hacia -Z

    ys, xs = np.mgrid[0:gh, 0:gw]
    X = xs.astype(np.float32)
    Y = (gh - 1 - ys).astype(np.float32)
    front = np.stack([X, Y, zf], axis=-1).reshape(-1, 3)
    back = np.stack([X, Y, zb], axis=-1).reshape(-1, 3)
    vertices = np.concatenate([front, back], axis=0)
    n = gh * gw

    def fi(y, x):
        return y * gw + x

    def bi(y, x):
        return n + y * gw + x

    cell = inside[:-1, :-1] & inside[:-1, 1:] & inside[1:, :-1] & inside[1:, 1:]
    cy, cx = np.where(cell)
    faces = []

    faces.append(np.stack([fi(cy, cx), fi(cy + 1, cx), fi(cy + 1, cx + 1)], -1))
    faces.append(np.stack([fi(cy, cx), fi(cy + 1, cx + 1), fi(cy, cx + 1)], -1))
    faces.append(np.stack([bi(cy, cx), bi(cy + 1, cx + 1), bi(cy + 1, cx)], -1))
    faces.append(np.stack([bi(cy, cx), bi(cy, cx + 1), bi(cy + 1, cx + 1)], -1))

    solid = np.zeros((gh - 1, gw - 1), dtype=bool)
    solid[cy, cx] = True

    def neighbor_solid(dy, dx):
        ny, nx = cy + dy, cx + dx
        ok = (ny >= 0) & (ny < solid.shape[0]) & (nx >= 0) & (nx < solid.shape[1])
        r = np.zeros(cy.shape, dtype=bool)
        r[ok] = solid[ny[ok], nx[ok]]
        return r

    def wall(ay, ax, by, bx, sel):
        fa, fb = fi(ay[sel], ax[sel]), fi(by[sel], bx[sel])
        ba, bb = bi(ay[sel], ax[sel]), bi(by[sel], bx[sel])
        faces.append(np.stack([fa, fb, bb], -1))
        faces.append(np.stack([fa, bb, ba], -1))

    wall(cy, cx, cy + 1, cx, ~neighbor_solid(0, -1))
    wall(cy, cx + 1, cy + 1, cx + 1, ~neighbor_solid(0, +1))
    wall(cy, cx, cy, cx + 1, ~neighbor_solid(-1, 0))
    wall(cy + 1, cx, cy + 1, cx + 1, ~neighbor_solid(+1, 0))

    all_faces = np.concatenate(faces, axis=0).astype(np.int64)
    mesh = trimesh.Trimesh(vertices=vertices, faces=all_faces, process=False)
    mesh.remove_unreferenced_vertices()
    mesh.merge_vertices()
    trimesh.repair.fix_normals(mesh)
    return mesh
