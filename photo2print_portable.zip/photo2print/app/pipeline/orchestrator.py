"""Orquestador del pipeline de generación 3D (Fase 1).

Encadena: cargar imagen -> segmentar -> profundidad -> reconstruir sólido ->
reparar -> escalar a mm -> apoyar/base -> analizar impresión.

Es agnóstico de la GUI: recibe callbacks `progress(pct, msg)` y
`should_cancel()` para poder ejecutarse en un hilo y ser cancelable.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
import trimesh

from ..config import PrintSettings
from . import images as images_mod
from . import segmentation, depth, reconstruct, mesh_tools, print_analysis

ProgressCb = Callable[[int, str], None]
CancelCb = Callable[[], bool]


class CancelledError(Exception):
    pass


@dataclass
class GenerationResult:
    mesh: trimesh.Trimesh
    mask: np.ndarray
    depth: np.ndarray
    report: print_analysis.PrintReport
    warnings: list[str]
    methods: dict[str, str]


def _tick(progress: Optional[ProgressCb], cancel: Optional[CancelCb], pct: int, msg: str):
    if cancel and cancel():
        raise CancelledError("Proceso cancelado por el usuario.")
    if progress:
        progress(pct, msg)


def generate(
    image_path: str,
    settings: PrintSettings,
    *,
    device: str = "cpu",
    prefer_ai_depth: bool = True,
    prefer_rembg: bool = True,
    max_input_side: int = 1024,
    progress: Optional[ProgressCb] = None,
    cancel: Optional[CancelCb] = None,
) -> GenerationResult:
    warnings: list[str] = []
    methods: dict[str, str] = {}

    _tick(progress, cancel, 5, "Cargando imagen…")
    rgb = images_mod.load_image(image_path)
    rgb = images_mod.to_rgb(rgb)
    rgb = images_mod.downscale_max_side(rgb, max_input_side)

    _tick(progress, cancel, 20, "Separando el sujeto del fondo…")
    mask, seg_method = segmentation.segment(rgb, prefer_rembg=prefer_rembg)
    methods["segmentation"] = seg_method
    if seg_method == "fallback":
        warnings.append(
            "Fondo eliminado con el método básico (sin IA). Revisa la máscara; "
            "instala 'rembg' para una selección más precisa."
        )

    _tick(progress, cancel, 40, "Estimando profundidad…")
    d, depth_method = depth.estimate_depth(
        rgb, device=device, prefer_ai=prefer_ai_depth
    )
    methods["depth"] = depth_method
    if depth_method == "fallback":
        warnings.append(
            "Profundidad estimada con el método básico (sin IA). Para volumen "
            "más realista instala PyTorch + MiDaS (ver documentation/MODELS.md)."
        )

    _tick(progress, cancel, 60, "Reconstruyendo el sólido 3D…")
    params = reconstruct.ReconstructParams(detail_level=settings.detail_level)
    mesh = reconstruct.reconstruct_solid(d, mask, params)
    warnings.append(
        "La parte trasera se ha aproximado como una superficie plana porque "
        "no hay fotos posteriores (modo rápido / 1 imagen)."
    )

    _tick(progress, cancel, 75, "Reparando la malla…")
    mesh = mesh_tools.basic_repair(mesh)
    mesh = mesh_tools.keep_largest_component(mesh)
    if settings.smoothing > 0:
        mesh = mesh_tools.laplacian_smooth(mesh, settings.smoothing)
        mesh = mesh_tools.basic_repair(mesh)

    _tick(progress, cancel, 88, "Ajustando tamaño y base…")
    mesh = mesh_tools.scale_to_height(mesh, settings.target_height_mm)
    mesh = mesh_tools.add_flat_base(
        mesh, settings.base_thickness_mm if settings.add_base else 0.0
    )
    mesh = mesh_tools.center_on_origin_xy(mesh)

    _tick(progress, cancel, 95, "Analizando imprimibilidad…")
    report = print_analysis.analyze(
        mesh,
        nozzle_diameter_mm=settings.nozzle_diameter_mm,
        material=settings.material,
    )

    _tick(progress, cancel, 100, "Listo.")
    return GenerationResult(
        mesh=mesh, mask=mask, depth=d, report=report,
        warnings=warnings, methods=methods,
    )


def generate_multiview(
    image_paths: list[str],
    settings: PrintSettings,
    *,
    angles: list[float] | None = None,
    resolution: int = 96,
    apply_color: bool = True,
    prefer_rembg: bool = True,
    max_input_side: int = 1024,
    progress: Optional[ProgressCb] = None,
    cancel: Optional[CancelCb] = None,
) -> GenerationResult:
    """Reconstrucción volumétrica (Fase 2) a partir de varias fotos.

    `angles` son los grados de cada foto alrededor del objeto (0 = frontal).
    Si no se dan, se asumen equiespaciados (plato giratorio regular).
    """
    from . import cameras, multiview, texturing
    from .cameras import View

    if len(image_paths) < 2:
        raise ValueError("La reconstrucción multivista necesita 2 o más fotos.")
    angles = angles or cameras.default_angles(len(image_paths))
    if len(angles) != len(image_paths):
        raise ValueError("El número de ángulos no coincide con el de fotos.")

    warnings: list[str] = []
    methods: dict[str, str] = {}
    views: list[View] = []

    seg_methods = set()
    for i, path in enumerate(image_paths):
        base = 5 + int(35 * i / len(image_paths))
        _tick(progress, cancel, base, f"Procesando foto {i+1}/{len(image_paths)}…")
        rgb = images_mod.downscale_max_side(
            images_mod.to_rgb(images_mod.load_image(path)), max_input_side
        )
        mask, seg = segmentation.segment(rgb, prefer_rembg=prefer_rembg)
        seg_methods.add(seg)
        views.append(View(rgb=rgb, mask=mask, angle_deg=float(angles[i])))
    methods["segmentation"] = "/".join(sorted(seg_methods))
    if "fallback" in seg_methods:
        warnings.append(
            "Alguna máscara se hizo con el método básico (sin IA). Siluetas "
            "limpias mejoran mucho la reconstrucción; instala 'rembg'."
        )

    _tick(progress, cancel, 45, "Reconstruyendo el volumen (space carving)…")
    mesh = multiview.visual_hull(
        views, multiview.VisualHullParams(resolution=resolution)
    )
    methods["reconstruction"] = f"visual_hull:{resolution}"

    _tick(progress, cancel, 70, "Reparando la malla…")
    mesh = mesh_tools.basic_repair(mesh)
    mesh = mesh_tools.keep_largest_component(mesh)
    if settings.smoothing > 0:
        mesh = mesh_tools.laplacian_smooth(mesh, settings.smoothing)
        mesh = mesh_tools.basic_repair(mesh)

    if apply_color:
        _tick(progress, cancel, 80, "Transfiriendo color de las fotos…")
        mesh = texturing.color_from_views(mesh, views)
        methods["color"] = "multiview_vertex"

    _tick(progress, cancel, 90, "Ajustando orientación, tamaño y base…")
    # La figura se orienta de pie (su altura Y pasa a ser el eje vertical Z)
    # y se escala a la altura pedida a lo largo de ese eje vertical.
    mesh = mesh_tools.orient_upright_y_to_z(mesh)
    mesh = mesh_tools.scale_to_height(mesh, settings.target_height_mm, axis=2)
    mesh = mesh_tools.add_flat_base(
        mesh, settings.base_thickness_mm if settings.add_base else 0.0
    )
    mesh = mesh_tools.center_on_origin_xy(mesh)

    _tick(progress, cancel, 96, "Analizando imprimibilidad…")
    report = print_analysis.analyze(
        mesh,
        nozzle_diameter_mm=settings.nozzle_diameter_mm,
        material=settings.material,
    )

    _tick(progress, cancel, 100, "Listo.")
    return GenerationResult(
        mesh=mesh, mask=views[0].mask, depth=np.zeros(views[0].mask.shape, np.float32),
        report=report, warnings=warnings, methods=methods,
    )


def apply_postprocess(
    mesh,
    *,
    auto_orient: bool = False,
    hollow_mm: float = 0.0,
    drain_mm: float = 0.0,
    decimate_faces: int = 0,
    progress=None,
    cancel=None,
):
    """Aplica postprocesado opcional (Fase 3) a una malla ya en mm.

    Orden: auto-orientar → vaciar → decimar. Cada paso es opcional.
    """
    from . import postprocess as pp

    out = mesh
    if auto_orient:
        _tick(progress, cancel, 40, "Auto-orientando para impresión…")
        out = pp.auto_orient(out)
    if hollow_mm and hollow_mm > 0:
        _tick(progress, cancel, 60, "Vaciando el interior…")
        out = pp.hollow(out, wall_thickness_mm=hollow_mm, drain_diameter_mm=drain_mm)
    if decimate_faces and decimate_faces > 0:
        _tick(progress, cancel, 85, "Optimizando la malla…")
        out = pp.decimate(out, decimate_faces)
    _tick(progress, cancel, 100, "Postprocesado listo.")
    return out
