"""Herramientas de malla: reparación, escalado en mm, base y suavizado.

Se apoya en trimesh (y opcionalmente pymeshlab en fases posteriores).
Todas las operaciones devuelven una copia y no mutan la entrada salvo que
se indique.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import trimesh


@dataclass
class MeshStats:
    n_vertices: int
    n_faces: int
    is_watertight: bool
    is_winding_consistent: bool
    euler_number: int
    n_components: int
    bbox_mm: tuple[float, float, float]  # (x, y, z)
    volume_mm3: float

    def to_dict(self) -> dict:
        return {
            "n_vertices": self.n_vertices,
            "n_faces": self.n_faces,
            "is_watertight": self.is_watertight,
            "is_winding_consistent": self.is_winding_consistent,
            "euler_number": self.euler_number,
            "n_components": self.n_components,
            "bbox_mm": [round(v, 2) for v in self.bbox_mm],
            "volume_mm3": round(self.volume_mm3, 2),
        }


def compute_stats(mesh: trimesh.Trimesh) -> MeshStats:
    comps = mesh.split(only_watertight=False)
    try:
        vol = float(abs(mesh.volume)) if mesh.is_watertight else 0.0
    except Exception:
        vol = 0.0
    ext = mesh.extents if mesh.extents is not None else np.zeros(3)
    return MeshStats(
        n_vertices=int(len(mesh.vertices)),
        n_faces=int(len(mesh.faces)),
        is_watertight=bool(mesh.is_watertight),
        is_winding_consistent=bool(mesh.is_winding_consistent),
        euler_number=int(mesh.euler_number),
        n_components=int(len(comps)),
        bbox_mm=(float(ext[0]), float(ext[1]), float(ext[2])),
        volume_mm3=vol,
    )


def basic_repair(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Reparación básica: duplicados, caras degeneradas, normales, agujeros."""
    m = mesh.copy()
    m.merge_vertices()
    # trimesh >= 4: los helpers de limpieza se aplican con update_faces()
    try:
        m.update_faces(m.unique_faces())
        m.update_faces(m.nondegenerate_faces())
    except Exception:
        pass
    m.remove_unreferenced_vertices()
    trimesh.repair.fix_inversion(m)
    trimesh.repair.fix_normals(m)
    trimesh.repair.fix_winding(m)
    if not m.is_watertight:
        try:
            trimesh.repair.fill_holes(m)
        except Exception:
            pass
    m.remove_unreferenced_vertices()
    return m


def keep_largest_component(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Elimina objetos flotantes quedándose con la pieza mayor."""
    comps = mesh.split(only_watertight=False)
    if len(comps) <= 1:
        return mesh.copy()
    return max(comps, key=lambda c: len(c.faces)).copy()


def laplacian_smooth(mesh: trimesh.Trimesh, intensity: float) -> trimesh.Trimesh:
    """Suavizado laplaciano. intensity in [0,1]."""
    if intensity <= 0:
        return mesh.copy()
    m = mesh.copy()
    iters = int(round(1 + intensity * 8))
    lamb = 0.5 * float(np.clip(intensity, 0.0, 1.0))
    try:
        trimesh.smoothing.filter_laplacian(m, lamb=lamb, iterations=iters)
    except Exception:
        pass
    return m


def scale_to_height(mesh: trimesh.Trimesh, target_height_mm: float, axis: int = 1) -> trimesh.Trimesh:
    """Escala uniformemente para que la extensión en `axis` sea la altura en mm.

    axis=1 (Y) por defecto (relieve/Fase 1). axis=2 (Z) para objetos que se
    imprimen de pie tras orientarse verticalmente.
    """
    m = mesh.copy()
    ext = m.extents
    cur_h = float(ext[axis]) if ext is not None else 0.0
    if cur_h <= 1e-9:
        return m
    factor = float(target_height_mm) / cur_h
    m.apply_scale(factor)
    return m


def orient_upright_y_to_z(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Rota el objeto para que su eje de altura (Y) pase a ser el vertical (Z).

    Se usa en reconstrucción volumétrica (multivista) para que la figura se
    imprima de pie. Conserva colores por vértice (solo transforma geometría).
    """
    m = mesh.copy()
    R = trimesh.transformations.rotation_matrix(np.pi / 2.0, [1, 0, 0])
    m.apply_transform(R)
    return m


def add_flat_base(mesh: trimesh.Trimesh, base_thickness_mm: float = 0.0) -> trimesh.Trimesh:
    """Apoya el modelo en Z=0 y opcionalmente añade una losa de base.

    Fase 1: reposiciona el modelo sobre el plano Z=0. La base como losa
    separada llega en Fase 3; aquí solo garantizamos apoyo estable.
    """
    m = mesh.copy()
    m.apply_translation([0, 0, -m.bounds[0][2]])  # base en Z=0
    if base_thickness_mm and base_thickness_mm > 0:
        min_x, min_y, _ = m.bounds[0]
        max_x, max_y, _ = m.bounds[1]
        # La losa cubre exactamente la huella para no alterar la altura pedida.
        slab = trimesh.creation.box(
            extents=[(max_x - min_x),
                     (max_y - min_y),
                     base_thickness_mm]
        )
        slab.apply_translation([
            (min_x + max_x) / 2.0,
            (min_y + max_y) / 2.0,
            base_thickness_mm / 2.0,
        ])
        m.apply_translation([0, 0, base_thickness_mm])
        m = trimesh.util.concatenate([slab, m])
        m = basic_repair(m)
    return m


def center_on_origin_xy(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    m = mesh.copy()
    c = m.bounds.mean(axis=0)
    m.apply_translation([-c[0], -c[1], 0])
    return m
