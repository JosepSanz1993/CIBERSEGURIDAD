"""Reconstrucción de malla a partir de profundidad + máscara.

Fase 1: genera un SÓLIDO cerrado por extrusión de un heightmap enmascarado.
  - Superficie frontal: relieve = base + profundidad.
  - Superficie trasera: plano (aproximación de la zona no visible).
  - Paredes laterales: cierran el contorno del sujeto -> malla estanca.

El resultado es geometría con volumen (frente, laterales y una espalda
plana aproximada), no una simple imagen con profundidad. La limitación de
la espalda plana desde una sola foto se documenta y se avisa al usuario
(ver documentation/LIMITATIONS.md). Fase 2 sustituirá la trasera plana por
reconstrucción multivista / generación de vistas.

Devuelve un trimesh.Trimesh en unidades de rejilla (se escala después).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import trimesh


@dataclass
class ReconstructParams:
    detail_level: int = 2        # 1..3 -> resolución de rejilla
    relief_ratio: float = 0.28   # amplitud del relieve respecto al lado mayor
    min_thickness_ratio: float = 0.06  # grosor mínimo (fondo) para evitar caras a 0
    mask_threshold: float = 0.5


def _grid_resolution(detail_level: int) -> int:
    return {1: 160, 2: 256, 3: 384}.get(int(detail_level), 256)


def _resample(arr: np.ndarray, gh: int, gw: int, order_nearest: bool) -> np.ndarray:
    """Reescala arr a (gh, gw). Usa PIL para evitar dependencias extra."""
    from PIL import Image
    mode = "F"
    a = arr.astype(np.float32)
    im = Image.fromarray(a, mode=mode)
    resample = Image.NEAREST if order_nearest else Image.BILINEAR
    im = im.resize((gw, gh), resample)
    return np.asarray(im, dtype=np.float32)


def reconstruct_solid(
    depth: np.ndarray,
    mask: np.ndarray,
    params: ReconstructParams | None = None,
) -> trimesh.Trimesh:
    """Construye un sólido estanco desde depth [0..1] y mask uint8."""
    params = params or ReconstructParams()
    h, w = depth.shape[:2]

    res = _grid_resolution(params.detail_level)
    if max(h, w) >= res:
        if h >= w:
            gh, gw = res, max(2, int(round(res * w / h)))
        else:
            gw, gh = res, max(2, int(round(res * h / w)))
    else:
        gh, gw = h, w

    d = _resample(depth, gh, gw, order_nearest=False)
    m = _resample((mask > 127).astype(np.float32), gh, gw, order_nearest=False)
    inside = m >= params.mask_threshold
    if inside.sum() < 8:
        raise ValueError(
            "La máscara del sujeto está casi vacía. Revisa la selección "
            "antes de generar el modelo 3D."
        )

    longest = max(gh, gw)
    relief = params.relief_ratio * longest
    base = params.min_thickness_ratio * longest
    front_z = base + d * relief          # (gh, gw)

    # Vértices frontales y traseros para toda la rejilla (los no usados se
    # eliminan al final). X hacia la derecha, Y hacia arriba, Z hacia el
    # observador.
    ys, xs = np.mgrid[0:gh, 0:gw]
    X = xs.astype(np.float32)
    Y = (gh - 1 - ys).astype(np.float32)   # voltea para que arriba sea +Y
    front = np.stack([X, Y, front_z], axis=-1).reshape(-1, 3)
    back = np.stack([X, Y, np.zeros_like(front_z)], axis=-1).reshape(-1, 3)
    vertices = np.concatenate([front, back], axis=0)
    n = gh * gw

    def fi(y, x):  # índice frontal
        return y * gw + x

    def bi(y, x):  # índice trasero
        return n + y * gw + x

    # Celdas sólidas: las 4 esquinas dentro de la máscara.
    cell = (
        inside[:-1, :-1] & inside[:-1, 1:] &
        inside[1:, :-1] & inside[1:, 1:]
    )
    cy, cx = np.where(cell)  # coord. de esquina superior-izq de cada celda

    faces: list[np.ndarray] = []

    # Superficie frontal (2 triángulos por celda).
    v00 = fi(cy, cx); v01 = fi(cy, cx + 1)
    v10 = fi(cy + 1, cx); v11 = fi(cy + 1, cx + 1)
    faces.append(np.stack([v00, v10, v11], axis=-1))
    faces.append(np.stack([v00, v11, v01], axis=-1))

    # Superficie trasera (winding invertido).
    b00 = bi(cy, cx); b01 = bi(cy, cx + 1)
    b10 = bi(cy + 1, cx); b11 = bi(cy + 1, cx + 1)
    faces.append(np.stack([b00, b11, b10], axis=-1))
    faces.append(np.stack([b00, b01, b11], axis=-1))

    # Paredes laterales en los bordes del contorno.
    cell_padded = np.zeros((gh + 1, gw + 1), dtype=bool)
    cell_padded[:gh - 1 + 1, :gw - 1 + 1][:cell.shape[0], :cell.shape[1]] = cell
    solid = np.zeros((gh - 1, gw - 1), dtype=bool)
    solid[cy, cx] = True

    def neighbor_solid(dy, dx):
        ny, nx = cy + dy, cx + dx
        ok = (ny >= 0) & (ny < solid.shape[0]) & (nx >= 0) & (nx < solid.shape[1])
        res_ = np.zeros(cy.shape, dtype=bool)
        res_[ok] = solid[ny[ok], nx[ok]]
        return res_

    def wall(a_y, a_x, b_y, b_x, sel):
        """Cuadrilátero vertical entre (a) y (b) para las celdas seleccionadas."""
        ay, ax = a_y[sel], a_x[sel]
        by, bx = b_y[sel], b_x[sel]
        fa, fb = fi(ay, ax), fi(by, bx)
        ba, bb = bi(ay, ax), bi(by, bx)
        faces.append(np.stack([fa, fb, bb], axis=-1))
        faces.append(np.stack([fa, bb, ba], axis=-1))

    left_edge = ~neighbor_solid(0, -1)
    right_edge = ~neighbor_solid(0, +1)
    top_edge = ~neighbor_solid(-1, 0)
    bot_edge = ~neighbor_solid(+1, 0)

    # bordes de cada celda (coords de esquina)
    wall(cy, cx, cy + 1, cx, left_edge)                # izquierda
    wall(cy, cx + 1, cy + 1, cx + 1, right_edge)       # derecha
    wall(cy, cx, cy, cx + 1, top_edge)                 # arriba
    wall(cy + 1, cx, cy + 1, cx + 1, bot_edge)         # abajo

    all_faces = np.concatenate(faces, axis=0).astype(np.int64)

    mesh = trimesh.Trimesh(vertices=vertices, faces=all_faces, process=False)
    mesh.remove_unreferenced_vertices()
    mesh.merge_vertices()
    trimesh.repair.fix_normals(mesh)
    return mesh
