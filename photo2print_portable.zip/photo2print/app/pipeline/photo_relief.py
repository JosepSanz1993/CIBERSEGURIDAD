"""Foto → relieve 3D fiel (mapa de alturas por brillo).

Convierte CUALQUIER imagen en un relieve sólido e imprimible que **se parece a
la foto**: cada píxel se eleva según su brillo. No usa IA ni segmentación, así
que el resultado es predecible y reconocible para cualquier imagen.

- Modo "relieve": las zonas claras se elevan (la imagen se ve en relieve).
- Modo "litofania": las zonas oscuras son más gruesas (pensado para iluminar
  por detrás; al trasluz se ve la foto).

Siempre devuelve un sólido cerrado (estanco) listo para exportar a STL.
"""
from __future__ import annotations

import numpy as np
import trimesh


def _to_gray(rgb: np.ndarray) -> np.ndarray:
    a = rgb.astype(np.float32)
    if a.ndim == 2:
        g = a
    else:
        if a.shape[2] == 4:  # aplanar alfa sobre blanco
            alpha = a[:, :, 3:4] / 255.0
            a = a[:, :, :3] * alpha + 255.0 * (1 - alpha)
        g = 0.2126 * a[:, :, 0] + 0.7152 * a[:, :, 1] + 0.0722 * a[:, :, 2]
    return g / 255.0


def _resize(gray: np.ndarray, max_side: int) -> np.ndarray:
    h, w = gray.shape
    if max(h, w) <= max_side:
        return gray
    if h >= w:
        nh, nw = max_side, max(2, round(w * max_side / h))
    else:
        nw, nh = max_side, max(2, round(h * max_side / w))
    ys = (np.linspace(0, h - 1, nh)).astype(np.int64)
    xs = (np.linspace(0, w - 1, nw)).astype(np.int64)
    return gray[ys][:, xs]


def _blur(gray: np.ndarray, sigma: float) -> np.ndarray:
    if sigma <= 0:
        return gray
    try:
        from scipy.ndimage import gaussian_filter
        return gaussian_filter(gray, sigma=sigma)
    except Exception:
        return gray


def heightmap_relief(
    rgb: np.ndarray,
    height_mm: float = 120.0,
    relief_mm: float = 4.0,
    base_mm: float = 2.0,
    *,
    invert: bool = False,
    detail: int = 2,
    smooth: float = 0.6,
    contrast: bool = True,
) -> trimesh.Trimesh:
    """Genera un relieve sólido a partir de una imagen.

    height_mm  -> alto físico del relieve (eje Y). El ancho sale proporcional.
    relief_mm  -> cuánto sobresale el relieve por encima de la base.
    base_mm    -> grosor de la placa de base (para que sea sólido y rígido).
    invert     -> True para litofania (oscuro = más grueso).
    detail     -> 1/2/3 controla la resolución (más detalle = más caras).
    """
    max_side = {1: 140, 2: 220, 3: 340}.get(int(detail), 260)

    gray = _to_gray(rgb)
    gray = _resize(gray, max_side)
    gray = _blur(gray, smooth)

    if contrast:  # estira el rango para que el relieve tenga cuerpo
        lo, hi = np.percentile(gray, 2), np.percentile(gray, 98)
        if hi - lo > 1e-4:
            gray = np.clip((gray - lo) / (hi - lo), 0, 1)

    if invert:
        gray = 1.0 - gray

    gh, gw = gray.shape
    px = float(height_mm) / max(gh - 1, 1)          # tamaño de píxel en mm (eje Y)

    xs = np.arange(gw, dtype=np.float32) * px
    ys = (gh - 1 - np.arange(gh, dtype=np.float32)) * px
    X, Y = np.meshgrid(xs, ys)                        # (gh, gw)

    z_top = base_mm + gray.astype(np.float32) * float(relief_mm)
    n = gh * gw

    top = np.stack([X.ravel(), Y.ravel(), z_top.ravel()], axis=1)
    bot = np.stack([X.ravel(), Y.ravel(), np.zeros(n, np.float32)], axis=1)
    vertices = np.concatenate([top, bot], axis=0)

    def ti(r, c): return r * gw + c
    def bi(r, c): return n + r * gw + c

    r = np.arange(gh - 1)[:, None]
    c = np.arange(gw - 1)[None, :]
    r = np.broadcast_to(r, (gh - 1, gw - 1)).ravel()
    c = np.broadcast_to(c, (gh - 1, gw - 1)).ravel()

    faces = []
    # superficie superior (con el relieve)
    faces.append(np.stack([ti(r, c), ti(r + 1, c), ti(r + 1, c + 1)], 1))
    faces.append(np.stack([ti(r, c), ti(r + 1, c + 1), ti(r, c + 1)], 1))
    # base inferior (normales hacia abajo)
    faces.append(np.stack([bi(r, c), bi(r + 1, c + 1), bi(r + 1, c)], 1))
    faces.append(np.stack([bi(r, c), bi(r, c + 1), bi(r + 1, c + 1)], 1))

    # paredes laterales (cierran el sólido)
    left_r = np.arange(gh - 1)
    right_r = np.arange(gh - 1)
    top_c = np.arange(gw - 1)
    bot_c = np.arange(gw - 1)
    # borde izquierdo (c=0)
    faces.append(np.stack([ti(left_r, 0), bi(left_r, 0), bi(left_r + 1, 0)], 1))
    faces.append(np.stack([ti(left_r, 0), bi(left_r + 1, 0), ti(left_r + 1, 0)], 1))
    # borde derecho (c=gw-1)
    cc = gw - 1
    faces.append(np.stack([ti(right_r, cc), ti(right_r + 1, cc), bi(right_r + 1, cc)], 1))
    faces.append(np.stack([ti(right_r, cc), bi(right_r + 1, cc), bi(right_r, cc)], 1))
    # borde superior (r=0)
    faces.append(np.stack([ti(0, top_c), ti(0, top_c + 1), bi(0, top_c + 1)], 1))
    faces.append(np.stack([ti(0, top_c), bi(0, top_c + 1), bi(0, top_c)], 1))
    # borde inferior (r=gh-1)
    rr = gh - 1
    faces.append(np.stack([ti(rr, bot_c), bi(rr, bot_c), bi(rr, bot_c + 1)], 1))
    faces.append(np.stack([ti(rr, bot_c), bi(rr, bot_c + 1), ti(rr, bot_c + 1)], 1))

    all_faces = np.concatenate(faces, axis=0).astype(np.int64)
    mesh = trimesh.Trimesh(vertices=vertices, faces=all_faces, process=True)
    trimesh.repair.fix_normals(mesh)
    return mesh
