"""Paquete de impresión (Fase 4).

Genera un "print pack": el/los modelo(s), un manifiesto JSON con dimensiones,
material estimado y ajustes recomendados, una vista previa PNG y un README.
Pensado para entregar todo lo necesario para laminar en Bambu Studio.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import trimesh

from ..config import PrintSettings
from . import print_analysis, bed as bed_mod
from .. import exporters


@dataclass
class PrintEstimate:
    bbox_mm: tuple
    volume_cm3: float
    filament_g: float
    filament_m: float
    est_time_min: float
    needs_supports: bool
    fits_bed: bool


# flujo volumétrico aproximado por material (cm³/min) a velocidad media
_FLOW_CM3_MIN = {"PLA": 8.0, "PETG": 6.5, "ABS": 6.5, "TPU": 3.0, "ASA": 6.0}


def estimate(mesh: trimesh.Trimesh, settings: PrintSettings, bed=bed_mod.DEFAULT_BED) -> PrintEstimate:
    rep = print_analysis.analyze(
        mesh, nozzle_diameter_mm=settings.nozzle_diameter_mm, material=settings.material
    )
    # Volumen robusto: usa el volumen de la malla; si no es fiable, aproxima con
    # el casco convexo (factor de relleno conservador).
    vol_mm3 = abs(float(mesh.volume)) if mesh.volume is not None else 0.0
    if vol_mm3 <= 1e-6:
        try:
            vol_mm3 = abs(float(mesh.convex_hull.volume)) * 0.35
        except Exception:
            vol_mm3 = 0.0
    vol_cm3 = vol_mm3 / 1000.0
    flow = _FLOW_CM3_MIN.get(settings.material.upper(), 7.0)
    est_min = round(vol_cm3 / flow * 60.0 / 10.0, 1) if vol_cm3 else 0.0  # heurística burda
    e = mesh.extents
    density = 1.24  # g/cm³ aprox PLA
    fil_g = rep.est_filament_g if rep.est_filament_g > 0 else round(vol_cm3 * density, 1)
    fil_m = round(fil_g / 2.98, 2)  # ~2.98 g/m para PLA 1.75mm
    return PrintEstimate(
        bbox_mm=tuple(round(float(x), 1) for x in e),
        volume_cm3=round(vol_cm3, 2),
        filament_g=round(fil_g, 1),
        filament_m=fil_m,
        est_time_min=est_min,
        needs_supports=bool(rep.needs_supports),
        fits_bed=bed_mod.fits_bed(mesh, bed),
    )


def export_print_pack(
    mesh: trimesh.Trimesh,
    out_dir: str | Path,
    settings: PrintSettings,
    *,
    model_format: str = "3mf",
    make_preview: bool = True,
    split_if_needed: bool = True,
    bed=bed_mod.DEFAULT_BED,
) -> dict:
    """Escribe el paquete en `out_dir`. Devuelve un dict con las rutas."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written: list[str] = []

    parts = [mesh]
    if split_if_needed and not bed_mod.fits_bed(mesh, bed):
        parts = bed_mod.split_for_bed(mesh, bed)

    model_paths = []
    if len(parts) == 1:
        p = exporters.export(mesh, out / "model", model_format)
        model_paths.append(str(p)); written.append(str(p))
    else:
        for i, part in enumerate(parts, 1):
            p = exporters.export(part, out / f"part_{i:02d}", model_format)
            model_paths.append(str(p)); written.append(str(p))

    est = estimate(mesh, settings, bed)

    preview_path = None
    if make_preview:
        try:
            from . import render_preview
            preview_path = str(out / "preview.png")
            render_preview.save_png(mesh, preview_path, size=640)
            written.append(preview_path)
        except Exception:
            preview_path = None

    manifest = {
        "app": "Photo2Print",
        "model_files": [Path(p).name for p in model_paths],
        "n_parts": len(parts),
        "preview": Path(preview_path).name if preview_path else None,
        "settings": {
            "target_height_mm": settings.target_height_mm,
            "nozzle_diameter_mm": settings.nozzle_diameter_mm,
            "material": settings.material,
            "detail_level": settings.detail_level,
        },
        "estimate": asdict(est),
        "recommended": {
            "supports": est.needs_supports,
            "layer_height_mm": round(settings.nozzle_diameter_mm * 0.5, 2),
            "walls": 3,
            "infill_percent": 15,
        },
        "bed_mm": list(bed),
    }
    man_path = out / "manifest.json"
    man_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    written.append(str(man_path))

    readme = out / "README.txt"
    readme.write_text(
        "Photo2Print — paquete de impresión\n"
        "==================================\n\n"
        f"Modelo(s): {', '.join(Path(p).name for p in model_paths)}\n"
        f"Piezas: {len(parts)} (troceado por cama {bed[0]:.0f}x{bed[1]:.0f}x{bed[2]:.0f} mm)\n"
        f"Dimensiones: {est.bbox_mm} mm\n"
        f"Material estimado: {est.filament_g} g (~{est.filament_m} m) de {settings.material}\n"
        f"Soportes recomendados: {'sí' if est.needs_supports else 'no'}\n\n"
        "Abre el/los archivo(s) en Bambu Studio para laminar.\n"
        "Consulta manifest.json para los ajustes recomendados.\n",
        encoding="utf-8",
    )
    written.append(str(readme))

    return {
        "dir": str(out),
        "model_files": model_paths,
        "manifest": str(man_path),
        "readme": str(readme),
        "preview": preview_path,
        "estimate": asdict(est),
        "files": written,
    }
