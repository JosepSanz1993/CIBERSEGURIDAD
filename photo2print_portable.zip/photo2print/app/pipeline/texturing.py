"""Transferencia de color de las fotos a la malla (Fase 2).

Asigna un color por vértice muestreando las fotos originales. Para cada
vértice y cada vista se calcula un peso = cuánto "mira" la superficie a esa
cámara (normal · dirección de cámara). Solo las caras orientadas hacia una
foto reciben su color, lo que evita en gran medida pintar la espalda con la
textura del frente sin necesidad de un test de oclusión completo.

Trabaja en coordenadas normalizadas del turntable (las que produce
`multiview.visual_hull`).
"""
from __future__ import annotations

import numpy as np
import trimesh

from . import cameras
from .cameras import View


def color_from_views(
    mesh: trimesh.Trimesh,
    views: list[View],
    fallback=(180, 180, 185),
    margin: float = 0.06,
) -> trimesh.Trimesh:
    """Devuelve una copia de la malla con `visual.vertex_colors` asignados."""
    m = mesh.copy()
    for v in views:
        if v.half <= 0:
            cameras.prepare_view(v, margin=margin)

    verts = m.vertices.view(np.ndarray)
    norms = m.vertex_normals.view(np.ndarray)
    n = len(verts)

    # Normaliza los vértices al cubo [-1,1] (independiente de la escala en mm),
    # que es el espacio en el que se definieron las siluetas/proyecciones.
    center = m.bounds.mean(axis=0)
    half_max = 0.5 * float(np.max(m.extents)) or 1.0
    verts_n = (verts - center) / half_max

    accum = np.zeros((n, 3), dtype=np.float64)
    wsum = np.zeros((n, 1), dtype=np.float64)

    for v in views:
        pv = cameras.rotate_y(verts_n, v.angle_deg)
        nv = cameras.rotate_y(norms, v.angle_deg)
        # cámara en +Z' mirando -Z': la superficie "mira" a la cámara si nz' > 0
        weight = np.clip(nv[:, 2], 0.0, None)
        seen = weight > 1e-3
        if not seen.any():
            continue
        px = cameras.project_to_pixels(pv, v)
        cols = px[:, 0]
        rows = px[:, 1]
        rgb = cameras.sample_rgb(v, cols, rows).astype(np.float64)
        w = weight[:, None]
        accum[seen] += rgb[seen] * w[seen]
        wsum[seen] += w[seen]

    colored = np.where(wsum > 0, accum / np.maximum(wsum, 1e-9), np.array(fallback, np.float64))
    rgba = np.concatenate(
        [np.clip(colored, 0, 255).astype(np.uint8),
         np.full((n, 1), 255, np.uint8)],
        axis=1,
    )
    m.visual = trimesh.visual.ColorVisuals(mesh=m, vertex_colors=rgba)
    return m


def has_color(mesh: trimesh.Trimesh) -> bool:
    try:
        vc = mesh.visual.vertex_colors
        return vc is not None and len(vc) == len(mesh.vertices)
    except Exception:
        return False
