"""Estimación de profundidad monocular.

Estrategia idéntica en filosofía a segmentation.py:
  1. Si PyTorch + MiDaS están disponibles, se usa MiDaS (Intel-ISL, licencia
     MIT). Los pesos se descargan la primera vez vía torch.hub.
  2. Si no, fallback determinista basado en luminancia + suavizado, que
     produce un relieve razonable sin dependencias pesadas.

Salida: mapa de profundidad float32 (H, W) normalizado a [0, 1], donde
1 = más cerca de la cámara (más alto en el relieve).
"""
from __future__ import annotations

import numpy as np

from .images import to_rgb


def torch_midas_available() -> bool:
    try:
        import torch  # noqa: F401
        return True
    except Exception:
        return False


# Cache del modelo cargado (evita recargarlo por cada imagen).
_MIDAS_CACHE: dict = {}


def _depth_with_midas(rgb: np.ndarray, device: str, model_type: str) -> np.ndarray:
    import torch

    if "model" not in _MIDAS_CACHE:
        midas = torch.hub.load("intel-isl/MiDaS", model_type)
        transforms = torch.hub.load("intel-isl/MiDaS", "transforms")
        transform = (
            transforms.small_transform
            if "small" in model_type
            else transforms.dpt_transform
        )
        midas.to(device).eval()
        _MIDAS_CACHE.update(model=midas, transform=transform, device=device)

    midas = _MIDAS_CACHE["model"]
    transform = _MIDAS_CACHE["transform"]
    dev = _MIDAS_CACHE["device"]

    inp = transform(to_rgb(rgb)).to(dev)
    with torch.no_grad():
        pred = midas(inp)
        pred = torch.nn.functional.interpolate(
            pred.unsqueeze(1), size=rgb.shape[:2],
            mode="bicubic", align_corners=False,
        ).squeeze()
    depth = pred.detach().cpu().numpy().astype(np.float32)
    return _normalize01(depth)


def _depth_fallback(rgb: np.ndarray) -> np.ndarray:
    """Pseudo-profundidad por luminancia + realce central.

    No es geometría real, pero da un relieve con volumen suave, suficiente
    para el modo relieve/Fase 1 y para que el pipeline sea end-to-end.
    """
    rgb = to_rgb(rgb).astype(np.float32) / 255.0
    lum = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    depth = _gaussian_blur(lum, sigma=2.0)

    # realce radial: el centro sobresale un poco -> aspecto de volumen
    h, w = depth.shape
    yy, xx = np.mgrid[0:h, 0:w]
    r = np.hypot((yy - h / 2) / (h / 2), (xx - w / 2) / (w / 2))
    bump = np.clip(1.0 - r, 0.0, 1.0) ** 1.5
    depth = 0.7 * depth + 0.3 * bump
    return _normalize01(depth)


def _normalize01(x: np.ndarray) -> np.ndarray:
    x = x.astype(np.float32)
    lo, hi = float(np.min(x)), float(np.max(x))
    if hi - lo < 1e-6:
        return np.zeros_like(x)
    return (x - lo) / (hi - lo)


def _gaussian_blur(x: np.ndarray, sigma: float) -> np.ndarray:
    try:
        from scipy.ndimage import gaussian_filter
        return gaussian_filter(x, sigma=sigma)
    except Exception:
        return x


def estimate_depth(
    rgb: np.ndarray,
    device: str = "cpu",
    model_type: str = "MiDaS_small",
    prefer_ai: bool = True,
) -> tuple[np.ndarray, str]:
    """Devuelve (depth float32 [0..1], método_usado)."""
    if prefer_ai and torch_midas_available():
        try:
            return _depth_with_midas(rgb, device, model_type), f"midas:{model_type}"
        except Exception:
            pass
    return _depth_fallback(rgb), "fallback"
