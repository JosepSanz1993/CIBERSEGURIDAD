"""Carga y normalización de imágenes de entrada.

Soporta JPG, PNG, WebP, BMP, TIFF de forma nativa (Pillow) y HEIC/HEIF si
`pillow-heif` está instalado. Corrige la orientación EXIF y devuelve un
array RGB uint8 (H, W, 3) o RGBA cuando hay canal alfa.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

# Registro opcional del plugin HEIC/HEIF.
try:  # pragma: no cover - depende del entorno
    import pillow_heif

    pillow_heif.register_heif_opener()
    _HEIF_OK = True
except Exception:  # pragma: no cover
    _HEIF_OK = False


class ImageLoadError(Exception):
    """Error legible para la UI cuando una imagen no se puede abrir."""


def heif_available() -> bool:
    return _HEIF_OK


def load_image(path: str | Path) -> np.ndarray:
    """Devuelve un array RGB(A) uint8. Lanza ImageLoadError con mensaje claro."""
    path = Path(path)
    if not path.exists():
        raise ImageLoadError(f"El archivo no existe: {path}")

    suffix = path.suffix.lower()
    if suffix in (".heic", ".heif") and not _HEIF_OK:
        raise ImageLoadError(
            "Este archivo es HEIC/HEIF. Instala el paquete 'pillow-heif' "
            "o convierte la imagen a JPG/PNG e inténtalo de nuevo."
        )

    try:
        with Image.open(path) as im:
            im = ImageOps.exif_transpose(im)  # respeta la orientación de la cámara
            if im.mode not in ("RGB", "RGBA"):
                im = im.convert("RGBA" if "A" in im.getbands() else "RGB")
            arr = np.asarray(im)
    except (UnidentifiedImageError, OSError) as exc:
        raise ImageLoadError(
            f"No se pudo leer la imagen '{path.name}'. "
            f"¿Está dañada o en un formato no soportado? Detalle: {exc}"
        ) from exc

    if arr.ndim == 2:  # escala de grises -> RGB
        arr = np.stack([arr] * 3, axis=-1)
    return np.ascontiguousarray(arr)


def to_rgb(arr: np.ndarray, background=(255, 255, 255)) -> np.ndarray:
    """Aplana RGBA sobre un fondo sólido y devuelve RGB uint8."""
    if arr.ndim == 3 and arr.shape[2] == 4:
        rgb = arr[..., :3].astype(np.float32)
        alpha = arr[..., 3:4].astype(np.float32) / 255.0
        bg = np.array(background, dtype=np.float32)
        out = rgb * alpha + bg * (1.0 - alpha)
        return np.clip(out, 0, 255).astype(np.uint8)
    return arr[..., :3].copy()


def downscale_max_side(arr: np.ndarray, max_side: int) -> np.ndarray:
    """Reduce la imagen para que su lado mayor no exceda `max_side` px."""
    h, w = arr.shape[:2]
    longest = max(h, w)
    if longest <= max_side:
        return arr
    scale = max_side / float(longest)
    new_size = (max(1, int(round(w * scale))), max(1, int(round(h * scale))))
    mode = "RGBA" if arr.ndim == 3 and arr.shape[2] == 4 else "RGB"
    im = Image.fromarray(arr, mode=mode).resize(new_size, Image.LANCZOS)
    return np.asarray(im)
