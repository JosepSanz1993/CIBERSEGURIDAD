"""Postprocesado de malla (Fase 3).

- `hollow`: vacía el sólido dejando una pared de grosor dado (ahorra material),
  con agujero de drenaje opcional. Método por vóxeles (no requiere booleanos).
- `decimate`: reduce el número de caras a un presupuesto (archivos más ligeros).
- `auto_orient`: apoya el modelo sobre su cara más grande (mejor adherencia y
  menos soportes).
- `advanced_repair`: reparación con `pymeshlab` si está instalado (opcional);
  si no, cae a la reparación básica.
"""
from __future__ import annotations

import numpy as np
import trimesh


def decimate(mesh: trimesh.Trimesh, target_faces: int) -> trimesh.Trimesh:
    """Reduce la malla a ~target_faces conservando la forma. Preserva color."""
    if target_faces <= 0 or len(mesh.faces) <= target_faces:
        return mesh.copy()
    had_color = _get_vertex_colors(mesh)
    try:
        out = mesh.simplify_quadric_decimation(face_count=int(target_faces))
    except Exception:
        return mesh.copy()
    # el color por vértice no sobrevive a la decimación (cambia la topología);
    # se re-muestrea por vecino más cercano si lo había.
    if had_color is not None and len(out.vertices):
        out = _transfer_colors_nearest(mesh, out)
    return out


def hollow(
    mesh: trimesh.Trimesh,
    wall_thickness_mm: float = 2.0,
    voxel_mm: float | None = None,
    drain_diameter_mm: float = 0.0,
) -> trimesh.Trimesh:
    """Vacía el interior dejando una pared. Devuelve una malla nueva.

    Con `drain_diameter_mm > 0` se abre un agujero inferior para vaciar resina/
    material de soporte y evitar bolsas de aire (la malla deja de ser estanca).
    """
    from scipy import ndimage
    from skimage.measure import marching_cubes

    ext = float(np.max(mesh.extents))
    if voxel_mm is None:
        voxel_mm = ext / 140.0                      # ~140 vóxeles en el lado mayor
    voxel_mm = max(min(voxel_mm, wall_thickness_mm / 2.0), ext / 400.0)

    vox = mesh.voxelized(pitch=voxel_mm)
    try:
        vox = vox.fill()
    except Exception:
        pass
    occ = np.asarray(vox.matrix, dtype=bool)
    if occ.sum() < 8:
        return mesh.copy()

    k = max(1, int(round(wall_thickness_mm / voxel_mm)))
    inner = ndimage.binary_erosion(occ, iterations=k)
    shell = occ & ~inner
    if not shell.any():
        return mesh.copy()  # demasiado fino para vaciar a esta resolución

    if drain_diameter_mm > 0:
        _carve_drain(shell, voxel_mm, drain_diameter_mm)

    padded = np.pad(shell.astype(np.float32), 1, mode="constant", constant_values=0.0)
    verts, faces, _n, _v = marching_cubes(padded, level=0.5)
    verts -= 1.0                                     # deshace el pad → índices de matriz
    verts_world = trimesh.transform_points(verts, vox.transform)
    out = trimesh.Trimesh(vertices=verts_world, faces=faces, process=True)
    trimesh.repair.fix_normals(out)
    return out


def _carve_drain(shell: np.ndarray, voxel_mm: float, diameter_mm: float) -> None:
    """Abre un cilindro vertical (−Z) en la base para drenar el interior."""
    r = max(1, int(round((diameter_mm / 2.0) / voxel_mm)))
    nx, ny, nz = shell.shape
    ci, cj = nx // 2, ny // 2
    ii, jj = np.mgrid[0:nx, 0:ny]
    disk = (ii - ci) ** 2 + (jj - cj) ** 2 <= r ** 2
    depth = min(nz, 2 * r + 4)
    for kz in range(depth):
        layer = shell[:, :, kz]
        layer[disk] = False
        shell[:, :, kz] = layer


def auto_orient(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Rota el modelo para que su cara plana mayor quede abajo (Z=0)."""
    m = mesh.copy()
    try:
        hull = m.convex_hull
        areas = hull.area_faces
        idx = int(np.argmax(areas))
        n = hull.face_normals[idx]
    except Exception:
        return m
    target = np.array([0.0, 0.0, -1.0])
    R = trimesh.geometry.align_vectors(n, target)
    if R is not None:
        m.apply_transform(R)
    # apoya en Z=0
    m.apply_translation([0, 0, -m.bounds[0][2]])
    return m


def advanced_repair(mesh: trimesh.Trimesh):
    """Reparación con pymeshlab si está disponible; si no, None (usa la básica)."""
    try:
        import pymeshlab  # noqa: F401
    except Exception:
        return None
    try:
        ms = pymeshlab.MeshSet()
        ms.add_mesh(pymeshlab.Mesh(vertex_matrix=mesh.vertices, face_matrix=mesh.faces))
        ms.meshing_repair_non_manifold_edges()
        ms.meshing_close_holes(maxholesize=100)
        m = ms.current_mesh()
        return trimesh.Trimesh(vertex_matrix=m.vertex_matrix(), faces=m.face_matrix(), process=True)
    except Exception:
        return None


# ---- utilidades de color ----
def _get_vertex_colors(mesh):
    try:
        vc = mesh.visual.vertex_colors
        if vc is not None and len(vc) == len(mesh.vertices):
            return np.asarray(vc)
    except Exception:
        pass
    return None


def _transfer_colors_nearest(src: trimesh.Trimesh, dst: trimesh.Trimesh) -> trimesh.Trimesh:
    src_c = _get_vertex_colors(src)
    if src_c is None:
        return dst
    try:
        from scipy.spatial import cKDTree
        tree = cKDTree(src.vertices)
        _d, idx = tree.query(dst.vertices, k=1)
        dst.visual = trimesh.visual.ColorVisuals(mesh=dst, vertex_colors=src_c[idx])
    except Exception:
        pass
    return dst
