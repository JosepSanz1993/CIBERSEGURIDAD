"""Renderizador por software (z-buffer en numpy) para vistas previa.

No necesita GPU ni OpenGL: proyecta la malla (con color por vértice si lo
tiene) y la rasteriza con sombreado plano. Se usa para las miniaturas del
"print pack" y para las demostraciones. Pensado para mallas de pocas miles de
caras (decima antes si hace falta).
"""
from __future__ import annotations

import numpy as np
import trimesh


def render(
    mesh: trimesh.Trimesh,
    size: int = 700,
    azim_deg: float = 30.0,
    elev_deg: float = 20.0,
    bg=(245, 245, 248),
    base_color=(180, 180, 188),
    max_faces: int = 6000,
) -> np.ndarray:
    """Devuelve una imagen RGB (size,size,3) uint8 de la malla."""
    m = mesh.copy()
    # color por vértice original (para conservarlo si hay que decimar)
    orig_colors = None
    try:
        vcol0 = m.visual.vertex_colors
        if vcol0 is not None and len(vcol0) == len(m.vertices):
            orig_colors = np.asarray(vcol0)[:, :3].astype(np.float64)
            orig_verts = np.asarray(m.vertices).copy()
    except Exception:
        orig_colors = None

    if len(m.faces) > max_faces:
        try:
            m = m.simplify_quadric_decimation(face_count=max_faces)
            if orig_colors is not None:
                from scipy.spatial import cKDTree
                _d, idx = cKDTree(orig_verts).query(np.asarray(m.vertices), k=1)
                m.visual = trimesh.visual.ColorVisuals(mesh=m, vertex_colors=orig_colors[idx].astype(np.uint8))
        except Exception:
            pass

    V = np.asarray(m.vertices, dtype=np.float64)
    center = (V.max(0) + V.min(0)) / 2.0
    V = V - center

    az = np.radians(azim_deg)
    el = np.radians(elev_deg)
    # rota alrededor de Z (vertical) y luego inclina sobre X
    Rz = np.array([[np.cos(az), -np.sin(az), 0], [np.sin(az), np.cos(az), 0], [0, 0, 1]])
    Rx = np.array([[1, 0, 0], [0, np.cos(el), -np.sin(el)], [0, np.sin(el), np.cos(el)]])
    P = V @ Rz.T @ Rx.T

    # pantalla: x → columna, z → fila (arriba), y → profundidad
    sx, sy, depth = P[:, 0], P[:, 2], P[:, 1]
    span = max(P.max(0) - P.min(0)) or 1.0
    scale = (size * 0.86) / span
    cx = size / 2.0
    cy = size / 2.0
    px = cx + sx * scale
    py = cy - sy * scale

    img = np.zeros((size, size, 3), dtype=np.float64)
    img[:] = bg
    zbuf = np.full((size, size), -np.inf)

    faces = np.asarray(m.faces)
    fn = np.asarray(m.face_normals)
    fn_r = fn @ Rz.T @ Rx.T
    light = np.array([0.2, -0.7, 0.6]); light = light / np.linalg.norm(light)
    diffuse = np.clip(fn_r @ light, 0, 1)
    shade = 0.55 + 0.45 * diffuse                       # ambiente alto + difuso

    # color por cara (media de color de vértices si existe)
    vc = None
    try:
        vcol = m.visual.vertex_colors
        if vcol is not None and len(vcol) == len(m.vertices):
            vc = np.asarray(vcol)[:, :3].astype(np.float64)
    except Exception:
        vc = None
    if vc is not None:
        face_col = vc[faces].mean(axis=1)
    else:
        face_col = np.tile(np.array(base_color, float), (len(faces), 1))
    face_col = np.clip(face_col * shade[:, None], 0, 255)

    order = np.argsort(depth[faces].mean(axis=1))  # de atrás hacia delante
    for fi in order:
        a, b, c = faces[fi]
        xs = np.array([px[a], px[b], px[c]])
        ys = np.array([py[a], py[b], py[c]])
        zs = np.array([depth[a], depth[b], depth[c]])
        x0, x1 = int(np.floor(xs.min())), int(np.ceil(xs.max()))
        y0, y1 = int(np.floor(ys.min())), int(np.ceil(ys.max()))
        x0 = max(x0, 0); y0 = max(y0, 0); x1 = min(x1, size - 1); y1 = min(y1, size - 1)
        if x1 < x0 or y1 < y0:
            continue
        gx, gy = np.meshgrid(np.arange(x0, x1 + 1), np.arange(y0, y1 + 1))
        gx = gx.ravel(); gy = gy.ravel()
        d = ((ys[1] - ys[2]) * (xs[0] - xs[2]) + (xs[2] - xs[1]) * (ys[0] - ys[2]))
        if abs(d) < 1e-9:
            continue
        w0 = ((ys[1] - ys[2]) * (gx - xs[2]) + (xs[2] - xs[1]) * (gy - ys[2])) / d
        w1 = ((ys[2] - ys[0]) * (gx - xs[2]) + (xs[0] - xs[2]) * (gy - ys[2])) / d
        w2 = 1 - w0 - w1
        inside = (w0 >= 0) & (w1 >= 0) & (w2 >= 0)
        if not inside.any():
            continue
        gx, gy, w0, w1, w2 = gx[inside], gy[inside], w0[inside], w1[inside], w2[inside]
        z = w0 * zs[0] + w1 * zs[1] + w2 * zs[2]
        cur = zbuf[gy, gx]
        better = z > cur
        if better.any():
            zbuf[gy[better], gx[better]] = z[better]
            img[gy[better], gx[better]] = face_col[fi]

    return np.clip(img, 0, 255).astype(np.uint8)


def save_png(mesh: trimesh.Trimesh, path, **kw) -> str:
    from PIL import Image
    arr = render(mesh, **kw)
    Image.fromarray(arr).save(path)
    return str(path)
