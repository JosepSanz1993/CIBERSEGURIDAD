"""Cama de impresión: comprobación de encaje y troceado (Fase 4).

Si el modelo no cabe en la cama, se corta con planos en trozos que sí caben.
Los cortes son planos (sin conectores tipo espiga todavía; ver LIMITATIONS).
"""
from __future__ import annotations

import numpy as np
import trimesh

# Camas típicas (mm). Bambu Lab por defecto ~256×256×256.
DEFAULT_BED = (256.0, 256.0, 256.0)


def fits_bed(mesh: trimesh.Trimesh, bed=DEFAULT_BED) -> bool:
    e = mesh.extents
    return bool(e[0] <= bed[0] + 1e-6 and e[1] <= bed[1] + 1e-6 and e[2] <= bed[2] + 1e-6)


def _cut(mesh: trimesh.Trimesh, axis: int, value: float):
    """Devuelve (parte<=value, parte>value) cerradas con `cap`."""
    normal = np.zeros(3); normal[axis] = 1.0
    origin = np.zeros(3); origin[axis] = value
    low = mesh.slice_plane(origin, -normal, cap=True)
    high = mesh.slice_plane(origin, normal, cap=True)
    return low, high


def split_for_bed(mesh: trimesh.Trimesh, bed=DEFAULT_BED) -> list[trimesh.Trimesh]:
    """Trocea el modelo en piezas que caben en la cama. Lista con 1+ mallas."""
    parts = [mesh.copy()]
    for axis in range(3):
        limit = bed[axis]
        new_parts: list[trimesh.Trimesh] = []
        for p in parts:
            e = p.extents[axis]
            if e <= limit + 1e-6:
                new_parts.append(p)
                continue
            n_cuts = int(np.ceil(e / limit))
            lo = p.bounds[0][axis]
            step = e / n_cuts
            remainder = p
            for i in range(1, n_cuts):
                cut_val = lo + step * i
                low, high = _cut(remainder, axis, cut_val)
                if low is not None and len(low.faces):
                    new_parts.append(low)
                remainder = high if (high is not None and len(high.faces)) else None
                if remainder is None:
                    break
            if remainder is not None and len(remainder.faces):
                new_parts.append(remainder)
        parts = new_parts
    return parts
