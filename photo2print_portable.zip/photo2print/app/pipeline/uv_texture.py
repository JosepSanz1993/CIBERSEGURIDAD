"""Baking de textura UV (Fase 3) — OPCIONAL y desactivado por defecto.

Convierte el color por vértice en un mapa de textura con coordenadas UV, lo que
mejora el aspecto en superficies suaves y permite exportar OBJ+MTL/GLB con
textura (en vez de solo color por vértice).

IMPORTANTE: el "unwrapping" usa `xatlas` (a través de `trimesh.unwrap`). En
algunos entornos xatlas puede fallar/crashear, por eso esta ruta es opcional y
está desactivada por defecto. Actívala con `bake=True` solo si tu instalación
de xatlas es estable.
"""
from __future__ import annotations

import numpy as np
import trimesh


def can_bake() -> bool:
    try:
        import xatlas  # noqa: F401
        return True
    except Exception:
        return False


def bake_texture(mesh: trimesh.Trimesh, size: int = 1024):
    """Devuelve (mesh_con_uv, imagen_textura PIL) o (mesh, None) si no se puede.

    Requiere color por vértice y xatlas. No se ejecuta en el sandbox de
    desarrollo (ver documentation/NO_EJECUTADO_EN_SANDBOX.txt).
    """
    try:
        from PIL import Image
    except Exception:
        return mesh, None
    if not can_bake():
        return mesh, None
    try:
        unwrapped = mesh.unwrap()  # xatlas: puede fallar en algunos entornos
    except Exception:
        return mesh, None

    uv = getattr(unwrapped.visual, "uv", None)
    vcol = None
    try:
        vcol = np.asarray(mesh.visual.vertex_colors)[:, :3]
    except Exception:
        pass
    if uv is None or vcol is None:
        return unwrapped, None

    # Rasteriza el color de cada triángulo al mapa UV (nearest, sencillo).
    tex = np.zeros((size, size, 3), np.uint8)
    faces = np.asarray(unwrapped.faces)
    uvs = np.clip(uv, 0, 1)
    for f in faces:
        pts = (uvs[f] * (size - 1)).astype(int)
        col = vcol[f].mean(axis=0).astype(np.uint8)
        x0, y0 = pts.min(0); x1, y1 = pts.max(0)
        tex[y0:y1 + 1, x0:x1 + 1] = col
    image = Image.fromarray(tex)
    unwrapped.visual = trimesh.visual.TextureVisuals(uv=uv, image=image)
    return unwrapped, image
