"""Análisis de imprimibilidad y estimaciones.

Comprobaciones (subconjunto Fase 1, ampliable en Fase 3):
  - Malla cerrada / estanca.
  - Normales/winding consistentes (caras invertidas).
  - Componentes sueltos (objetos flotantes).
  - Paredes/relieve por debajo del diámetro de boquilla.
  - Base de apoyo (estabilidad).
  - Voladizos que probablemente necesiten soportes.
  - Dimensiones máximas y estimación aproximada de material.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import numpy as np
import trimesh

Severity = Literal["ok", "warning", "error"]


@dataclass
class Issue:
    key: str
    severity: Severity
    message: str


@dataclass
class PrintReport:
    issues: list[Issue] = field(default_factory=list)
    dimensions_mm: tuple[float, float, float] = (0, 0, 0)
    volume_cm3: float = 0.0
    est_filament_g: float = 0.0
    overhang_fraction: float = 0.0
    needs_supports: bool = False

    @property
    def printable(self) -> bool:
        return not any(i.severity == "error" for i in self.issues)

    def to_dict(self) -> dict:
        return {
            "printable": self.printable,
            "dimensions_mm": [round(v, 2) for v in self.dimensions_mm],
            "volume_cm3": round(self.volume_cm3, 2),
            "est_filament_g": round(self.est_filament_g, 1),
            "overhang_fraction": round(self.overhang_fraction, 3),
            "needs_supports": self.needs_supports,
            "issues": [
                {"key": i.key, "severity": i.severity, "message": i.message}
                for i in self.issues
            ],
        }


# densidad aproximada por material (g/cm3) para estimación de filamento
_MATERIAL_DENSITY = {
    "PLA": 1.24, "PETG": 1.27, "ABS": 1.04, "ASA": 1.07, "TPU": 1.21,
}


def analyze(
    mesh: trimesh.Trimesh,
    nozzle_diameter_mm: float = 0.4,
    material: str = "PLA",
    infill_fraction: float = 0.15,
    overhang_angle_deg: float = 45.0,
) -> PrintReport:
    report = PrintReport()
    ext = mesh.extents if mesh.extents is not None else np.zeros(3)
    report.dimensions_mm = (float(ext[0]), float(ext[1]), float(ext[2]))

    # 1) estanqueidad
    if mesh.is_watertight:
        report.issues.append(Issue("watertight", "ok", "La malla está cerrada (estanca)."))
    else:
        report.issues.append(Issue(
            "watertight", "error",
            "La malla no está cerrada: tiene agujeros o bordes abiertos. "
            "Pulsa 'Reparar para impresión'.",
        ))

    # 2) caras invertidas / winding
    if mesh.is_winding_consistent:
        report.issues.append(Issue("winding", "ok", "Orientación de caras consistente."))
    else:
        report.issues.append(Issue(
            "winding", "warning",
            "Hay caras con orientación invertida. La reparación intentará corregirlas.",
        ))

    # 3) objetos flotantes
    comps = mesh.split(only_watertight=False)
    if len(comps) > 1:
        report.issues.append(Issue(
            "components", "warning",
            f"El modelo tiene {len(comps)} piezas separadas. "
            "Se recomienda unir o quedarse con la principal.",
        ))
    else:
        report.issues.append(Issue("components", "ok", "El modelo es una sola pieza."))

    # 4) volumen / material
    if mesh.is_watertight:
        vol_mm3 = float(abs(mesh.volume))
        report.volume_cm3 = vol_mm3 / 1000.0
        density = _MATERIAL_DENSITY.get(material.upper(), 1.24)
        # material ~ (cáscaras + relleno). Aproximación conservadora.
        effective = infill_fraction + 0.35 * (1 - infill_fraction)
        report.est_filament_g = report.volume_cm3 * density * effective
    else:
        report.issues.append(Issue(
            "volume", "warning",
            "No se puede estimar el material hasta cerrar la malla.",
        ))

    # 5) rasgos finos por debajo de la boquilla
    edges = mesh.edges_unique_length if len(mesh.edges_unique) else np.array([1.0])
    if edges.size:
        p5 = float(np.percentile(edges, 5))
        if p5 < nozzle_diameter_mm:
            report.issues.append(Issue(
                "thin_features", "warning",
                f"Hay detalles de ~{p5:.2f} mm, por debajo del diámetro de "
                f"boquilla ({nozzle_diameter_mm:.2f} mm). Podrían no imprimirse.",
            ))
        else:
            report.issues.append(Issue("thin_features", "ok", "Sin detalles por debajo de la boquilla."))

    # 6) base de apoyo
    zmin = float(mesh.bounds[0][2])
    contact = mesh.vertices[np.isclose(mesh.vertices[:, 2], zmin, atol=max(0.2, ext[2] * 0.01))]
    if contact.shape[0] >= 3:
        area = _footprint_area(contact)
        base_ratio = area / max(ext[0] * ext[1], 1e-6)
        if base_ratio < 0.05:
            report.issues.append(Issue(
                "base", "warning",
                "La base de apoyo es pequeña; el modelo podría volcarse. "
                "Añade una base plana o una peana.",
            ))
        else:
            report.issues.append(Issue("base", "ok", "Base de apoyo suficiente."))
    else:
        report.issues.append(Issue("base", "warning", "No se detecta una base plana clara."))

    # 7) voladizos / soportes
    frac = _overhang_fraction(mesh, overhang_angle_deg)
    report.overhang_fraction = frac
    report.needs_supports = frac > 0.12
    if report.needs_supports:
        report.issues.append(Issue(
            "supports", "warning",
            f"~{frac*100:.0f}% de las caras son voladizos pronunciados; "
            "probablemente necesites soportes al laminar.",
        ))
    else:
        report.issues.append(Issue("supports", "ok", "Pocos voladizos; soportes mínimos."))

    return report


def _footprint_area(points_xy_z: np.ndarray) -> float:
    """Área aproximada de la huella (convex hull en XY)."""
    pts = points_xy_z[:, :2]
    if pts.shape[0] < 3:
        return 0.0
    try:
        from scipy.spatial import ConvexHull
        return float(ConvexHull(pts).volume)  # en 2D, .volume = área
    except Exception:
        min_xy = pts.min(axis=0)
        max_xy = pts.max(axis=0)
        return float((max_xy[0] - min_xy[0]) * (max_xy[1] - min_xy[1]))


def _overhang_fraction(mesh: trimesh.Trimesh, angle_deg: float) -> float:
    """Fracción de área de caras cuya normal apunta hacia abajo más allá del
    ángulo de voladizo respecto al plano de impresión (Z)."""
    normals = mesh.face_normals
    areas = mesh.area_faces
    if normals is None or len(normals) == 0:
        return 0.0
    # ángulo entre la normal y -Z
    cos_thr = np.cos(np.radians(90.0 - angle_deg))
    downward = normals[:, 2] < -cos_thr
    total = float(areas.sum())
    if total <= 0:
        return 0.0
    return float(areas[downward].sum() / total)
