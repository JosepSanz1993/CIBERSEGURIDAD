"""CLI sin GUI: genera un modelo desde una imagen. Útil para pruebas y lotes.

Ejemplo:
    python -m app.cli foto.jpg -o modelo.stl --height 120 --format stl
"""
from __future__ import annotations

import argparse
import sys

from .config import PrintSettings
from .pipeline import orchestrator
from . import exporters
from .system_probe import probe


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Photo2Print CLI (foto → 3D imprimible)")
    p.add_argument("image", nargs="+", help="Imagen(es) de entrada. 2+ activan multivista.")
    p.add_argument("-o", "--output", default="modelo.stl", help="Archivo de salida")
    p.add_argument("--format", choices=["stl", "obj", "3mf", "ply", "glb"], default="stl")
    p.add_argument("--height", type=float, default=100.0, help="Altura final en mm")
    p.add_argument("--nozzle", type=float, default=0.4, help="Diámetro de boquilla en mm")
    p.add_argument("--material", default="PLA")
    p.add_argument("--detail", type=int, default=2, choices=[1, 2, 3])
    p.add_argument("--smoothing", type=float, default=0.3)
    p.add_argument("--no-ai", action="store_true", help="Fuerza métodos básicos (sin torch/rembg)")
    # multivista (Fase 2)
    p.add_argument("--angles", type=str, default="",
                   help="Ángulos separados por comas para multivista (p.ej. 0,90,180,270)")
    p.add_argument("--resolution", type=int, default=96, help="Resolución del volumen (multivista)")
    p.add_argument("--no-color", action="store_true", help="No transferir color (multivista)")
    # postprocesado (Fase 3)
    p.add_argument("--hollow", type=float, default=0.0, help="Vaciar dejando pared de N mm")
    p.add_argument("--drain", type=float, default=0.0, help="Diámetro del agujero de drenaje en mm")
    p.add_argument("--decimate", type=int, default=0, help="Reducir a N caras")
    p.add_argument("--auto-orient", action="store_true", help="Apoyar sobre la cara mayor")
    # print pack (Fase 4)
    p.add_argument("--pack", type=str, default="", help="Directorio para exportar un print pack")
    p.add_argument("--pack-format", default="3mf", choices=["stl", "obj", "3mf", "ply", "glb"])
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    sysinfo = probe()
    settings = PrintSettings(
        target_height_mm=args.height,
        nozzle_diameter_mm=args.nozzle,
        material=args.material,
        detail_level=args.detail,
        smoothing=args.smoothing,
    )

    def prog(pct, msg):
        print(f"[{pct:3d}%] {msg}")

    if len(args.image) >= 2:
        angles = [float(a) for a in args.angles.split(",")] if args.angles else None
        result = orchestrator.generate_multiview(
            args.image, settings,
            angles=angles,
            resolution=args.resolution,
            apply_color=not args.no_color,
            prefer_rembg=not args.no_ai,
            progress=prog,
        )
    else:
        result = orchestrator.generate(
            args.image[0], settings,
            device=sysinfo.device,
            prefer_ai_depth=not args.no_ai,
            prefer_rembg=not args.no_ai,
            progress=prog,
        )
    # postprocesado opcional (Fase 3)
    if args.auto_orient or args.hollow > 0 or args.decimate > 0:
        result.mesh = orchestrator.apply_postprocess(
            result.mesh,
            auto_orient=args.auto_orient,
            hollow_mm=args.hollow,
            drain_mm=args.drain,
            decimate_faces=args.decimate,
            progress=prog,
        )

    out = exporters.export(result.mesh, args.output, args.format)
    print("Métodos:", result.methods)
    print("Imprimible:", result.report.printable,
          "| Dimensiones mm:", [round(v, 1) for v in result.report.dimensions_mm])
    for w in result.warnings:
        print("Aviso:", w)
    print("Guardado:", out)

    if args.pack:
        from .pipeline import printpack
        info = printpack.export_print_pack(
            result.mesh, args.pack, settings, model_format=args.pack_format
        )
        print("Print pack en:", info["dir"])
        print("  archivos:", ", ".join(__import__("os").path.basename(f) for f in info["files"]))
        print("  estimación:", info["estimate"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
