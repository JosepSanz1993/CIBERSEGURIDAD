"""Exportadores de malla a formatos de impresión."""
from __future__ import annotations

from pathlib import Path

import trimesh


class ExportError(Exception):
    """Error legible para la UI cuando falla una exportación."""


def export_stl(mesh: trimesh.Trimesh, path: str | Path) -> Path:
    """STL binario. No almacena color ni textura."""
    path = Path(path).with_suffix(".stl")
    try:
        mesh.export(path, file_type="stl")  # trimesh escribe STL binario
    except Exception as exc:  # noqa: BLE001
        raise ExportError(f"No se pudo exportar STL: {exc}") from exc
    return path


def export_obj(mesh: trimesh.Trimesh, path: str | Path) -> Path:
    """OBJ (con textura/UV si la malla las tiene)."""
    path = Path(path).with_suffix(".obj")
    try:
        mesh.export(path, file_type="obj")
    except Exception as exc:  # noqa: BLE001
        raise ExportError(f"No se pudo exportar OBJ: {exc}") from exc
    return path


def export_3mf(mesh: trimesh.Trimesh, path: str | Path) -> Path:
    """3MF compatible con Bambu Studio.

    trimesh escribe 3MF con unidades en milimetros. Se conservan escala y
    orientacion. Colores/partes separadas se ampliaran en Fase 2/3.
    """
    path = Path(path).with_suffix(".3mf")
    try:
        mesh.export(path, file_type="3mf")
    except Exception as exc:  # noqa: BLE001
        raise ExportError(
            f"No se pudo exportar 3MF: {exc}. Exporta STL como alternativa."
        ) from exc
    return path


def export_ply(mesh: trimesh.Trimesh, path: str | Path) -> Path:
    """PLY: conserva el color por vértice (ideal para revisar el color en mm)."""
    path = Path(path).with_suffix(".ply")
    try:
        mesh.export(path, file_type="ply")
    except Exception as exc:  # noqa: BLE001
        raise ExportError(f"No se pudo exportar PLY: {exc}") from exc
    return path


def export_glb(mesh: trimesh.Trimesh, path: str | Path) -> Path:
    """GLB: geometría + color por vértice en un único archivo (previsualización)."""
    path = Path(path).with_suffix(".glb")
    try:
        mesh.export(path, file_type="glb")
    except Exception as exc:  # noqa: BLE001
        raise ExportError(f"No se pudo exportar GLB: {exc}") from exc
    return path


EXPORTERS = {
    "stl": export_stl,
    "obj": export_obj,
    "3mf": export_3mf,
    "ply": export_ply,
    "glb": export_glb,
}

# Formatos que conservan color por vértice.
COLOR_FORMATS = ("ply", "glb")


def export(mesh: trimesh.Trimesh, path: str | Path, fmt: str) -> Path:
    fmt = fmt.lower().lstrip(".")
    if fmt not in EXPORTERS:
        raise ExportError(f"Formato no soportado: {fmt}")
    return EXPORTERS[fmt](mesh, path)
