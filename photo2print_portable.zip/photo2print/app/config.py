"""Configuración central: rutas de la aplicación y ajustes por defecto."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path


APP_DIRNAME = "Photo2Print"


def _base_data_dir() -> Path:
    """Directorio de datos por plataforma (modelos, cache, ajustes)."""
    home = Path.home()
    if os.name == "nt":
        root = Path(os.environ.get("APPDATA", home / "AppData" / "Roaming"))
    elif os.sys.platform == "darwin":
        root = home / "Library" / "Application Support"
    else:
        root = Path(os.environ.get("XDG_DATA_HOME", home / ".local" / "share"))
    return root / APP_DIRNAME


DATA_DIR = _base_data_dir()
MODELS_DIR = DATA_DIR / "models"
CACHE_DIR = DATA_DIR / "cache"
LOG_DIR = DATA_DIR / "logs"
SETTINGS_FILE = DATA_DIR / "settings.json"

for _d in (DATA_DIR, MODELS_DIR, CACHE_DIR, LOG_DIR):
    try:
        _d.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass


SUPPORTED_IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".bmp", ".tiff")


@dataclass
class PrintSettings:
    """Parámetros de preparación para impresión (subconjunto Fase 1)."""
    target_height_mm: float = 100.0     # altura final del modelo
    max_width_mm: float = 0.0           # 0 = sin límite (se deriva de la altura)
    max_depth_mm: float = 0.0
    nozzle_diameter_mm: float = 0.4
    material: str = "PLA"               # PLA/PETG/ABS/ASA/TPU
    solid: bool = True                  # sólido (Fase 1). Hueco -> Fase 3
    wall_thickness_mm: float = 1.2
    detail_level: int = 2               # 1..3 (afecta resolución de malla)
    smoothing: float = 0.3              # 0..1
    add_base: bool = True               # cara plana inferior + base
    base_thickness_mm: float = 3.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class AppSettings:
    language: str = "es"                # "es" | "en"
    theme: str = "dark"                 # "dark" | "light"
    processing_mode: str = "local"      # "local" | "remote"
    allow_remote_upload: bool = False   # nunca subir imágenes sin permiso
    last_project_dir: str = field(default_factory=lambda: str(Path.home()))
    telemetry_enabled: bool = False     # desactivada por defecto

    @classmethod
    def load(cls) -> "AppSettings":
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            known = {k: data[k] for k in cls().__dict__ if k in data}
            return cls(**known)
        except (OSError, ValueError, TypeError):
            return cls()

    def save(self) -> None:
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as fh:
                json.dump(asdict(self), fh, indent=2, ensure_ascii=False)
        except OSError:
            pass
