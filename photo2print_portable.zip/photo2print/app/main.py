"""Punto de arranque de la aplicación de escritorio."""
from __future__ import annotations

import sys

from .config import AppSettings
from .logging_setup import setup_logging
from .system_probe import probe
from . import i18n


def _selfcheck() -> int:
    """Valida que las librerías críticas cargan dentro del paquete (sin GUI).

    Se usa tras empaquetar (installers/*/verify_build) y en CI. Devuelve 0 si
    todo carga; 1 si falta algo esencial.
    """
    essentials = ["numpy", "PIL", "trimesh", "scipy", "skimage", "shapely"]
    optional = ["fast_simplification", "pyvista", "pyvistaqt", "vtkmodules",
                "rembg", "torch", "pillow_heif", "manifold3d", "pymeshlab", "xatlas"]
    import importlib
    ok = True
    for m in essentials:
        try:
            importlib.import_module(m)
            print(f"[ok]   {m}")
        except Exception as exc:  # noqa: BLE001
            ok = False
            print(f"[FALTA] {m}: {exc}")
    for m in optional:
        try:
            importlib.import_module(m)
            print(f"[ok]   {m} (opcional)")
        except Exception:
            print(f"[--]   {m} (opcional, no instalado)")
    # comprobación funcional mínima del núcleo geométrico
    try:
        import trimesh
        from skimage.measure import marching_cubes  # noqa: F401
        _ = trimesh.creation.box().is_watertight
        print("[ok]   núcleo geométrico operativo")
    except Exception as exc:  # noqa: BLE001
        ok = False
        print(f"[FALTA] núcleo geométrico: {exc}")
    print("RESULTADO:", "OK" if ok else "FALLO")
    return 0 if ok else 1


def main() -> int:
    if "--selfcheck" in sys.argv:
        return _selfcheck()

    log = setup_logging()
    settings = AppSettings.load()
    i18n.set_language(settings.language)

    sysinfo = probe()
    log.info("Sistema: %s", sysinfo.to_dict())

    # Import diferido de Qt para poder ejecutar utilidades sin GUI.
    from PySide6.QtWidgets import QApplication, QMessageBox
    from .ui.main_window import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName("Photo2Print")

    win = MainWindow(settings, sysinfo)

    # Recuperación tras cierre inesperado.
    try:
        from .project import Project
        recovered = Project.recover_autosave()
        if recovered is not None:
            proj, _mesh = recovered
            if proj.image_paths:
                res = QMessageBox.question(
                    win, "Recuperar proyecto",
                    "Se encontró un proyecto sin guardar de una sesión anterior. "
                    "¿Quieres recuperarlo?",
                )
                if res == QMessageBox.StandardButton.Yes:
                    win.import_step.image_path = proj.image_paths[0]
                    try:
                        from .pipeline import images as im
                        win.import_step.rgb = im.to_rgb(im.load_image(proj.image_paths[0]))
                        win.import_step.view.show_array(win.import_step.rgb)
                        win.import_step.btn_removebg.setEnabled(True)
                    except Exception:
                        pass
    except Exception as exc:  # noqa: BLE001
        log.warning("Recuperación no disponible: %s", exc)

    win.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
