"""Modelo de proyecto y persistencia (.p2p).

Un .p2p es un ZIP con:
  - project.json  (metadatos + ajustes de impresión)
  - images/       (copias de las imágenes importadas)
  - mesh.stl      (última malla generada, si existe)

Permite reabrir y editar, y sirve de base para la recuperación tras un
cierre inesperado (se guarda un autosave en la carpeta de cache).
"""
from __future__ import annotations

import json
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

from . import __version__
from .config import CACHE_DIR, PrintSettings

MODEL_TYPES = [
    "persona_completa", "busto", "cabeza", "mascota", "objeto",
    "figura_artistica", "relieve",
]


@dataclass
class Project:
    name: str = "Proyecto sin título"
    model_type: str = "relieve"
    image_paths: list[str] = field(default_factory=list)
    print_settings: PrintSettings = field(default_factory=PrintSettings)
    generation_mode: str = "rapido"      # rapido | preciso | busto | figura | relieve | asistido
    app_version: str = __version__
    file_path: Optional[str] = None      # ruta del .p2p en disco

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("file_path", None)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "Project":
        ps = data.get("print_settings", {})
        known_ps = {k: ps[k] for k in PrintSettings().__dict__ if k in ps}
        proj = cls(
            name=data.get("name", "Proyecto sin título"),
            model_type=data.get("model_type", "relieve"),
            image_paths=list(data.get("image_paths", [])),
            print_settings=PrintSettings(**known_ps),
            generation_mode=data.get("generation_mode", "rapido"),
            app_version=data.get("app_version", __version__),
        )
        return proj

    # ---- persistencia ----

    def save(self, path: str | Path, mesh_stl_bytes: Optional[bytes] = None) -> Path:
        path = Path(path).with_suffix(".p2p")
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp / "images").mkdir()
            stored_images = []
            for i, img in enumerate(self.image_paths):
                src = Path(img)
                if src.exists():
                    dst = tmp / "images" / f"{i:02d}{src.suffix.lower()}"
                    shutil.copy2(src, dst)
                    stored_images.append(f"images/{dst.name}")
            meta = self.to_dict()
            meta["image_paths_internal"] = stored_images
            (tmp / "project.json").write_text(
                json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            if mesh_stl_bytes:
                (tmp / "mesh.stl").write_bytes(mesh_stl_bytes)
            with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in tmp.rglob("*"):
                    if f.is_file():
                        zf.write(f, f.relative_to(tmp))
        self.file_path = str(path)
        return path

    @classmethod
    def load(cls, path: str | Path) -> tuple["Project", Optional[bytes]]:
        path = Path(path)
        extract_dir = CACHE_DIR / f"open_{path.stem}"
        if extract_dir.exists():
            shutil.rmtree(extract_dir, ignore_errors=True)
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(extract_dir)
        meta = json.loads((extract_dir / "project.json").read_text(encoding="utf-8"))
        proj = cls.from_dict(meta)
        # rehidrata rutas de imagen a las copias internas
        internal = meta.get("image_paths_internal", [])
        proj.image_paths = [str(extract_dir / p) for p in internal]
        proj.file_path = str(path)
        mesh_bytes = None
        mesh_file = extract_dir / "mesh.stl"
        if mesh_file.exists():
            mesh_bytes = mesh_file.read_bytes()
        return proj, mesh_bytes

    def autosave(self, mesh_stl_bytes: Optional[bytes] = None) -> Path:
        return self.save(CACHE_DIR / "autosave", mesh_stl_bytes)

    @classmethod
    def recover_autosave(cls) -> Optional[tuple["Project", Optional[bytes]]]:
        auto = CACHE_DIR / "autosave.p2p"
        if auto.exists():
            try:
                return cls.load(auto)
            except Exception:
                return None
        return None
