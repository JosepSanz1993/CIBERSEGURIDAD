"""Interfaz gráfica **web local** de Photo2Print (portable, sin toolkit pesado).

Levanta un servidor en 127.0.0.1 y sirve una página donde arrastrar una foto,
ajustar parámetros y generar/descargar el modelo (STL/OBJ/3MF/PLY/GLB) con una
vista previa. Reutiliza el mismo pipeline probado (orchestrator/exporters).

Solo usa la librería estándar para la parte web (http.server, json, base64),
así que no añade dependencias nuevas. Ejecuta:  python run_web.py
"""
from __future__ import annotations

import base64
import numpy as np
import json
import socket
import sys
import tempfile
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .config import PrintSettings
from .pipeline import orchestrator
from . import exporters
from .logging_setup import setup_logging

_LOG = setup_logging()
_SESSIONS: dict[str, Path] = {}
_MIME = {
    "stl": "model/stl", "obj": "text/plain", "3mf": "model/3mf",
    "ply": "application/octet-stream", "glb": "model/gltf-binary",
    "png": "image/png",
}

PAGE = """<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Photo2Print</title>
<style>
  :root { --bg:#0f1420; --card:#171d2b; --ink:#e8ecf4; --mut:#93a0b8; --acc:#5b8cff; --line:#263149; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--ink);
         font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif; }
  header { padding:18px 24px; border-bottom:1px solid var(--line); display:flex; align-items:baseline; gap:12px; }
  header h1 { font-size:18px; margin:0; letter-spacing:.3px; }
  header span { color:var(--mut); font-size:13px; }
  main { max-width:960px; margin:0 auto; padding:24px; display:grid; grid-template-columns:1fr 1fr; gap:20px; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:12px; padding:18px; }
  h2 { font-size:14px; text-transform:uppercase; letter-spacing:.6px; color:var(--mut); margin:0 0 14px; }
  #drop { border:2px dashed var(--line); border-radius:10px; padding:26px; text-align:center; color:var(--mut);
          cursor:pointer; transition:.15s; }
  #drop.hover { border-color:var(--acc); color:var(--ink); background:#1b2334; }
  #thumb { max-width:100%; max-height:220px; border-radius:8px; margin-top:12px; display:none; }
  label { display:block; font-size:13px; color:var(--mut); margin:12px 0 4px; }
  input[type=number], select { width:100%; padding:8px 10px; background:#0f1524; color:var(--ink);
          border:1px solid var(--line); border-radius:8px; }
  .row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .chk { display:flex; align-items:center; gap:8px; margin-top:12px; color:var(--ink); font-size:14px; }
  button { margin-top:16px; width:100%; padding:12px; border:0; border-radius:9px; background:var(--acc);
           color:white; font-weight:600; font-size:15px; cursor:pointer; }
  button:disabled { opacity:.5; cursor:default; }
  #preview { width:100%; border-radius:8px; background:#0f1524; display:none; }
  #stats { font-size:13px; color:var(--mut); margin-top:12px; white-space:pre-line; }
  .dl { display:inline-block; margin:6px 8px 0 0; padding:8px 12px; background:#22304d; color:var(--ink);
        border-radius:8px; text-decoration:none; font-size:14px; }
  .warn { color:#ffcf7a; font-size:13px; margin-top:10px; }
  .spin { display:none; margin-top:14px; color:var(--mut); }
</style></head><body>
<header><h1>Photo2Print</h1><span>foto → relieve 3D imprimible · local</span></header>
<main>
  <section class="card">
    <h2>1 · Tu foto</h2>
    <div id="drop">Arrastra una imagen aquí<br>o haz clic para elegir</div>
    <input id="file" type="file" accept="image/*" hidden>
    <img id="thumb">
    <h2 style="margin-top:20px">2 · Ajustes</h2>
    <div class="row">
      <div><label>Altura (mm)</label><input id="height" type="number" value="120" min="10" max="300"></div>
      <div><label>Material</label>
        <select id="material"><option>PLA</option><option>PETG</option><option>ABS</option><option>TPU</option></select></div>
    </div>
    <div class="row">
      <div><label>Detalle</label><select id="detail"><option value="1">Bajo</option><option value="2" selected>Medio</option><option value="3">Alto</option></select></div>
      <div><label>Relieve (mm)</label><input id="relief" type="number" value="4" step="0.5" min="0.5"></div>
    </div>
    <label class="chk"><input id="lithophane" type="checkbox"> Litofanía (para iluminar por detrás: lo oscuro se hace más grueso)</label>
    <button id="go" disabled>Generar 3D</button>
    <div class="spin" id="spin">Generando… (puede tardar unos segundos)</div>
  </section>
  <section class="card">
    <h2>3 · Resultado</h2>
    <img id="preview">
    <div id="stats">Sube una foto y pulsa «Generar 3D».</div>
    <div id="downloads"></div>
    <div class="warn" id="warns"></div>
  </section>
</main>
<script>
let imgData = null;
const drop=document.getElementById('drop'), file=document.getElementById('file'),
      thumb=document.getElementById('thumb'), go=document.getElementById('go');
drop.onclick=()=>file.click();
['dragover','dragenter'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.add('hover');}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.remove('hover');}));
drop.addEventListener('drop',ev=>{ if(ev.dataTransfer.files[0]) load(ev.dataTransfer.files[0]); });
file.onchange=()=>{ if(file.files[0]) load(file.files[0]); };
function load(f){ const r=new FileReader(); r.onload=()=>{ imgData=r.result; thumb.src=imgData; thumb.style.display='block';
  drop.textContent='Imagen cargada ✔ (clic para cambiar)'; go.disabled=false; }; r.readAsDataURL(f); }

go.onclick=async ()=>{
  if(!imgData) return;
  go.disabled=true; document.getElementById('spin').style.display='block';
  document.getElementById('downloads').innerHTML=''; document.getElementById('warns').textContent='';
  document.getElementById('stats').textContent='Procesando…';
  const body={ image:imgData,
    height:+document.getElementById('height').value, material:document.getElementById('material').value,
    detail:+document.getElementById('detail').value,
    relief:+document.getElementById('relief').value,
    lithophane: document.getElementById('lithophane').checked };
  try{
    const res=await fetch('/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const j=await res.json();
    if(!j.ok){ document.getElementById('stats').textContent='Error: '+j.error; }
    else{
      const p=document.getElementById('preview'); p.src=j.preview; p.style.display='block';
      document.getElementById('stats').textContent=j.stats;
      let dl=''; for(const f of j.formats){ dl+=`<a class="dl" href="/download?id=${j.id}&fmt=${f}" download="modelo.${f}">⬇ ${f.toUpperCase()}</a>`; }
      document.getElementById('downloads').innerHTML=dl;
      document.getElementById('warns').textContent=(j.warnings||[]).join('  ·  ');
    }
  }catch(e){ document.getElementById('stats').textContent='Error de red: '+e; }
  document.getElementById('spin').style.display='none'; go.disabled=false;
};
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # silencia el log ruidoso por petición
        pass

    def _send(self, code, ctype, body: bytes, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/" or self.path.startswith("/index"):
            self._send(200, "text/html; charset=utf-8", PAGE.encode("utf-8"))
        elif self.path.startswith("/download"):
            self._download()
        else:
            self._send(404, "text/plain", b"not found")

    def _download(self):
        from urllib.parse import urlparse, parse_qs
        q = parse_qs(urlparse(self.path).query)
        sid = (q.get("id") or [""])[0]
        fmt = (q.get("fmt") or [""])[0]
        d = _SESSIONS.get(sid)
        if not d:
            self._send(404, "text/plain", b"sesion no encontrada"); return
        f = d / f"model.{fmt}"
        if not f.exists():
            self._send(404, "text/plain", b"archivo no encontrado"); return
        self._send(200, _MIME.get(fmt, "application/octet-stream"), f.read_bytes(),
                   extra={"Content-Disposition": f'attachment; filename="modelo.{fmt}"'})

    def do_POST(self):
        if self.path != "/generate":
            self._send(404, "text/plain", b"not found"); return
        try:
            n = int(self.headers.get("Content-Length", 0))
            payload = json.loads(self.rfile.read(n).decode("utf-8"))
            out = _generate(payload)
            self._send(200, "application/json", json.dumps(out).encode("utf-8"))
        except Exception as exc:  # noqa: BLE001
            _LOG.exception("Fallo en /generate")
            self._send(200, "application/json",
                       json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"))


def _guess_ext(raw: bytes) -> str:
    """Adivina la extensión por la cabecera del archivo (para guardar bien)."""
    if raw[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return ".webp"
    if raw[:2] in (b"BM",):
        return ".bmp"
    if raw[:4] in (b"II*\x00", b"MM\x00*"):
        return ".tiff"
    if raw[4:12] in (b"ftypheic", b"ftypheix", b"ftypmif1", b"ftypmsf1"):
        return ".heic"
    return ".png"


def _generate(payload: dict) -> dict:
    from .pipeline import render_preview, printpack, photo_relief
    from .pipeline import images as images_mod

    data_url = payload["image"]
    b64 = data_url.split(",", 1)[1] if "," in data_url else data_url
    raw = base64.b64decode(b64)

    sid = uuid.uuid4().hex[:12]
    d = Path(tempfile.gettempdir()) / "photo2print_web" / sid
    d.mkdir(parents=True, exist_ok=True)
    _SESSIONS[sid] = d
    img_path = d / ("input" + _guess_ext(raw))
    img_path.write_bytes(raw)

    settings = PrintSettings(
        target_height_mm=float(payload.get("height", 120)),
        material=str(payload.get("material", "PLA")),
        detail_level=int(payload.get("detail", 2)),
        nozzle_diameter_mm=float(payload.get("nozzle", 0.4)),
    )

    # Foto → relieve 3D fiel (opción A): cualquier imagen se convierte en un
    # relieve reconocible por mapa de alturas. Sin IA ni segmentación.
    rgb = images_mod.to_rgb(images_mod.load_image(str(img_path)))
    mesh = photo_relief.heightmap_relief(
        rgb,
        height_mm=settings.target_height_mm,
        relief_mm=float(payload.get("relief", 4.0)),
        base_mm=float(payload.get("base", 2.0)),
        invert=bool(payload.get("lithophane", False)),
        detail=settings.detail_level,
    )

    hollow = float(payload.get("hollow", 0) or 0)
    if hollow > 0:
        mesh = orchestrator.apply_postprocess(mesh, hollow_mm=hollow)

    warnings_list: list[str] = []

    # Exporta cada formato de forma independiente: si uno falla (p.ej. 3MF sin
    # lxml), NO debe impedir los demás. El STL siempre se genera.
    formats = []
    export_errors = []
    for fmt in ["stl", "obj", "3mf"]:
        try:
            exporters.export(mesh, d / "model", fmt)
            formats.append(fmt)
        except Exception as exc:  # noqa: BLE001
            export_errors.append(f"{fmt.upper()}: {exc}")
            _LOG.warning("Export %s falló: %s", fmt, exc)
    if not formats:
        raise RuntimeError("No se pudo exportar ningún formato: " + " | ".join(export_errors))

    preview_data = ""
    try:
        e = mesh.extents
        relief = max(float(payload.get("relief", 4.0)), 0.5)
        # Exagera la profundidad solo para que el relieve se vea en la miniatura.
        factor = float(np.clip((0.35 * max(e[0], e[1])) / relief, 2.0, 10.0))
        render_preview.save_png(mesh, d / "preview.png", size=560,
                                azim_deg=28, elev_deg=30, z_exaggerate=factor)
        preview_data = "data:image/png;base64," + base64.b64encode((d / "preview.png").read_bytes()).decode("ascii")
    except Exception as exc:  # noqa: BLE001
        _LOG.warning("Preview falló: %s", exc)

    try:
        est = printpack.estimate(mesh, settings)
        dims = est.bbox_mm
        stats = (
            f"Estanco (imprimible): {'sí' if mesh.is_watertight else 'revisar'}\n"
            f"Dimensiones: {dims[0]} × {dims[1]} × {dims[2]} mm\n"
            f"Material aprox.: {est.filament_g} g (~{est.filament_m} m) de {settings.material}\n"
            f"Caras: {len(mesh.faces):,}"
        )
    except Exception as exc:  # noqa: BLE001
        _LOG.warning("Estimación falló: %s", exc)
        e = mesh.extents
        stats = (f"Dimensiones: {round(float(e[0]),1)} × {round(float(e[1]),1)} × "
                 f"{round(float(e[2]),1)} mm\nCaras: {len(mesh.faces):,}")

    warnings = list(warnings_list)
    if export_errors:
        warnings.append("Algunos formatos no se pudieron exportar (se usó STL). "
                        + " · ".join(export_errors))
    return {
        "ok": True, "id": sid, "formats": formats,
        "preview": preview_data,
        "stats": stats, "warnings": warnings,
    }


def _free_port(preferred=8765) -> int:
    for port in (preferred, 8766, 8770, 0):
        try:
            s = socket.socket(); s.bind(("127.0.0.1", port)); p = s.getsockname()[1]; s.close(); return p
        except OSError:
            continue
    return 0


def run(host: str = "127.0.0.1", port: int | None = None, open_browser: bool = True) -> None:
    # En apps empaquetadas "de ventana" (.app en macOS, --windowed), PyInstaller
    # deja sys.stdout/err en None; cualquier print() reventaría la app al
    # arrancar. Lo blindamos redirigiendo a /dev/null si hiciera falta.
    import os
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w")
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w")

    port = port or _free_port()
    server = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}/"
    print("=" * 54, flush=True)
    print("  Photo2Print — interfaz web local", flush=True)
    print(f"  Abre en tu navegador:  {url}", flush=True)
    print("  (deja esta ventana abierta; Ctrl+C para salir)", flush=True)
    print("=" * 54, flush=True)
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando…")
        server.shutdown()


if __name__ == "__main__":
    run()
