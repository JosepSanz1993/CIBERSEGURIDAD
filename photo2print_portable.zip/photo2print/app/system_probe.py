"""Detección automática de capacidades del equipo.

Se usa para elegir modelo de IA y resolución apropiados, y para decidir
si se ejecuta la inferencia en GPU o CPU. Todo es best-effort: si una
dependencia opcional no está, se degrada con elegancia y nunca lanza.
"""
from __future__ import annotations

import os
import platform
import shutil
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class SystemInfo:
    os_name: str
    os_version: str
    arch: str                 # "x86_64", "arm64", ...
    cpu_count: int
    ram_gb: float
    disk_free_gb: float
    has_cuda: bool
    has_mps: bool             # Apple Silicon GPU (Metal)
    gpu_name: Optional[str]
    vram_gb: Optional[float]

    @property
    def device(self) -> str:
        """Dispositivo de inferencia recomendado para PyTorch/ONNX."""
        if self.has_cuda:
            return "cuda"
        if self.has_mps:
            return "mps"
        return "cpu"

    @property
    def quality_tier(self) -> str:
        """Nivel de calidad sugerido segun potencia disponible.

        low   -> equipos modestos / solo CPU con poca RAM
        medium-> CPU decente o GPU pequena
        high  -> GPU con >= 6 GB de VRAM
        """
        if (self.has_cuda or self.has_mps) and (self.vram_gb or 0) >= 6:
            return "high"
        if self.ram_gb >= 12 or self.has_cuda or self.has_mps:
            return "medium"
        return "low"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["device"] = self.device
        d["quality_tier"] = self.quality_tier
        return d


def _ram_gb() -> float:
    try:
        import psutil  # optional
        return round(psutil.virtual_memory().total / (1024 ** 3), 1)
    except Exception:
        pass
    # POSIX fallback
    try:
        pages = os.sysconf("SC_PHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        return round(pages * page_size / (1024 ** 3), 1)
    except (ValueError, OSError, AttributeError):
        return 0.0


def _disk_free_gb(path: str) -> float:
    try:
        return round(shutil.disk_usage(path).free / (1024 ** 3), 1)
    except OSError:
        return 0.0


def _gpu_info() -> tuple[bool, bool, Optional[str], Optional[float]]:
    has_cuda = has_mps = False
    gpu_name: Optional[str] = None
    vram_gb: Optional[float] = None
    try:
        import torch  # optional heavy dependency
        if torch.cuda.is_available():
            has_cuda = True
            gpu_name = torch.cuda.get_device_name(0)
            props = torch.cuda.get_device_properties(0)
            vram_gb = round(props.total_memory / (1024 ** 3), 1)
        elif getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            has_mps = True
            gpu_name = "Apple Silicon GPU (Metal)"
    except Exception:
        pass
    return has_cuda, has_mps, gpu_name, vram_gb


def probe(reference_path: Optional[str] = None) -> SystemInfo:
    """Recolecta información del sistema. Nunca lanza excepción."""
    reference_path = reference_path or os.path.expanduser("~")
    has_cuda, has_mps, gpu_name, vram_gb = _gpu_info()
    return SystemInfo(
        os_name=platform.system(),
        os_version=platform.release(),
        arch=platform.machine(),
        cpu_count=os.cpu_count() or 1,
        ram_gb=_ram_gb(),
        disk_free_gb=_disk_free_gb(reference_path),
        has_cuda=has_cuda,
        has_mps=has_mps,
        gpu_name=gpu_name,
        vram_gb=vram_gb,
    )


if __name__ == "__main__":
    import json
    print(json.dumps(probe().to_dict(), indent=2, ensure_ascii=False))
