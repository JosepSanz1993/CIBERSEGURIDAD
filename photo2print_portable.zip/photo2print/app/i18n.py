"""Internacionalización mínima (ES/EN) sin dependencias externas.

Uso:  from app.i18n import tr;  tr("import")  -> texto en el idioma activo.
Para Fase 4 se puede migrar a Qt Linguist (.ts/.qm); esta capa mantiene la
API estable.
"""
from __future__ import annotations

_LANG = "es"

_STRINGS: dict[str, dict[str, str]] = {
    "es": {
        "app_title": "Photo2Print — Foto a 3D imprimible",
        "new_project": "Nuevo proyecto",
        "open_project": "Abrir proyecto",
        "save_project": "Guardar proyecto",
        "recent_projects": "Proyectos recientes",
        "step_import": "Importar",
        "step_generate": "Generar",
        "step_review": "Revisar",
        "step_repair": "Reparar",
        "step_export": "Exportar",
        "import_image": "Importar imagen",
        "remove_bg": "Eliminar fondo",
        "grow_mask": "Ampliar selección",
        "shrink_mask": "Reducir selección",
        "generate_3d": "Generar 3D",
        "height_mm": "Altura (mm)",
        "nozzle_mm": "Boquilla (mm)",
        "material": "Material",
        "detail": "Nivel de detalle",
        "smoothing": "Suavizado",
        "repair_for_print": "Reparar para impresión",
        "check_print": "Comprobar impresión",
        "export": "Exportar",
        "open_in_bambu": "Abrir en Bambu Studio",
        "cancel": "Cancelar",
        "processing": "Procesando…",
        "done": "Listo",
        "error": "Error",
        "model_type": "Tipo de modelo",
        "language": "Idioma",
        "theme": "Tema",
        "settings": "Configuración",
        "warn_back_flat": (
            "Aviso: con una sola foto no hay información de la parte trasera. "
            "Se ha generado una espalda plana aproximada."
        ),
    },
    "en": {
        "app_title": "Photo2Print — Photo to printable 3D",
        "new_project": "New project",
        "open_project": "Open project",
        "save_project": "Save project",
        "recent_projects": "Recent projects",
        "step_import": "Import",
        "step_generate": "Generate",
        "step_review": "Review",
        "step_repair": "Repair",
        "step_export": "Export",
        "import_image": "Import image",
        "remove_bg": "Remove background",
        "grow_mask": "Grow selection",
        "shrink_mask": "Shrink selection",
        "generate_3d": "Generate 3D",
        "height_mm": "Height (mm)",
        "nozzle_mm": "Nozzle (mm)",
        "material": "Material",
        "detail": "Detail level",
        "smoothing": "Smoothing",
        "repair_for_print": "Repair for printing",
        "check_print": "Check printability",
        "export": "Export",
        "open_in_bambu": "Open in Bambu Studio",
        "cancel": "Cancel",
        "processing": "Processing…",
        "done": "Done",
        "error": "Error",
        "model_type": "Model type",
        "language": "Language",
        "theme": "Theme",
        "settings": "Settings",
        "warn_back_flat": (
            "Note: a single photo has no information about the back side. "
            "An approximate flat back has been generated."
        ),
    },
}


def set_language(lang: str) -> None:
    global _LANG
    if lang in _STRINGS:
        _LANG = lang


def get_language() -> str:
    return _LANG


def tr(key: str) -> str:
    return _STRINGS.get(_LANG, _STRINGS["es"]).get(key, key)
