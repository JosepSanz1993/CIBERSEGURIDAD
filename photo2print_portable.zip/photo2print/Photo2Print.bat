@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Photo2Print

echo ============================================================
echo   Photo2Print - interfaz web local
echo ============================================================
echo.

REM --- 1) Detectar Python (primero el lanzador py, luego python) ---
set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY (
  python --version >nul 2>nul && set "PY=python"
)
if not defined PY goto no_python

echo Python detectado:
%PY% --version
echo.

REM --- 2) Crear el entorno la primera vez ---
if exist ".venv\Scripts\python.exe" goto have_venv

echo Primera ejecucion: creando entorno virtual (una sola vez)...
%PY% -m venv .venv
if not exist ".venv\Scripts\python.exe" goto venv_fail

echo Instalando dependencias de la interfaz web (puede tardar 2-5 min)...
echo Se guarda un registro en setup_log.txt
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements-web.txt > setup_log.txt 2>&1
  type setup_log.txt
".venv\Scripts\python.exe" -c "import numpy,PIL,trimesh,scipy" 2>nul
if errorlevel 1 goto pip_fail

:have_venv
echo.
echo Iniciando Photo2Print... se abrira en tu navegador.
echo Deja esta ventana abierta mientras uses la aplicacion (Ctrl+C para salir).
echo.
".venv\Scripts\python.exe" run_web.py
goto end

:no_python
echo [ERROR] No se ha encontrado Python.
echo.
echo Instala Python 3.10 - 3.12 desde:
echo    https://www.python.org/downloads/windows/
echo y marca la casilla "Add python.exe to PATH" durante la instalacion.
echo.
echo Alternativa sin instalar Python: modo portable con Python embebido,
echo ver documentation\PORTABLE.md (bootstrap_windows_portable.ps1).
goto end

:venv_fail
echo [ERROR] No se pudo crear el entorno virtual .venv
echo.
echo Causa habitual: "python" es el acceso directo de la Microsoft Store
echo (no un Python real). Solucion:
echo   1) Instala Python real desde python.org (marca Add to PATH), o
echo   2) Desactiva el alias: Configuracion ^> Aplicaciones ^>
echo      Alias de ejecucion de aplicaciones ^> desactiva "python.exe".
goto end

:pip_fail
echo [ERROR] Fallo al instalar dependencias.
echo Abre setup_log.txt en esta carpeta y pega aqui las ultimas lineas.
echo (Si usas Python 3.13, prueba con Python 3.12, que tiene mejor soporte.)
goto end

:end
echo.
pause
endlocal
