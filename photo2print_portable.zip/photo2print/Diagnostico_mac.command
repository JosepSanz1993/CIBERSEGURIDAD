#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "=== Diagnostico Photo2Print (macOS) ===" | tee diagnostico.txt
{
  echo "Fecha: $(date)"
  echo "-- python disponibles --"
  for c in python3.12 python3.11 python3.10 python3 python; do
    command -v "$c" >/dev/null 2>&1 && echo "$c -> $($c --version 2>&1)"
  done
  echo "-- existe .venv --"
  [ -x ".venv/bin/python" ] && echo "SI" || echo "NO"
  echo "-- imports en .venv --"
  [ -x ".venv/bin/python" ] && ./.venv/bin/python -c "import numpy,PIL,trimesh,scipy,skimage,shapely;print('imports OK')" 2>&1
} | tee -a diagnostico.txt
echo ""
echo "Se ha creado diagnostico.txt. Copia su contenido para poder ayudarte."
read -p "Pulsa Enter para cerrar..."
