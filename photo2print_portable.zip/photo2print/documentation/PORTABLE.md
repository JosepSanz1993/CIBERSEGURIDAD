# Uso portable (sin instalar la app)

## macOS — la forma que SIEMPRE funciona (recomendada)
En Finder, haz **clic derecho → Abrir** sobre **`Photo2Print.command`** (la
primera vez usa clic derecho para saltar el aviso de seguridad; después vale el
doble clic).

- Se abre una **ventana de Terminal** que muestra la dirección local y arranca
  la app en tu navegador. La primera vez prepara su entorno (2–5 min).
- **Deja esa ventana abierta** mientras uses la app. Para cerrarla: `Ctrl+C` o
  cierra la ventana.
- Si algo falla, la ventana **muestra el error**: cópiamelo y lo arreglamos.
  También puedes ejecutar **`Diagnostico_mac.command`** y pegar `diagnostico.txt`.

> ¿Por qué esta y no el `.app`? El binario/`.app` empaquetado depende de detalles
> de macOS (Gatekeeper, firma) difíciles de acertar a ciegas. El
> `Photo2Print.command` es transparente: ves qué pasa y funciona con Python 3
> instalado (gratis desde python.org si no lo tienes).

---


Photo2Print puede usarse como aplicación **portable con interfaz gráfica en el
navegador**: no hay que instalar la app, solo arrancar un lanzador. Hay dos
niveles según si quieres tener Python en el sistema o no.

---

## Opción 1 — Un clic (recomendada)  ·  Windows
Requiere tener **Python 3.10–3.12** instalado una vez (desde python.org, marcando
"Add python.exe to PATH"). La app en sí no se instala.

1. Descomprime el ZIP del proyecto.
2. Doble clic en **`Photo2Print.bat`**.
   - La primera vez crea su propio entorno dentro de la carpeta e instala solo
     lo que la **interfaz web** necesita (`requirements-web.txt`: numpy, Pillow,
     trimesh, scipy, scikit-image, shapely, fast-simplification). **No** instala
     PySide6 ni VTK, que son las que suelen fallar en Windows. Tarda 2–5 min.
   - Las siguientes veces arranca al instante.
3. Se abre el navegador con la interfaz. Arrastra tu foto, ajusta la altura y
   pulsa **Generar 3D**. Descarga el **STL** (o 3MF/OBJ).

### Si el `.bat` no arranca
- Ejecuta **`diagnostico.bat`** (doble clic): crea `diagnostico.txt` con la
  versión de Python y si las dependencias cargan. Ábrelo y comparte su contenido.
- Revisa **`setup_log.txt`** (se crea en la primera instalación) por si pip falló.
- Causa típica: *"python" es el acceso de la Microsoft Store*. Instala Python
  real desde python.org, o desactiva el alias en Configuración → Aplicaciones →
  Alias de ejecución de aplicaciones → "python.exe".
- Con **Python 3.13** algunas ruedas pueden faltar; usa **3.12** si ves errores.

En **macOS/Linux** es igual con **`Photo2Print.command`**.

> Todo es local: tu foto no sale del equipo. Para cerrar, cierra la ventana
> negra (consola) que quedó abierta.

---

## Opción 2 — Totalmente portable, SIN instalar Python  ·  Windows
Ideal para llevar en un USB. Descarga un Python "embebido" **dentro de la
carpeta**; no se instala nada en el sistema.

1. Clic derecho en
   `installers\portable\bootstrap_windows_portable.ps1` → **Ejecutar con
   PowerShell** (necesita internet solo esta vez).
   - Si Windows bloquea el script, abre PowerShell y ejecuta:
     `powershell -ExecutionPolicy Bypass -File installers\portable\bootstrap_windows_portable.ps1`
2. Al terminar, arranca la app con **`Photo2Print_Portable.bat`** (doble clic).
3. Puedes copiar **toda la carpeta** a otro equipo o a un USB y funcionará igual.

---

## ¿Y sin nada de internet ni Python? (bundle .exe)
Para un ejecutable único que no requiera Python ni descargas, hay que
**compilarlo en Windows** con PyInstaller (ver `installers/windows/build_windows.md`).
Eso produce `Photo2Print.exe`. No se puede generar sin una máquina Windows.

---

## Consejos para un buen resultado
- Foto nítida, sujeto centrado, **fondo liso y con contraste**.
- Sin IA (por defecto) el recorte es básico pero funciona; para mejor recorte:
  marca "Usar IA" en la interfaz y, una vez, instala en la carpeta:
  `pip install rembg onnxruntime` (o con el Python portable:
  `python-portable\python.exe -m pip install rembg onnxruntime`).
- Si el modelo es grande, activa **Vaciar interior** para ahorrar material.

## Interfaces disponibles
- **Web (portable):** `python run_web.py` → navegador. Es la que usan los
  lanzadores de arriba.
- **Escritorio (PySide6):** `python run.py` → ventana nativa (requiere instalar
  `requirements.txt`, que ya incluye PySide6).
