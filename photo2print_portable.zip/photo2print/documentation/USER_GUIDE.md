# Guía de usuario — Photo2Print

Convierte fotos en un modelo 3D imprimible. No necesitas saber programar.
Hay **dos modos**:

- **Rápido (1 foto):** ideal para relieves, medallones y bustos "tipo placa".
- **Multivista (varias fotos):** da **volumen real** (incluida la espalda) y
  **transfiere el color** de las fotos. Ideal para figuras y objetos completos.

## 1. Importar y revisar

### Modo Rápido
1. Elige "Rápido — 1 foto" y el **tipo de modelo**.
2. **Importar imagen…**, luego **Eliminar fondo** (verás el sujeto en verde).
3. Ajusta con **Ampliar/Reducir selección** si hace falta.

### Modo Multivista (Fase 2)
1. Elige "Multivista — varias fotos".
2. **Añadir foto(s)…** las tomas alrededor del objeto (p. ej. cada 90°).
3. Indica el **ángulo** de cada foto (0° = frontal). El botón **Repartir
   ángulos automáticamente** los distribuye de forma regular.
4. Cuantas más vistas (4–8) y más limpio el fondo, mejor el volumen.

**Consejo:** para multivista, usa un plato giratorio o marcas en el suelo, la
misma distancia y altura de cámara, y gira en pasos regulares.

## 2. Generar 3D
1. Ajusta **Altura (mm)**, **Boquilla (mm)**, **Material**, **Detalle** y
   **Suavizado**.
2. Pulsa **Generar 3D** (barra de progreso; puedes **Cancelar**).
3. Gira el modelo en el visor (**Sólido / Textura / Alámbrico**).

En multivista, la figura se **orienta de pie** automáticamente para imprimir.

## 3. Reparar y exportar
1. Revisa el **informe de imprimibilidad** (cerrado, tamaño, material, soportes).
2. Si algo sale en rojo, pulsa **Reparar para impresión**.
3. Elige formato:
   - **STL / OBJ / 3MF:** geometría (para laminar directamente).
   - **PLY / GLB:** **conservan el color** (para previsualizar el color). Si tu
     modelo tiene color, la app preselecciona PLY.
4. **Exportar…** y, si quieres, **Abrir en Bambu Studio**.

> Impresión en color (AMS): hoy el color se conserva en PLY/GLB para
> previsualizar. Para imprimir multicolor, exporta la geometría (3MF/STL) y
> aplica el color/pintado en Bambu Studio. El 3MF con color por AMS llegará en
> la Fase 3.

## Preguntas rápidas
- **¿Sin GPU?** Sí, funciona en CPU con métodos básicos (también la multivista).
- **¿Se suben mis fotos?** No, todo es local.
- **¿Por qué la espalda es plana en modo Rápido?** Con una sola foto no hay
  datos de detrás. Usa **Multivista** para volumen real (ver LIMITATIONS.md).
- **¿Recupero mi trabajo si se cierra la app?** Sí, hay autoguardado.
