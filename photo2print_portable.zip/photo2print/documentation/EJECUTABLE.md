# Generar un ejecutable autocontenido (.exe / app)

Este método crea **un ejecutable que ya lleva Python y todas las dependencias
dentro**. El usuario final solo hace doble clic; **no instala nada**.

> Importante: el ejecutable hay que **construirlo una vez en el mismo sistema
> operativo** de destino (un `.exe` se crea en Windows; el binario de macOS se
> crea en macOS). No se puede crear un `.exe` de Windows desde macOS/Linux ni
> al revés. Los scripts de abajo automatizan ese único paso.

## Windows → `Photo2Print.exe`
Requisitos para **construir** (una vez): Python 3.10–3.12 e internet.

1. Doble clic en **`installers\exe\build_exe_windows.bat`**.
   - Crea un entorno temporal, instala las dependencias ligeras + PyInstaller y
     empaqueta. Tarda unos minutos. El registro queda en `build_log.txt`.
2. Al terminar tendrás **`Photo2Print.exe`** en la carpeta del proyecto.
3. **Doble clic en `Photo2Print.exe`**: se abre una ventana con la URL local y
   el navegador con la interfaz. Sube tu foto → **Generar 3D** → descarga el STL.

Ese `.exe` es portable: puedes copiarlo a otro PC con Windows (mismo bits, 64)
y funciona **sin instalar nada**.

## macOS → `Photo2Print.app`
Requisitos para **construir** (una vez): Python 3.10–3.12 e internet.

1. En Finder, ve a `installers/exe/` y haz **doble clic** en
   **`build_app_macos.command`** (la primera vez: clic derecho → Abrir, para
   saltar el aviso de Gatekeeper). Si prefieres Terminal:
   `bash installers/exe/build_app_macos.command`
   - Crea el entorno, instala dependencias + PyInstaller y **empaqueta un
     `.app` de verdad**. Tarda unos minutos (registro en `build_log.txt`).
2. Al terminar tendrás **`Photo2Print.app`** en la carpeta del proyecto (y el
   script intenta abrirla para probar).
3. **Doble clic en `Photo2Print.app`** → se abre sola en tu navegador. Sube tu
   foto → **Generar 3D** → descarga el STL.

> **Importante (por qué antes no se abría):** PyInstaller sin `.app` genera un
> binario "pelado" de consola que macOS **no** lanza con doble clic. Este spec
> genera un **`.app` real**, que sí se abre.
>
> - **Primera vez:** si macOS dice "no se puede abrir porque es de un
>   desarrollador no identificado", haz **clic derecho → Abrir → Abrir**. (El
>   script ya le quita la cuarentena con `xattr -cr`, pero si copias la .app a
>   otro Mac puede volver a pedirlo.)
> - **Para cerrarla:** clic derecho en su icono del **Dock → Salir** (no tiene
>   ventana propia; funciona en segundo plano sirviendo la interfaz web).
> - Si aún no abriera, en Terminal: `open Photo2Print.app`. Y para ver por qué:
>   `./Photo2Print.app/Contents/MacOS/Photo2Print` (mostrará mensajes/errores).

Puedes mover `Photo2Print.app` a la carpeta **Aplicaciones** o a otro Mac.

## ¿Qué incluye el ejecutable?
- Python + numpy, Pillow, trimesh, scipy, scikit-image, shapely, fast-simplification.
- Toda la app (motor de generación + interfaz web).
- **No** incluye PySide6 ni VTK (la web no los necesita; así el binario es más
  ligero y fiable).
- **No** incluye la IA (rembg/torch): el recorte usa el método básico. Si algún
  día quieres IA, se usa mejor la versión de escritorio con `requirements.txt`.

## Verificado
La receta de empaquetado (mismo `.spec`, mismo PyInstaller) se probó
construyendo el binario en Linux dentro del entorno de desarrollo: el
ejecutable **arranca y sirve la interfaz web** correctamente. En Windows/macOS
el resultado es el `.exe`/binario equivalente.

## Firma (opcional)
Sin firmar, Windows (SmartScreen) o macOS (Gatekeeper) mostrarán un aviso la
primera vez; se puede abrir igualmente (Windows: "Más información" → "Ejecutar
de todos modos"; macOS: clic derecho → Abrir). Firmar requiere tus
certificados: ver `installers/windows/build_windows.md` y
`installers/macos/build_macos.md`.

## Tamaño
El ejecutable ronda los 150–260 MB porque empaqueta numpy/scipy/scikit-image.
Es normal para apps científicas autocontenidas.
