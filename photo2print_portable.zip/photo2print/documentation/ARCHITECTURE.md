# Arquitectura — Photo2Print (Fase 1 / MVP)

## Principio rector
Aplicación de escritorio **local-first**: todo el procesamiento ocurre en el
equipo del usuario. Las imágenes no se envían a ningún servidor salvo que el
usuario lo active de forma explícita (previsto para fases posteriores).

## Capas
```
┌──────────────────────── UI (PySide6) ────────────────────────┐
│  main_window  ·  steps/ (importar, generar, exportar)         │
│  widgets/ (viewer3d, image_view)  ·  worker (QThread)         │
└───────────────┬───────────────────────────────────────────────┘
                │ llama (con callbacks progreso/cancelar)
┌───────────────▼──────────── Pipeline (sin GUI) ───────────────┐
│  orchestrator  → images → segmentation → depth →              │
│                 reconstruct → mesh_tools → print_analysis      │
└───────────────┬───────────────────────────────────────────────┘
                │ produce trimesh.Trimesh (mm)
┌───────────────▼──────────── Exporters ────────────────────────┐
│  STL · OBJ · 3MF                                              │
└───────────────────────────────────────────────────────────────┘
   Transversal:  config · system_probe · logging · i18n · project
```

## Por qué esta separación
- **La lógica pesada no vive en la UI.** `pipeline/` no importa PySide6, así
  que se puede probar en CI headless y reutilizar desde `cli.py`.
- **Cancelación y progreso** se pasan como callbacks al orquestador; el
  `GenerationWorker` (QThread) los conecta a señales de Qt.
- **Degradación elegante:** segmentación y profundidad tienen *fallback*
  determinista sin dependencias de IA, de modo que el MVP funciona en
  cualquier equipo y luego mejora si se instalan `rembg`/`torch`.

## Flujo de datos de generación
1. `images.load_image` → RGB uint8 (corrige EXIF, soporta HEIC).
2. `segmentation.segment` → máscara del sujeto (rembg o fallback).
3. `depth.estimate_depth` → mapa de profundidad [0,1] (MiDaS o fallback).
4. `reconstruct.reconstruct_solid` → **sólido estanco** por extrusión de
   heightmap enmascarado (frente con relieve + espalda plana + paredes).
5. `mesh_tools` → reparar, quedarse con la pieza mayor, suavizar, escalar a
   la altura en mm, apoyar en Z=0 (+ base opcional), centrar.
6. `print_analysis.analyze` → informe de imprimibilidad y estimaciones.
7. `exporters.export` → STL/OBJ/3MF en milímetros.

## Sistema de coordenadas
- **X**: horizontal de la imagen. **Y**: vertical (alto del sujeto).
- **Z**: relieve/profundidad (frente hacia +Z, espalda plana en Z=0).
- La "altura" configurable en mm corresponde al eje **Y**.
- El modelo se apoya con la espalda (Z=0) sobre la cama: orientación natural
  para imprimir un relieve/busto generado desde una sola foto.

## Persistencia
- Proyecto `.p2p` = ZIP con `project.json` + `images/` + `mesh.stl`.
- **Autosave** tras cada generación en la carpeta de cache → recuperación
  tras cierre inesperado.

## Puntos de extensión (Fases 2–4)
- `depth.py` y `segmentation.py`: añadir nuevos backends de IA sin tocar la UI.
- `reconstruct.py`: sustituir la espalda plana por reconstrucción multivista.
- `exporters/`: añadir laminado/【slicing】 o exportación de color.

## Novedades de la Fase 2 (reconstrucción volumétrica + color)
Módulos nuevos en `pipeline/`:
- **`cameras.py`** — modelo de plato giratorio ortográfico: `View`
  (imagen+máscara+ángulo), rotación en Y y proyección a píxeles.
- **`multiview.py`** —
  - `visual_hull(views, ...)`: **space carving**. Intersección de siluetas en
    una rejilla de vóxeles → marching cubes (skimage) → malla estanca con
    **volumen real** (incluida la parte trasera). *Fallback* a cajas de vóxel
    si no hay skimage.
  - `reconstruct_front_back(...)`: sólido cerrado desde foto frontal + trasera.
- **`texturing.py`** — `color_from_views(mesh, views)`: color **por vértice**
  muestreando cada foto, ponderado por cuánto mira la superficie a esa cámara
  (evita pintar la espalda con la textura del frente). Normaliza los vértices
  internamente, así funciona a cualquier escala.

Orquestación y salida:
- `orchestrator.generate_multiview(image_paths, angles, ...)`: procesa cada
  foto, reconstruye, repara, **orienta la figura de pie** (Y→Z), escala a mm,
  colorea y analiza. Reutiliza `mesh_tools`/`print_analysis`.
- `mesh_tools`: `scale_to_height(axis=...)` y `orient_upright_y_to_z()`.
- `exporters`: **PLY** y **GLB** conservan color por vértice (STL/OBJ/3MF =
  solo geometría). `COLOR_FORMATS = ("ply","glb")`.

UI:
- `import_step` ofrece **modo Rápido (1 foto)** y **Multivista (varias fotos
  con ángulos)**; `job()` devuelve el trabajo a ejecutar.
- `worker` despacha a `generate` o `generate_multiview` según el modo.

### Coordenadas en multivista
Reconstrucción en cubo normalizado (X dcha., **Y altura**, Z profundidad/frente).
Antes de imprimir se rota **Y→Z** para que la figura quede **de pie** sobre la
cama (Z arriba) y se escala la altura a lo largo de Z.

## Novedades de la Fase 3 (postprocesado y textura)
Módulos nuevos en `pipeline/`:
- **`postprocess.py`** — `hollow()` (vaciado por vóxeles con pared y drenaje,
  sin booleanos), `decimate()` (reduce caras con `fast_simplification`),
  `auto_orient()` (apoya la cara mayor abajo), `advanced_repair()` (pymeshlab
  opcional, con fallback).
- **`uv_texture.py`** — `bake_texture()` (color por vértice → textura UV con
  xatlas). Opcional y desactivado por defecto (xatlas inestable en el sandbox).
- `orchestrator.apply_postprocess()` encadena auto-orientar → vaciar → decimar.

## Novedades de la Fase 4 (preparación de impresión)
- **`bed.py`** — `fits_bed()` y `split_for_bed()` (troceado por planos con tapa,
  usa shapely).
- **`render_preview.py`** — renderizador por software (z-buffer en numpy, sin
  GPU) para miniaturas y demos; sombreado plano y color por vértice.
- **`printpack.py`** — `estimate()` (dimensiones, volumen, material, tiempo) y
  `export_print_pack()` (modelo(s) + `manifest.json` + README + `preview.png`).
- CLI: `--hollow`, `--drain`, `--decimate`, `--auto-orient`, `--pack`.
