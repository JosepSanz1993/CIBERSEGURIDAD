# Modelos de IA — qué instalar y dónde

El MVP **funciona sin ningún modelo de IA** gracias a los métodos *fallback*.
Instalar los modelos mejora notablemente la calidad de la máscara y del
volumen. Todo es opcional y local.

## 1. Eliminación de fondo — rembg (U²-Net)
- Paquete: `rembg` + `onnxruntime` (CPU) u `onnxruntime-gpu`.
- Licencia: MIT (rembg). Modelo U²-Net.
- Instalación:
  ```bash
  pip install rembg onnxruntime
  ```
- **Descarga del modelo:** rembg descarga el `.onnx` automáticamente la
  primera vez que se usa, a `~/.u2net/` por defecto. Si quieres ubicarlo en la
  carpeta de la app, exporta la variable antes de lanzar:
  - Windows (PowerShell): `$env:U2NET_HOME="$env:APPDATA\Photo2Print\models"`
  - macOS/Linux: `export U2NET_HOME="$HOME/.local/share/Photo2Print/models"`
- Tamaño aproximado: ~170 MB (modelo `u2net`).

## 2. Profundidad monocular — MiDaS
- Paquete: `torch` (+ `timm` para algunos modelos).
- Licencia: MIT (Intel-ISL MiDaS).
- Instalación (elige CPU o CUDA según tu equipo; mira https://pytorch.org):
  ```bash
  # CPU
  pip install torch timm
  # CUDA (ejemplo; usa el índice que indique pytorch.org para tu versión)
  # pip install torch --index-url https://download.pytorch.org/whl/cu121
  ```
- **Descarga del modelo:** se hace vía `torch.hub` la primera vez que se
  genera con IA. Se guarda en la cache de torch hub:
  - Windows: `%USERPROFILE%\.cache\torch\hub`
  - macOS/Linux: `~/.cache/torch/hub`
- Modelo por defecto del MVP: `MiDaS_small` (rápido, ~80 MB). Para más
  calidad puedes cambiar a `DPT_Hybrid`/`DPT_Large` en `app/pipeline/depth.py`
  (más lentos y pesados).

## Cómo sabe la app qué usar
`app/system_probe.py` detecta CPU/GPU (CUDA/MPS) y RAM. Si `torch` ve una GPU,
la inferencia va a `cuda`/`mps`; si no, a `cpu`. Si los paquetes no están,
se usan los *fallback* y la app avisa en la pantalla de generación.

## Recomendación por equipo
- **Solo CPU / equipo modesto:** empieza sin IA (fallback). Añade `rembg` si
  quieres mejores recortes; MiDaS en CPU funciona pero es más lento.
- **GPU NVIDIA (≥6 GB) / Apple Silicon:** instala `torch` con soporte de GPU y
  `rembg`; la calidad sube bastante y sigue siendo rápido.

## Multivista (Fase 2) y modelos
La reconstrucción multivista (*visual hull*) **no usa IA**: es geometría pura
(intersección de siluetas + marching cubes de `scikit-image`, ya incluido en
`requirements.txt`). Aun así, la **calidad de las siluetas** es clave: instalar
`rembg` produce máscaras más limpias y, por tanto, un volumen más fiel. Sin
`rembg`, el método básico funciona pero conviene fotografiar con un fondo liso
y contrastado.
