# Hoja de ruta y alcance (Photo2Print)

Este documento **fija el alcance definitivo** de las cuatro fases y sustituye a
las menciones dispersas de fases anteriores. El estado real de cada elemento se
marca así: ✅ hecho y probado · 🟡 hecho, no ejecutable en el sandbox (ver
`NO_EJECUTADO_EN_SANDBOX.txt`) · ⏳ previsto.

## Fase 1 — MVP (una foto → sólido imprimible) ✅
- Importar JPG/PNG/WebP/BMP/TIFF y HEIC/HEIF. ✅
- Segmentación (rembg 🟡 / fallback ✅) y profundidad (MiDaS 🟡 / fallback ✅).
- Sólido estanco por extrusión de heightmap (frente + espalda plana + paredes). ✅
- Reparación básica, escala a altura exacta en mm, base plana, análisis de
  imprimibilidad. ✅
- Visor 3D 🟡 (pyvista) · exportación STL/OBJ/3MF. ✅
- Flujo por pasos, i18n, autosave, CLI. ✅ (GUI 🟡)

## Fase 2 — Volumen real multivista + color ✅
- Modelo de cámara turntable ortográfico. ✅
- Reconstrucción por **visual hull / space carving** (varias fotos → volumen
  con parte trasera real). ✅
- Modo **frontal + trasera** (dos fotos → sólido con grosor por ambas caras). ✅
- **Transferencia de color** por vértice desde las fotos. ✅
- Exportación con color **PLY/GLB**. ✅
- Orientación automática "de pie" para impresión. ✅
- Integración en orquestador, CLI multivista y UI (modo + ángulos). ✅ (UI 🟡)

## Fase 3 — Postprocesado de malla y textura ✅ / 🟡
- **Vaciado (hollow)** con grosor de pared y agujero de drenaje (ahorro de
  material). ✅
- **Decimación** a un presupuesto de caras (archivos más ligeros). ✅
- **Auto-orientación** sobre la cara plana mayor (mejor adherencia/soportes). ✅
- **Reparación avanzada** con pymeshlab (opcional; fallback a la básica). 🟡
- **Baking de textura UV** (color por vértice → mapa de textura, OBJ+MTL/GLB
  con textura). 🟡 (usa xatlas; desactivado por defecto porque crashea en el
  sandbox de desarrollo — en máquina real suele funcionar).

## Fase 4 — Preparación de impresión (print pack) ✅
- **Comprobación de encaje en cama** y **troceado** por planos si no cabe. ✅
- **Estimación** de dimensiones, volumen, material (g/m) y tiempo aproximado. ✅
- **Print pack**: modelo(s) + `manifest.json` (ajustes recomendados) + README +
  **vista previa PNG** (renderizador por software, sin GPU). ✅
- Handoff a Bambu Studio (abrir archivo). ✅ (acción de sistema, 🟡 en sandbox)

## Más allá (⏳ futuro, fuera del alcance actual)
- Fotogrametría real (SfM/MVS) para concavidades internas.
- 3MF con color por AMS (multicolor real) y pintado por triángulo.
- Conectores tipo espiga/imán al trocear para la cama.
- Modelos de profundidad/segmentación más avanzados y soporte GPU afinado.
- Firma/notarización automatizada (requiere certificados del usuario).

## Nota sobre el alcance
El texto literal del *brief* de las fases venía como adjunto y no quedó en el
historial de trabajo. Este alcance se ha consolidado de forma coherente con el
objetivo del producto (foto → figura con volumen y color, imprimible en Bambu).
Si tu documento define alguna fase de otra manera, ajústalo aquí y lo
adaptamos.
