# Limitaciones conocidas (Fase 1 + Fase 2)

Honestidad ante todo. Estas son las limitaciones reales tras la Fase 2 y cómo
se abordarán más adelante.

## 1. Espalda plana → resuelto parcialmente en Fase 2
- **Modo Rápido (1 foto):** sigue generando frente con relieve y **espalda
  plana aproximada** (no hay datos de detrás). Útil para relieves, medallones
  y bustos "tipo placa".
- **Modo Multivista (Fase 2):** con varias fotos alrededor del objeto se
  reconstruye un **volumen real** (con parte trasera) por *visual hull* /
  space carving. Ya no es plano.
- **Modo Frontal+Trasera (Fase 2):** con dos fotos (delante y detrás) se cierra
  un sólido con grosor real por ambas caras.

## 2. El *visual hull* no capta concavidades
El space carving reconstruye la envolvente de las siluetas: **no puede recuperar
huecos internos** ni concavidades profundas que no se vean en el contorno (p. ej.
el interior de una taza). Es una limitación intrínseca del método.
- **Fase 3/4:** fotogrametría (features + profundidad multivista) o modelos
  generativos para recuperar concavidades.

## 3. Cámara aproximada (turntable ortográfico)
La multivista asume plato giratorio y proyección ortográfica, sin calibrar la
cámara. Es robusto y sencillo, pero introduce error si las fotos se toman a
distinta distancia/altura o con mucha perspectiva. Recomendado: objeto
centrado, misma distancia, giros regulares.
- **Fase 3:** estimación de pose/calibración para mayor fidelidad.

## 4. Color por vértice, sin textura UV
El color de Fase 2 se asigna **por vértice** (se ve mejor cuanta más resolución
de malla). Aún no hay mapa de textura UV ni pintado por triángulo para AMS.
Los formatos que conservan color son **PLY** y **GLB**; STL/OBJ/3MF exportan
solo geometría.
- **Fase 3:** textura UV y **3MF con color por AMS** para impresión multicolor.

## 5. Profundidad estimada (modo 1 foto)
En el modo rápido, la profundidad es una estimación (MiDaS o *fallback*), no una
medida métrica.

## 6. Reparación básica
Cubre duplicados, caras degeneradas, normales, winding y relleno simple. Mallas
muy problemáticas pueden requerir herramientas externas. (Fase 3: `pymeshlab`.)

## 7. Modelos de IA pesados y opcionales
`torch`/`rembg` implican descargas grandes; se dejan **opcionales**. El MVP y la
multivista funcionan con *fallback* sin IA (aunque siluetas limpias con `rembg`
mejoran mucho el carving).

## 8. Firma de instaladores
Firmar (Windows Authenticode / Apple Developer ID + notarización) requiere **tus**
certificados y no se puede automatizar sin ellos.

## 9. Rendimiento
El *visual hull* es O(resolución³) en memoria/tiempo. Resolución 96 es un buen
equilibrio; 128+ da más detalle pero consume bastante más RAM. En equipos
modestos usa 64–96.

## Fase 3 / 4 — límites añadidos
- **Vaciado por vóxeles:** el grosor de pared se cuantiza a la resolución de
  vóxel; paredes muy finas en modelos grandes disparan el nº de caras (se
  recomienda decimar después). No usa booleanos, así que es robusto pero
  aproximado en detalles muy pequeños.
- **Decimación:** puede introducir pequeñas imperfecciones; el color por
  vértice se re-muestrea por vecino más cercano (no perfecto).
- **Troceado por cama:** cortes planos **sin conectores** (espigas/imanes)
  todavía; las piezas se pegan/encajan manualmente. (Futuro.)
- **Estimación de tiempo:** heurística por flujo volumétrico, no un laminado
  real; úsala como orden de magnitud.
- **Textura UV:** depende de xatlas; desactivada por defecto (ver
  NO_EJECUTADO_EN_SANDBOX.txt).
