import numpy as np
import pytest
import trimesh

from app.pipeline import cameras, multiview, texturing
from app.pipeline.cameras import View
from app import exporters


def _circle_views(colors, H=180, W=180, r=64):
    yy, xx = np.mgrid[0:H, 0:W]
    circle = ((xx - W / 2) ** 2 + (yy - H / 2) ** 2) < r ** 2
    mask = (circle.astype(np.uint8) * 255)
    views = []
    for ang, col in colors.items():
        rgb = np.zeros((H, W, 3), np.uint8)
        rgb[circle] = col
        views.append(View(rgb=rgb, mask=mask, angle_deg=float(ang)))
    return views


def test_default_angles():
    assert cameras.default_angles(4) == [0.0, 90.0, 180.0, 270.0]


def test_visual_hull_sphere_is_watertight_and_round():
    views = _circle_views({0: (200, 0, 0), 90: (0, 200, 0),
                           180: (0, 0, 200), 270: (200, 200, 0)})
    mesh = multiview.visual_hull(views, multiview.VisualHullParams(resolution=64, smooth_iters=4))
    assert mesh.is_watertight
    e = mesh.extents
    # esférico/simétrico: los tres ejes muy parecidos
    assert max(e) / min(e) < 1.15


def test_visual_hull_requires_two_views():
    views = _circle_views({0: (200, 0, 0)})
    with pytest.raises(ValueError):
        multiview.visual_hull(views)


def test_visual_hull_empty_mask_raises():
    # Una vista con máscara vacía no se puede encuadrar -> error claro.
    H = W = 120
    good = np.zeros((H, W), np.uint8); good[30:90, 30:90] = 255
    empty = np.zeros((H, W), np.uint8)
    rgb = np.zeros((H, W, 3), np.uint8)
    views = [View(rgb, good, 0.0), View(rgb, empty, 90.0)]
    with pytest.raises(ValueError):
        multiview.visual_hull(views, multiview.VisualHullParams(resolution=48))


def test_color_from_views_assigns_side_colors():
    # Mismo conjunto de vistas de color para el hull y para el color, como en
    # el uso real. Frente (ángulo 0) rojo, espalda (ángulo 180) azul.
    colors = {0: (240, 0, 0), 90: (0, 240, 0), 180: (0, 0, 240), 270: (240, 240, 0)}
    views = _circle_views(colors)
    mesh = multiview.visual_hull(views, multiview.VisualHullParams(resolution=72, smooth_iters=4))
    colored = texturing.color_from_views(mesh, views)
    assert texturing.has_color(colored)
    C = colored.visual.vertex_colors[:, :3].astype(float)
    V = colored.vertices
    front = C[V[:, 2] > V[:, 2].max() * 0.5]      # cara hacia +Z (rojo)
    back = C[V[:, 2] < V[:, 2].min() * 0.5]        # cara hacia -Z (azul)
    # ignora vértices de borde negros (fondo) al comparar canales dominantes
    fr = front[front.sum(1) > 30]
    bk = back[back.sum(1) > 30]
    assert fr[:, 0].mean() > fr[:, 2].mean()       # frente más rojo que azul
    assert bk[:, 2].mean() > bk[:, 0].mean()       # espalda más azul que rojo


def test_front_back_is_watertight():
    H = W = 160
    yy, xx = np.mgrid[0:H, 0:W]
    circle = ((xx - W / 2) ** 2 + (yy - H / 2) ** 2) < 55 ** 2
    mask = circle.astype(np.uint8) * 255
    d = np.zeros((H, W), np.float32)
    d[circle] = 0.8
    mesh = multiview.reconstruct_front_back(d, mask, d, mask, detail_level=1)
    assert mesh.is_watertight


@pytest.mark.parametrize("fmt", ["ply", "glb"])
def test_colored_export_roundtrip(tmp_path, fmt):
    m = trimesh.creation.icosphere(subdivisions=2)
    m.visual.vertex_colors = np.tile([200, 40, 40, 255], (len(m.vertices), 1))
    out = exporters.export(m, tmp_path / "c", fmt)
    r = trimesh.load(out, force="mesh")
    assert len(r.vertices) == len(m.vertices)
    assert hasattr(r.visual, "vertex_colors")


def test_orient_upright_moves_height_to_z():
    from app.pipeline import mesh_tools
    box = trimesh.creation.box(extents=[10, 40, 5])  # alto en Y
    up = mesh_tools.orient_upright_y_to_z(box)
    # tras orientar, la mayor extensión debe estar en Z
    assert np.argmax(up.extents) == 2
