import numpy as np
import pytest

from app.pipeline import depth, segmentation, reconstruct


def test_reconstruct_is_watertight(disk_rgb, disk_mask):
    d, _ = depth.estimate_depth(disk_rgb, prefer_ai=False)
    mesh = reconstruct.reconstruct_solid(d, disk_mask)
    assert mesh.is_watertight
    assert len(mesh.faces) > 100
    # el sólido tiene volumen positivo
    assert abs(mesh.volume) > 0


def test_reconstruct_detail_levels(disk_rgb, disk_mask):
    d, _ = depth.estimate_depth(disk_rgb, prefer_ai=False)
    low = reconstruct.reconstruct_solid(
        d, disk_mask, reconstruct.ReconstructParams(detail_level=1))
    high = reconstruct.reconstruct_solid(
        d, disk_mask, reconstruct.ReconstructParams(detail_level=3))
    assert len(high.faces) >= len(low.faces)


def test_empty_mask_raises(disk_rgb):
    d, _ = depth.estimate_depth(disk_rgb, prefer_ai=False)
    empty = np.zeros(disk_rgb.shape[:2], np.uint8)
    with pytest.raises(ValueError):
        reconstruct.reconstruct_solid(d, empty)


def test_segment_fallback_covers_subject(disk_rgb):
    mask, method = segmentation.segment(disk_rgb, prefer_rembg=False)
    assert method == "fallback"
    cover = (mask > 127).mean()
    assert 0.1 < cover < 0.7
