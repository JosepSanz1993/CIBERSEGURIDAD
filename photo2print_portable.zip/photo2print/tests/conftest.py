"""Fixtures compartidas: imágenes sintéticas y utilidades."""
from __future__ import annotations

import numpy as np
import pytest
from PIL import Image


@pytest.fixture
def disk_rgb() -> np.ndarray:
    """Círculo claro texturizado sobre fondo oscuro (300x240 RGB)."""
    rng = np.random.default_rng(0)
    h, w = 300, 240
    yy, xx = np.mgrid[0:h, 0:w]
    disk = ((xx - w / 2) ** 2 + (yy - h / 2) ** 2) < 90 ** 2
    rgb = np.full((h, w, 3), (20, 20, 30), np.uint8)
    tex = (180 + 60 * rng.random((disk.sum(), 1))).astype(np.uint8)
    rgb[disk] = np.repeat(tex, 3, axis=1)
    return rgb


@pytest.fixture
def disk_mask(disk_rgb) -> np.ndarray:
    h, w = disk_rgb.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w]
    disk = ((xx - w / 2) ** 2 + (yy - h / 2) ** 2) < 90 ** 2
    return (disk.astype(np.uint8) * 255)


@pytest.fixture
def image_files(tmp_path, disk_rgb):
    """Guarda la imagen en varios formatos, incluida una ruta con acentos."""
    paths = {}
    for name in ["foto.jpg", "foto.png", "foto.webp", "café_ñandú.png"]:
        p = tmp_path / name
        Image.fromarray(disk_rgb).save(p)
        paths[name] = str(p)
    return paths
