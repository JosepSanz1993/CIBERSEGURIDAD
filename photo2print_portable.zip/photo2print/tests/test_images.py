import numpy as np
import pytest

from app.pipeline import images as im


def test_load_various_formats(image_files):
    for name, path in image_files.items():
        arr = im.load_image(path)
        assert arr.ndim == 3 and arr.shape[2] in (3, 4)
        assert arr.dtype == np.uint8


def test_load_accented_path(image_files):
    arr = im.load_image(image_files["café_ñandú.png"])
    assert arr.shape[0] > 0 and arr.shape[1] > 0


def test_missing_file_raises():
    with pytest.raises(im.ImageLoadError):
        im.load_image("/no/existe/imagen.png")


def test_to_rgb_flattens_alpha():
    rgba = np.zeros((4, 4, 4), np.uint8)
    rgba[..., 3] = 255
    rgb = im.to_rgb(rgba)
    assert rgb.shape == (4, 4, 3)


def test_downscale_max_side():
    arr = np.zeros((1000, 500, 3), np.uint8)
    out = im.downscale_max_side(arr, 200)
    assert max(out.shape[:2]) == 200
