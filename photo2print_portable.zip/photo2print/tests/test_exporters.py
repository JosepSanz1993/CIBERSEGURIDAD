import pytest
import trimesh

from app import exporters
from app.pipeline import print_analysis
from app import system_probe


@pytest.mark.parametrize("fmt", ["stl", "obj", "3mf"])
def test_export_and_reload_preserves_scale(tmp_path, fmt):
    m = trimesh.creation.box(extents=[10, 20, 30])
    out = exporters.export(m, tmp_path / "model", fmt)
    assert out.exists()
    reloaded = trimesh.load(out, force="mesh")
    # se conserva la escala en mm
    assert abs(reloaded.extents[2] - 30.0) < 1e-2


def test_unsupported_format_raises(tmp_path):
    m = trimesh.creation.box()
    with pytest.raises(exporters.ExportError):
        exporters.export(m, tmp_path / "m", "gltf")


def test_print_analysis_on_box():
    m = trimesh.creation.box(extents=[20, 20, 20])
    rep = print_analysis.analyze(m, nozzle_diameter_mm=0.4, material="PLA")
    assert rep.printable
    assert rep.est_filament_g > 0
    d = rep.to_dict()
    assert d["printable"] is True


def test_system_probe_never_raises():
    info = system_probe.probe()
    assert info.cpu_count >= 1
    assert info.device in ("cpu", "cuda", "mps")
    assert info.quality_tier in ("low", "medium", "high")
