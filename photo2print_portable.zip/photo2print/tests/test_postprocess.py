import json
import numpy as np
import trimesh
import pytest

from app.pipeline import postprocess as pp
from app.pipeline import bed, render_preview, printpack
from app.config import PrintSettings


# ---------------- Fase 3 ----------------
def test_hollow_reduces_volume_and_is_closed():
    s = trimesh.creation.icosphere(subdivisions=3, radius=15.0)
    solid = abs(s.volume)
    h = pp.hollow(s, wall_thickness_mm=2.0)
    assert h.is_watertight
    assert abs(h.volume) < solid * 0.85     # se ha vaciado material


def test_hollow_too_thin_returns_solid():
    s = trimesh.creation.icosphere(subdivisions=2, radius=4.0)
    h = pp.hollow(s, wall_thickness_mm=50.0)  # pared mayor que el objeto
    assert len(h.faces) > 0                   # no revienta; devuelve algo válido


def test_decimate_reduces_faces_keeps_watertight():
    s = trimesh.creation.icosphere(subdivisions=4)
    d = pp.decimate(s, 800)
    assert len(d.faces) <= len(s.faces)
    assert d.is_watertight


def test_decimate_noop_when_already_small():
    s = trimesh.creation.box()
    d = pp.decimate(s, 100000)
    assert len(d.faces) == len(s.faces)


def test_auto_orient_puts_largest_face_down():
    box = trimesh.creation.box(extents=[10, 40, 3])
    o = pp.auto_orient(box)
    assert np.argmin(o.extents) == 2                 # descansa sobre la cara mayor
    assert abs(float(o.bounds[0][2])) < 1e-6         # apoyado en Z=0


# ---------------- Fase 4 ----------------
def test_fits_bed():
    small = trimesh.creation.box(extents=[100, 100, 100])
    big = trimesh.creation.box(extents=[400, 50, 50])
    assert bed.fits_bed(small)
    assert not bed.fits_bed(big)


def test_split_for_bed_pieces_fit():
    bar = trimesh.creation.box(extents=[600, 50, 50])
    parts = bed.split_for_bed(bar)
    assert len(parts) >= 3
    assert all(p.extents[0] <= 256 + 1e-3 for p in parts)
    assert all(len(p.faces) > 0 for p in parts)


def test_render_produces_nonempty_image():
    s = trimesh.creation.icosphere(subdivisions=3, radius=15)
    s.visual.vertex_colors = np.tile([210, 80, 60, 255], (len(s.vertices), 1))
    img = render_preview.render(s, size=256)
    assert img.shape == (256, 256, 3)
    drawn = (img.reshape(-1, 3) != np.array([245, 245, 248])).any(1).sum()
    assert drawn > 500                                # ha dibujado la figura


def test_print_pack_writes_files_and_manifest(tmp_path):
    s = trimesh.creation.icosphere(subdivisions=3, radius=15)
    st = PrintSettings(target_height_mm=60, material="PLA")
    info = printpack.export_print_pack(s, tmp_path, st, model_format="stl")
    man = json.loads(open(info["manifest"], encoding="utf-8").read())
    assert man["app"] == "Photo2Print"
    assert man["estimate"]["filament_g"] > 0
    assert (tmp_path / "manifest.json").exists()
    assert (tmp_path / "README.txt").exists()


def test_print_pack_splits_large_model(tmp_path):
    bar = trimesh.creation.box(extents=[600, 50, 50])
    st = PrintSettings(target_height_mm=50, material="PLA")
    info = printpack.export_print_pack(bar, tmp_path, st, model_format="stl",
                                       make_preview=False)
    assert info["estimate"]["fits_bed"] is False
    assert len(info["model_files"]) >= 3              # se troceó
