import numpy as np
import trimesh

from app.pipeline import mesh_tools


def _box():
    return trimesh.creation.box(extents=[10, 20, 30])


def test_scale_to_height_sets_y():
    m = _box()
    scaled = mesh_tools.scale_to_height(m, 100.0)
    assert abs(scaled.extents[1] - 100.0) < 1e-3


def test_scale_preserves_aspect_ratio():
    m = _box()  # x:y:z = 10:20:30
    scaled = mesh_tools.scale_to_height(m, 40.0)  # y -> 40 => factor 2
    assert abs(scaled.extents[0] - 20.0) < 1e-3
    assert abs(scaled.extents[2] - 60.0) < 1e-3


def test_basic_repair_keeps_watertight():
    m = _box()
    r = mesh_tools.basic_repair(m)
    assert r.is_watertight


def test_keep_largest_component():
    a = trimesh.creation.box()
    b = trimesh.creation.box(); b.apply_translation([100, 0, 0])
    b.faces = b.faces[:2]  # deja b como fragmento pequeño
    merged = trimesh.util.concatenate([a, b])
    largest = mesh_tools.keep_largest_component(merged)
    assert len(largest.faces) <= len(merged.faces)


def test_compute_stats_box():
    stats = mesh_tools.compute_stats(_box())
    assert stats.is_watertight
    assert stats.n_components == 1
    assert stats.bbox_mm[2] == 30.0


def test_add_flat_base_sits_on_z0():
    m = _box()
    based = mesh_tools.add_flat_base(m, base_thickness_mm=0.0)
    assert abs(based.bounds[0][2]) < 1e-6
