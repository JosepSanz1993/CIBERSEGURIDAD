import numpy as np
from app.pipeline import photo_relief as pr


def _grad_image(h=120, w=160):
    yy, xx = np.mgrid[0:h, 0:w].astype(float)
    g = (xx / w * 255).astype(np.uint8)
    return np.stack([g, g, g], -1)


def test_relief_is_watertight_and_sized():
    m = pr.heightmap_relief(_grad_image(), height_mm=100, relief_mm=5, base_mm=2, detail=1)
    assert m.is_watertight
    assert abs(m.extents[1] - 100.0) < 1e-3          # alto exacto
    assert abs(m.extents[2] - 7.0) < 0.2             # base + relieve


def test_relief_follows_brightness():
    # gradiente horizontal: el lado claro (derecha) debe ser más alto que el oscuro
    m = pr.heightmap_relief(_grad_image(), height_mm=100, relief_mm=6, base_mm=2, detail=1,
                            smooth=0.0, contrast=False)
    V = m.vertices
    xmax = V[:, 0].max()
    right = V[(V[:, 0] > xmax * 0.9)][:, 2].max()
    left = V[(V[:, 0] < xmax * 0.1)][:, 2].max()
    assert right > left


def test_any_shape_input():
    # imagen en escala de grises (2D) y con alfa (4 canales) no deben fallar
    g = (np.random.default_rng(0).random((80, 100)) * 255).astype(np.uint8)
    m1 = pr.heightmap_relief(g, height_mm=60, detail=1)
    rgba = np.dstack([np.stack([g]*3, -1), np.full_like(g, 255)])
    m2 = pr.heightmap_relief(rgba, height_mm=60, detail=1)
    assert m1.is_watertight and m2.is_watertight
