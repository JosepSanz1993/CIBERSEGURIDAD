@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo === Diagnostico Photo2Print === > diagnostico.txt
echo Fecha: %date% %time% >> diagnostico.txt
echo. >> diagnostico.txt
echo -- where python -- >> diagnostico.txt
where python >> diagnostico.txt 2>&1
echo -- py -3 --version -- >> diagnostico.txt
py -3 --version >> diagnostico.txt 2>&1
echo -- python --version -- >> diagnostico.txt
python --version >> diagnostico.txt 2>&1
echo -- existe .venv -- >> diagnostico.txt
if exist ".venv\Scripts\python.exe" (echo SI >> diagnostico.txt) else (echo NO >> diagnostico.txt)
echo -- import de dependencias en .venv -- >> diagnostico.txt
if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" -c "import numpy,PIL,trimesh,scipy,skimage,shapely;print('imports OK')" >> diagnostico.txt 2>&1
echo. >> diagnostico.txt
echo Listo. Se ha creado diagnostico.txt en esta carpeta.
echo Abrelo y pega su contenido para que podamos ayudarte.
type diagnostico.txt
echo.
pause
endlocal
